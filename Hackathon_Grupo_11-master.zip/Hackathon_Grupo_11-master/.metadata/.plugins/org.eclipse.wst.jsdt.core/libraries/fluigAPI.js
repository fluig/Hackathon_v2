fluigAPI = new Object();
List = function() {};
List.prototype = {};
Map = function() {};
Map.prototype = {};
Date = function() {};
Date.prototype = {};
com.fluig.sdk.api.alert.AlertActionVO = function() {};
com.fluig.sdk.api.alert.AlertActionVO.prototype = {};
com.fluig.sdk.api.alert.AlertConfigVO = function() {};
com.fluig.sdk.api.alert.AlertConfigVO.prototype = {};
com.fluig.sdk.api.alert.AlertEventVO = function() {};
com.fluig.sdk.api.alert.AlertEventVO.prototype = {};
com.fluig.sdk.api.alert.AlertModuleVO = function() {};
com.fluig.sdk.api.alert.AlertModuleVO.prototype = {};
com.fluig.sdk.api.alert.AlertObjectVO = function() {};
com.fluig.sdk.api.alert.AlertObjectVO.prototype = {};
com.fluig.sdk.api.alert.AlertSenderVO = function() {};
com.fluig.sdk.api.alert.AlertSenderVO.prototype = {};
com.fluig.sdk.api.alert.AlertUserVO = function() {};
com.fluig.sdk.api.alert.AlertUserVO.prototype = {};
com.fluig.sdk.api.alert.AlertVO = function() {};
com.fluig.sdk.api.alert.AlertVO.prototype = {};
com.fluig.sdk.api.authorizeclient.AuthorizeClientSdkServiceVO = function() {};
com.fluig.sdk.api.authorizeclient.AuthorizeClientSdkServiceVO.prototype = {};
com.fluig.sdk.api.document.AllocatedDocumentVO = function() {};
com.fluig.sdk.api.document.AllocatedDocumentVO.prototype = {};
com.fluig.sdk.api.document.DocumentApprovementHistoryVO = function() {};
com.fluig.sdk.api.document.DocumentApprovementHistoryVO.prototype = {};
com.fluig.sdk.api.document.DocumentApproverVO = function() {};
com.fluig.sdk.api.document.DocumentApproverVO.prototype = {};
com.fluig.sdk.api.document.DocumentPermissionVO = function() {};
com.fluig.sdk.api.document.DocumentPermissionVO.prototype = {};
com.fluig.sdk.api.document.DocumentRestrictionVO = function() {};
com.fluig.sdk.api.document.DocumentRestrictionVO.prototype = {};
com.fluig.sdk.api.document.DocumentSecurityConfigVO = function() {};
com.fluig.sdk.api.document.DocumentSecurityConfigVO.prototype = {};
com.fluig.sdk.api.document.DocumentSecurityVO = function() {};
com.fluig.sdk.api.document.DocumentSecurityVO.prototype = {};
com.fluig.sdk.api.document.DocumentTaskVO = function() {};
com.fluig.sdk.api.document.DocumentTaskVO.prototype = {};
com.fluig.sdk.api.document.DocumentVO = function() {};
com.fluig.sdk.api.document.DocumentVO.prototype = {};
com.fluig.sdk.api.document.FolderVO = function() {};
com.fluig.sdk.api.document.FolderVO.prototype = {};
com.fluig.sdk.api.document.RelatedDocumentVO = function() {};
com.fluig.sdk.api.document.RelatedDocumentVO.prototype = {};
com.fluig.sdk.api.ecm.CollaborationAppVO = function() {};
com.fluig.sdk.api.ecm.CollaborationAppVO.prototype = {};
com.fluig.sdk.api.ecm.CollaborationVO = function() {};
com.fluig.sdk.api.ecm.CollaborationVO.prototype = {};
com.fluig.sdk.api.enums.AssumeProcessTaskStatus = function() {};
com.fluig.sdk.api.enums.AssumeProcessTaskStatus.prototype = {};
com.fluig.sdk.api.group.GroupVO = function() {};
com.fluig.sdk.api.group.GroupVO.prototype = {};
com.fluig.sdk.api.holiday.HolidayVO = function() {};
com.fluig.sdk.api.holiday.HolidayVO.prototype = {};
com.fluig.sdk.api.job.JobVO = function() {};
com.fluig.sdk.api.job.JobVO.prototype = {};
com.fluig.sdk.api.job.JobVO.IntervalType = function() {};
com.fluig.sdk.api.job.JobVO.IntervalType.prototype = {};
com.fluig.sdk.api.lms.AlternativeVO = function() {};
com.fluig.sdk.api.lms.AlternativeVO.prototype = {};
com.fluig.sdk.api.lms.AssessmentApplicationFinishedVO = function() {};
com.fluig.sdk.api.lms.AssessmentApplicationFinishedVO.prototype = {};
com.fluig.sdk.api.lms.AssessmentBlockVersionVO = function() {};
com.fluig.sdk.api.lms.AssessmentBlockVersionVO.prototype = {};
com.fluig.sdk.api.lms.AssessmentScheduleEmailVO = function() {};
com.fluig.sdk.api.lms.AssessmentScheduleEmailVO.prototype = {};
com.fluig.sdk.api.lms.AssessmentScheduleVO = function() {};
com.fluig.sdk.api.lms.AssessmentScheduleVO.prototype = {};
com.fluig.sdk.api.lms.AssessmentTopicVO = function() {};
com.fluig.sdk.api.lms.AssessmentTopicVO.prototype = {};
com.fluig.sdk.api.lms.AssessmentVO = function() {};
com.fluig.sdk.api.lms.AssessmentVO.prototype = {};
com.fluig.sdk.api.lms.BlockQuestionsFilterVO = function() {};
com.fluig.sdk.api.lms.BlockQuestionsFilterVO.prototype = {};
com.fluig.sdk.api.lms.BlockVO = function() {};
com.fluig.sdk.api.lms.BlockVO.prototype = {};
com.fluig.sdk.api.lms.CatalogSkillVO = function() {};
com.fluig.sdk.api.lms.CatalogSkillVO.prototype = {};
com.fluig.sdk.api.lms.ContentConfigVO = function() {};
com.fluig.sdk.api.lms.ContentConfigVO.prototype = {};
com.fluig.sdk.api.lms.ContentVO = function() {};
com.fluig.sdk.api.lms.ContentVO.prototype = {};
com.fluig.sdk.api.lms.CorrelationAlternativeVO = function() {};
com.fluig.sdk.api.lms.CorrelationAlternativeVO.prototype = {};
com.fluig.sdk.api.lms.CorrelationQuestionVO = function() {};
com.fluig.sdk.api.lms.CorrelationQuestionVO.prototype = {};
com.fluig.sdk.api.lms.DisciplineVO = function() {};
com.fluig.sdk.api.lms.DisciplineVO.prototype = {};
com.fluig.sdk.api.lms.EnrollUsersLogVO = function() {};
com.fluig.sdk.api.lms.EnrollUsersLogVO.prototype = {};
com.fluig.sdk.api.lms.EnrolledUsersResponseVO = function() {};
com.fluig.sdk.api.lms.EnrolledUsersResponseVO.prototype = {};
com.fluig.sdk.api.lms.EnrollmentHistoryVO = function() {};
com.fluig.sdk.api.lms.EnrollmentHistoryVO.prototype = {};
com.fluig.sdk.api.lms.EnrollmentRequestVO = function() {};
com.fluig.sdk.api.lms.EnrollmentRequestVO.prototype = {};
com.fluig.sdk.api.lms.EssayQuestionVO = function() {};
com.fluig.sdk.api.lms.EssayQuestionVO.prototype = {};
com.fluig.sdk.api.lms.FolderDisciplineVO = function() {};
com.fluig.sdk.api.lms.FolderDisciplineVO.prototype = {};
com.fluig.sdk.api.lms.FolderVO = function() {};
com.fluig.sdk.api.lms.FolderVO.prototype = {};
com.fluig.sdk.api.lms.ImagePropertiesVO = function() {};
com.fluig.sdk.api.lms.ImagePropertiesVO.prototype = {};
com.fluig.sdk.api.lms.LMSTaskVO = function() {};
com.fluig.sdk.api.lms.LMSTaskVO.prototype = {};
com.fluig.sdk.api.lms.LacunaAlternativeVO = function() {};
com.fluig.sdk.api.lms.LacunaAlternativeVO.prototype = {};
com.fluig.sdk.api.lms.LacunaQuestionVO = function() {};
com.fluig.sdk.api.lms.LacunaQuestionVO.prototype = {};
com.fluig.sdk.api.lms.LinkVO = function() {};
com.fluig.sdk.api.lms.LinkVO.prototype = {};
com.fluig.sdk.api.lms.MultipleEnrollmentRequestVO = function() {};
com.fluig.sdk.api.lms.MultipleEnrollmentRequestVO.prototype = {};
com.fluig.sdk.api.lms.MultipleQuestionVO = function() {};
com.fluig.sdk.api.lms.MultipleQuestionVO.prototype = {};
com.fluig.sdk.api.lms.NormalClassVO = function() {};
com.fluig.sdk.api.lms.NormalClassVO.prototype = {};
com.fluig.sdk.api.lms.ObjectiveQuestionVO = function() {};
com.fluig.sdk.api.lms.ObjectiveQuestionVO.prototype = {};
com.fluig.sdk.api.lms.OrdinationQuestionVO = function() {};
com.fluig.sdk.api.lms.OrdinationQuestionVO.prototype = {};
com.fluig.sdk.api.lms.PermissionVO = function() {};
com.fluig.sdk.api.lms.PermissionVO.prototype = {};
com.fluig.sdk.api.lms.ReproveRequestVO = function() {};
com.fluig.sdk.api.lms.ReproveRequestVO.prototype = {};
com.fluig.sdk.api.lms.ScaleQuestionVO = function() {};
com.fluig.sdk.api.lms.ScaleQuestionVO.prototype = {};
com.fluig.sdk.api.lms.SkillVO = function() {};
com.fluig.sdk.api.lms.SkillVO.prototype = {};
com.fluig.sdk.api.lms.TrackItemVO = function() {};
com.fluig.sdk.api.lms.TrackItemVO.prototype = {};
com.fluig.sdk.api.lms.TrackVO = function() {};
com.fluig.sdk.api.lms.TrackVO.prototype = {};
com.fluig.sdk.api.lms.TrainingVO = function() {};
com.fluig.sdk.api.lms.TrainingVO.prototype = {};
com.fluig.sdk.api.local.LocalUserVO = function() {};
com.fluig.sdk.api.local.LocalUserVO.prototype = {};
com.fluig.sdk.api.local.LocalVO = function() {};
com.fluig.sdk.api.local.LocalVO.prototype = {};
com.fluig.sdk.api.oauth.OAuthSdkVO = function() {};
com.fluig.sdk.api.oauth.OAuthSdkVO.prototype = {};
com.fluig.sdk.api.permission.PermissionAssetVO = function() {};
com.fluig.sdk.api.permission.PermissionAssetVO.prototype = {};
com.fluig.sdk.api.permission.PermissionVO = function() {};
com.fluig.sdk.api.permission.PermissionVO.prototype = {};
com.fluig.sdk.api.search.DefaultSearchRequest = function() {};
com.fluig.sdk.api.search.DefaultSearchRequest.prototype = {};
com.fluig.sdk.api.search.DefaultSearchResponse = function() {};
com.fluig.sdk.api.search.DefaultSearchResponse.prototype = {};
com.fluig.sdk.api.social.ArticleCoverVO = function() {};
com.fluig.sdk.api.social.ArticleCoverVO.prototype = {};
com.fluig.sdk.api.social.ArticleVO = function() {};
com.fluig.sdk.api.social.ArticleVO.prototype = {};
com.fluig.sdk.api.social.CommentVO = function() {};
com.fluig.sdk.api.social.CommentVO.prototype = {};
com.fluig.sdk.api.social.CommunityVO = function() {};
com.fluig.sdk.api.social.CommunityVO.prototype = {};
com.fluig.sdk.api.social.CropVO = function() {};
com.fluig.sdk.api.social.CropVO.prototype = {};
com.fluig.sdk.api.social.MediaVO = function() {};
com.fluig.sdk.api.social.MediaVO.prototype = {};
com.fluig.sdk.api.social.PostVO = function() {};
com.fluig.sdk.api.social.PostVO.prototype = {};
com.fluig.sdk.api.social.SociableVO = function() {};
com.fluig.sdk.api.social.SociableVO.prototype = {};
com.fluig.sdk.api.social.SocialBreadcrumbItemVO = function() {};
com.fluig.sdk.api.social.SocialBreadcrumbItemVO.prototype = {};
com.fluig.sdk.api.social.SocialBreadcrumbVO = function() {};
com.fluig.sdk.api.social.SocialBreadcrumbVO.prototype = {};
com.fluig.sdk.api.social.SocialVO = function() {};
com.fluig.sdk.api.social.SocialVO.prototype = {};
com.fluig.sdk.api.task.ResumedTasksVO = function() {};
com.fluig.sdk.api.task.ResumedTasksVO.prototype = {};
com.fluig.sdk.api.task.TaskKindEnum = function() {};
com.fluig.sdk.api.task.TaskKindEnum.prototype = {};
com.fluig.sdk.api.task.TaskStatusEnum = function() {};
com.fluig.sdk.api.task.TaskStatusEnum.prototype = {};
com.fluig.sdk.api.workflow.AssumeProcessTaskResultVO = function() {};
com.fluig.sdk.api.workflow.AssumeProcessTaskResultVO.prototype = {};
com.fluig.sdk.api.workflow.AssumeProcessTaskVO = function() {};
com.fluig.sdk.api.workflow.AssumeProcessTaskVO.prototype = {};
com.fluig.sdk.api.workflow.AssumeProcessTasksResultVO = function() {};
com.fluig.sdk.api.workflow.AssumeProcessTasksResultVO.prototype = {};
com.fluig.sdk.api.workflow.AssumeProcessTasksVO = function() {};
com.fluig.sdk.api.workflow.AssumeProcessTasksVO.prototype = {};
com.fluig.sdk.api.workflow.AttachmentVO = function() {};
com.fluig.sdk.api.workflow.AttachmentVO.prototype = {};
com.fluig.sdk.api.workflow.CancelInstanceResultVO = function() {};
com.fluig.sdk.api.workflow.CancelInstanceResultVO.prototype = {};
com.fluig.sdk.api.workflow.CancelInstanceVO = function() {};
com.fluig.sdk.api.workflow.CancelInstanceVO.prototype = {};
com.fluig.sdk.api.workflow.CancelInstancesResultVO = function() {};
com.fluig.sdk.api.workflow.CancelInstancesResultVO.prototype = {};
com.fluig.sdk.api.workflow.CancelInstancesVO = function() {};
com.fluig.sdk.api.workflow.CancelInstancesVO.prototype = {};
com.fluig.sdk.api.workflow.CardIndexAttachmentVO = function() {};
com.fluig.sdk.api.workflow.CardIndexAttachmentVO.prototype = {};
com.fluig.sdk.api.workflow.CardIndexVO = function() {};
com.fluig.sdk.api.workflow.CardIndexVO.prototype = {};
com.fluig.sdk.api.workflow.CardItemVO = function() {};
com.fluig.sdk.api.workflow.CardItemVO.prototype = {};
com.fluig.sdk.api.workflow.ProcessAttachmentVO = function() {};
com.fluig.sdk.api.workflow.ProcessAttachmentVO.prototype = {};
com.fluig.sdk.api.workflow.ProcessDefinitionVO = function() {};
com.fluig.sdk.api.workflow.ProcessDefinitionVO.prototype = {};
com.fluig.sdk.api.workflow.ProcessDefinitionVersionVO = function() {};
com.fluig.sdk.api.workflow.ProcessDefinitionVersionVO.prototype = {};
com.fluig.sdk.api.workflow.ProcessInstanceInfoVO = function() {};
com.fluig.sdk.api.workflow.ProcessInstanceInfoVO.prototype = {};
com.fluig.sdk.api.workflow.ProcessObservationVO = function() {};
com.fluig.sdk.api.workflow.ProcessObservationVO.prototype = {};
com.fluig.sdk.api.workflow.ProcessStateVO = function() {};
com.fluig.sdk.api.workflow.ProcessStateVO.prototype = {};
com.fluig.sdk.api.workflow.ProcessTaskInfoVO = function() {};
com.fluig.sdk.api.workflow.ProcessTaskInfoVO.prototype = {};
com.fluig.sdk.api.workflow.ProcessTaskVO = function() {};
com.fluig.sdk.api.workflow.ProcessTaskVO.prototype = {};
com.fluig.sdk.api.workflow.ProcessVersionVO = function() {};
com.fluig.sdk.api.workflow.ProcessVersionVO.prototype = {};
com.fluig.sdk.api.workflow.RequestProcessTaskVO = function() {};
com.fluig.sdk.api.workflow.RequestProcessTaskVO.prototype = {};
com.fluig.sdk.api.workflow.RequestSLAVO = function() {};
com.fluig.sdk.api.workflow.RequestSLAVO.prototype = {};
com.fluig.sdk.api.workflow.RequestTaskSLAVO = function() {};
com.fluig.sdk.api.workflow.RequestTaskSLAVO.prototype = {};
com.fluig.sdk.api.workflow.ResumeProcessTaskVO = function() {};
com.fluig.sdk.api.workflow.ResumeProcessTaskVO.prototype = {};
com.fluig.sdk.api.workflow.ResumeRequestsSLAVO = function() {};
com.fluig.sdk.api.workflow.ResumeRequestsSLAVO.prototype = {};
com.fluig.sdk.api.workflow.WorkflowVO = function() {};
com.fluig.sdk.api.workflow.WorkflowVO.prototype = {};
com.fluig.sdk.filter.FilterFieldVO = function() {};
com.fluig.sdk.filter.FilterFieldVO.prototype = {};
com.fluig.sdk.filter.FilterGroupResultVO = function() {};
com.fluig.sdk.filter.FilterGroupResultVO.prototype = {};
com.fluig.sdk.filter.FilterGroupVO = function() {};
com.fluig.sdk.filter.FilterGroupVO.prototype = {};
com.fluig.sdk.filter.FilterOrderVO = function() {};
com.fluig.sdk.filter.FilterOrderVO.prototype = {};
com.fluig.sdk.filter.FilterResultVO = function() {};
com.fluig.sdk.filter.FilterResultVO.prototype = {};
com.fluig.sdk.filter.FilterVO = function() {};
com.fluig.sdk.filter.FilterVO.prototype = {};
com.fluig.sdk.identity.UserAuthTokenSessionVO = function() {};
com.fluig.sdk.identity.UserAuthTokenSessionVO.prototype = {};
com.fluig.sdk.page.PageMobileApiVO = function() {};
com.fluig.sdk.page.PageMobileApiVO.prototype = {};
com.fluig.sdk.page.PageWidgetMobileApiVO = function() {};
com.fluig.sdk.page.PageWidgetMobileApiVO.prototype = {};
com.fluig.sdk.page.PublicApiPageVO = function() {};
com.fluig.sdk.page.PublicApiPageVO.prototype = {};
com.fluig.sdk.service.AlertService = function() {};
com.fluig.sdk.service.AlertService.prototype = {};
com.fluig.sdk.service.ArticleService = function() {};
com.fluig.sdk.service.ArticleService.prototype = {};
com.fluig.sdk.service.AssessmentApplicationService = function() {};
com.fluig.sdk.service.AssessmentApplicationService.prototype = {};
com.fluig.sdk.service.AssessmentScheduleService = function() {};
com.fluig.sdk.service.AssessmentScheduleService.prototype = {};
com.fluig.sdk.service.AssessmentService = function() {};
com.fluig.sdk.service.AssessmentService.prototype = {};
com.fluig.sdk.service.AssessmentTopicService = function() {};
com.fluig.sdk.service.AssessmentTopicService.prototype = {};
com.fluig.sdk.service.AuthorizeClientSdkService = function() {};
com.fluig.sdk.service.AuthorizeClientSdkService.prototype = {};
com.fluig.sdk.service.BlockService = function() {};
com.fluig.sdk.service.BlockService.prototype = {};
com.fluig.sdk.service.CardIndexService = function() {};
com.fluig.sdk.service.CardIndexService.prototype = {};
com.fluig.sdk.service.CardService = function() {};
com.fluig.sdk.service.CardService.prototype = {};
com.fluig.sdk.service.CollaborationSDKService = function() {};
com.fluig.sdk.service.CollaborationSDKService.prototype = {};
com.fluig.sdk.service.CommentService = function() {};
com.fluig.sdk.service.CommentService.prototype = {};
com.fluig.sdk.service.CommunityService = function() {};
com.fluig.sdk.service.CommunityService.prototype = {};
com.fluig.sdk.service.ContentFilesService = function() {};
com.fluig.sdk.service.ContentFilesService.prototype = {};
com.fluig.sdk.service.ContentService = function() {};
com.fluig.sdk.service.ContentService.prototype = {};
com.fluig.sdk.service.CorrelationQuestionService = function() {};
com.fluig.sdk.service.CorrelationQuestionService.prototype = {};
com.fluig.sdk.service.DisciplineService = function() {};
com.fluig.sdk.service.DisciplineService.prototype = {};
com.fluig.sdk.service.DocumentService = function() {};
com.fluig.sdk.service.DocumentService.prototype = {};
com.fluig.sdk.service.DocumentationProxyServiceService = function() {};
com.fluig.sdk.service.DocumentationProxyServiceService.prototype = {};
com.fluig.sdk.service.EnrollmentRequestService = function() {};
com.fluig.sdk.service.EnrollmentRequestService.prototype = {};
com.fluig.sdk.service.EnrollmentService = function() {};
com.fluig.sdk.service.EnrollmentService.prototype = {};
com.fluig.sdk.service.EssayQuestionService = function() {};
com.fluig.sdk.service.EssayQuestionService.prototype = {};
com.fluig.sdk.service.FavoritesService = function() {};
com.fluig.sdk.service.FavoritesService.prototype = {};
com.fluig.sdk.service.FilterAPIService = function() {};
com.fluig.sdk.service.FilterAPIService.prototype = {};
com.fluig.sdk.service.FolderDisciplineService = function() {};
com.fluig.sdk.service.FolderDisciplineService.prototype = {};
com.fluig.sdk.service.FolderDocumentService = function() {};
com.fluig.sdk.service.FolderDocumentService.prototype = {};
com.fluig.sdk.service.FolderService = function() {};
com.fluig.sdk.service.FolderService.prototype = {};
com.fluig.sdk.service.GlobalParameterService = function() {};
com.fluig.sdk.service.GlobalParameterService.prototype = {};
com.fluig.sdk.service.GroupService = function() {};
com.fluig.sdk.service.GroupService.prototype = {};
com.fluig.sdk.service.HolidayAPIService = function() {};
com.fluig.sdk.service.HolidayAPIService.prototype = {};
com.fluig.sdk.service.I18NService = function() {};
com.fluig.sdk.service.I18NService.prototype = {};
com.fluig.sdk.service.IdentityService = function() {};
com.fluig.sdk.service.IdentityService.prototype = {};
com.fluig.sdk.service.JobService = function() {};
com.fluig.sdk.service.JobService.prototype = {};
com.fluig.sdk.service.LMSTaskService = function() {};
com.fluig.sdk.service.LMSTaskService.prototype = {};
com.fluig.sdk.service.LacunaQuestionService = function() {};
com.fluig.sdk.service.LacunaQuestionService.prototype = {};
com.fluig.sdk.service.LinkService = function() {};
com.fluig.sdk.service.LinkService.prototype = {};
com.fluig.sdk.service.LocalAPIService = function() {};
com.fluig.sdk.service.LocalAPIService.prototype = {};
com.fluig.sdk.service.MultipleQuestionService = function() {};
com.fluig.sdk.service.MultipleQuestionService.prototype = {};
com.fluig.sdk.service.NormalClassService = function() {};
com.fluig.sdk.service.NormalClassService.prototype = {};
com.fluig.sdk.service.ObjectiveQuestionService = function() {};
com.fluig.sdk.service.ObjectiveQuestionService.prototype = {};
com.fluig.sdk.service.OrdinationQuestionService = function() {};
com.fluig.sdk.service.OrdinationQuestionService.prototype = {};
com.fluig.sdk.service.PageService = function() {};
com.fluig.sdk.service.PageService.prototype = {};
com.fluig.sdk.service.PageWidgetService = function() {};
com.fluig.sdk.service.PageWidgetService.prototype = {};
com.fluig.sdk.service.PostService = function() {};
com.fluig.sdk.service.PostService.prototype = {};
com.fluig.sdk.service.ScaleQuestionService = function() {};
com.fluig.sdk.service.ScaleQuestionService.prototype = {};
com.fluig.sdk.service.SearchService = function() {};
com.fluig.sdk.service.SearchService.prototype = {};
com.fluig.sdk.service.SecurityService = function() {};
com.fluig.sdk.service.SecurityService.prototype = {};
com.fluig.sdk.service.SkillService = function() {};
com.fluig.sdk.service.SkillService.prototype = {};
com.fluig.sdk.service.SocialBreadcrumbService = function() {};
com.fluig.sdk.service.SocialBreadcrumbService.prototype = {};
com.fluig.sdk.service.SocialSDKService = function() {};
com.fluig.sdk.service.SocialSDKService.prototype = {};
com.fluig.sdk.service.TagsCloudService = function() {};
com.fluig.sdk.service.TagsCloudService.prototype = {};
com.fluig.sdk.service.TasksService = function() {};
com.fluig.sdk.service.TasksService.prototype = {};
com.fluig.sdk.service.TenantService = function() {};
com.fluig.sdk.service.TenantService.prototype = {};
com.fluig.sdk.service.TrackService = function() {};
com.fluig.sdk.service.TrackService.prototype = {};
com.fluig.sdk.service.TrainingService = function() {};
com.fluig.sdk.service.TrainingService.prototype = {};
com.fluig.sdk.service.UserService = function() {};
com.fluig.sdk.service.UserService.prototype = {};
com.fluig.sdk.service.WidgetService = function() {};
com.fluig.sdk.service.WidgetService.prototype = {};
com.fluig.sdk.service.WorkflowAPIService = function() {};
com.fluig.sdk.service.WorkflowAPIService.prototype = {};
com.fluig.sdk.tenant.AdminUserVO = function() {};
com.fluig.sdk.tenant.AdminUserVO.prototype = {};
com.fluig.sdk.tenant.TenantVO = function() {};
com.fluig.sdk.tenant.TenantVO.prototype = {};
com.fluig.sdk.user.ColleagueVO = function() {};
com.fluig.sdk.user.ColleagueVO.prototype = {};
com.fluig.sdk.user.UserPasswordVO = function() {};
com.fluig.sdk.user.UserPasswordVO.prototype = {};
com.fluig.sdk.user.UserVO = function() {};
com.fluig.sdk.user.UserVO.prototype = {};
/**
* Recupera o SecurityService
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.SecurityService} 
*/
fluigAPI.getSecurityService = function() {}
/**
* Recupera o LocalAPIService
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.LocalAPIService} 
*/
fluigAPI.getLocalService = function() {}
/**
* Recupera o HolidayAPIService
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.HolidayAPIService} 
*/
fluigAPI.getHolidayService = function() {}
/**
* Recupera o serviço para tratar Usuário
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.UserService} 
*/
fluigAPI.getUserService = function() {}
/**
* Recupera o serviço para tratar Grupo
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.GroupService} 
*/
fluigAPI.getGroupService = function() {}
/**
* Recupera o serviço para Tenant
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.TenantService} 
*/
fluigAPI.getTenantService = function() {}
/**
* Recupera o serviço para tratar Upload de arquivos
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.ContentFilesService} 
*/
fluigAPI.getContentFilesService = function() {}
/**
* Recupera o serviço para tratar Documentos
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.DocumentService} 
*/
fluigAPI.getDocumentService = function() {}
/**
* Recupera o serviço para tratar Pastas de documentos
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.FolderDocumentService} 
*/
fluigAPI.getFolderDocumentService = function() {}
/**
* Recupera o serviço para tratar Workflow
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.WorkflowAPIService} 
*/
fluigAPI.getWorkflowService = function() {}
/**
* Recupera o serviço para tratar Cards
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.CardService} 
*/
fluigAPI.getCardService = function() {}
/**
* Recupera o serviço para tratar Card Index
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.CardIndexService} 
*/
fluigAPI.getCardIndexService = function() {}
/**
* Recupera serviço para Jobs do agendador de tarefas
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.JobService} 
*/
fluigAPI.getJobService = function() {}
/**
* Recupera serviço para tratar paginas
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.PageService} 
*/
fluigAPI.getPageService = function() {}
/**
* 
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.PageWidgetService} 
*/
fluigAPI.getPageWidgetService = function() {}
/**
* 
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.DocumentationProxyServiceService} 
*/
fluigAPI.getHelpService = function() {}
/**
* Recupera serviço para tratar linguagem
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.I18NService} 
*/
fluigAPI.getI18NService = function() {}
/**
* Recupera serviço para tratar Post's
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.PostService} 
*/
fluigAPI.getPostService = function() {}
/**
* Recupera serviço para tratar Artigos
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.ArticleService} 
*/
fluigAPI.getArticleService = function() {}
/**
* Recupera serviço para tratar Breadcrumb do Social
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.SocialBreadcrumbService} 
*/
fluigAPI.getSocialBreadcrumbService = function() {}
/**
* Recupera serviço para tratar Comunidades
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.CommunityService} 
*/
fluigAPI.getCommunityService = function() {}
/**
* Recupera serviço para tratar parâmetros gerais
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.GlobalParameterService} 
*/
fluigAPI.getGlobalParameterService = function() {}
/**
* Recupera serviço para tratar Favoritos
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.FavoritesService} 
*/
fluigAPI.getFavoritesService = function() {}
/**
* Recupera serviço para tratar Tasks
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.TasksService} 
*/
fluigAPI.getTasksService = function() {}
/**
* 
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.CollaborationSDKService} 
*/
fluigAPI.getCollaborationService = function() {}
/**
* 
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.IdentityService} 
*/
fluigAPI.getIdentityService = function() {}
/**
* Recupera serviço para tratar Notificações
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.AlertService} 
*/
fluigAPI.getAlertService = function() {}
/**
* Recupera o AuthorizeClientService
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.AuthorizeClientSdkService} 
*/
fluigAPI.getAuthorizeClientService = function() {}
/**
* Recupera o servico de tagscloud
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.TagsCloudService} 
*/
fluigAPI.getTagsCloudService = function() {}
/**
* Recupera serviço para tratar Comment's
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.CommentService} 
*/
fluigAPI.getCommentService = function() {}
/**
* Recupera serviço para efetuar pesquisas
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.SearchService} 
*/
fluigAPI.getSearchService = function() {}
/**
* Recupera serviço do social
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.SocialSDKService} 
*/
fluigAPI.getSocialService = function() {}
/**
* Recupera o serviço de widgets
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.WidgetService} 
*/
fluigAPI.getWidgetService = function() {}
/**
* Recupera serviço para tratar Conteúdos do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.ContentService} 
*/
fluigAPI.getContentService = function() {}
/**
* Recupera serviço para tratar Aplicações de Avaliações do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.AssessmentApplicationService} 
*/
fluigAPI.getAssessmentApplicationService = function() {}
/**
* Recupera serviço para tratar Agendamento de Avaliações do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.AssessmentScheduleService} 
*/
fluigAPI.getAssessmentScheduleService = function() {}
/**
* Recupera serviço para tratar Disciplinas do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.DisciplineService} 
*/
fluigAPI.getDisciplineService = function() {}
/**
* Recupera serviço para tratar Disciplinas do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.EnrollmentService} 
*/
fluigAPI.getEnrollmentService = function() {}
/**
* Recupera serviço para tratar Disciplinas do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.EnrollmentRequestService} 
*/
fluigAPI.getEnrollmentRequestService = function() {}
/**
* Recupera serviço para tratar Pastas do Catálogo de Disciplinas do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.FolderDisciplineService} 
*/
fluigAPI.getFolderDisciplineService = function() {}
/**
* Recupera serviço para tratar Turmas do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.NormalClassService} 
*/
fluigAPI.getNormalClassService = function() {}
/**
* Recupera serviço para tratar Trilhas do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.TrackService} 
*/
fluigAPI.getTrackService = function() {}
/**
* Recupera serviço para tratar Treinamentos do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.TrainingService} 
*/
fluigAPI.getTrainingService = function() {}
/**
* Recupera serviço para tratar as habilidades
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.SkillService} 
*/
fluigAPI.getSkillService = function() {}
/**
* Recupera serviço para tratar Pastas do catálogo de trilhas e treinamentos do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.FolderService} 
*/
fluigAPI.getFolderService = function() {}
/**
* Recupera serviço para tratar Questões Objetivas do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.ObjectiveQuestionService} 
*/
fluigAPI.getObjectiveQuestionService = function() {}
/**
* Recupera serviço para tratar Blocos de Avaliações do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.BlockService} 
*/
fluigAPI.getBlockService = function() {}
/**
* Recupera serviço para tratar os Tópicos dos Tópicos e Questões do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.AssessmentTopicService} 
*/
fluigAPI.getAssessmentTopicService = function() {}
/**
* Recupera serviço para tratar as Questões Dissertativas do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.EssayQuestionService} 
*/
fluigAPI.getEssayQuestionService = function() {}
/**
* Recupera serviço para tratar as Questões Ordenadas do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.OrdinationQuestionService} 
*/
fluigAPI.getOrdinationQuestionService = function() {}
/**
* Recupera serviço para tratar as questões do tipo lacuna do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.LacunaQuestionService} 
*/
fluigAPI.getLacunaQuestionService = function() {}
/**
* Recupera serviço para tratar Questões Mútipla escolha do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.MultipleQuestionService} 
*/
fluigAPI.getMultipleQuestionService = function() {}
/**
* Recupera serviço para tratar Questões Correlação/Multivalorada do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.CorrelationQuestionService} 
*/
fluigAPI.getCorrelationQuestionService = function() {}
/**
* Recupera serviço para tratar Questões Escala/Valor do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.ScaleQuestionService} 
*/
fluigAPI.getScaleQuestionService = function() {}
/**
* Recupera serviço para tratar Avaliações do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.AssessmentService} 
*/
fluigAPI.getAssessmentService = function() {}
/**
* Recupera o serviço do Filter
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.FilterAPIService} 
*/
fluigAPI.getFilterService = function() {}
/**
* Recupera serviço para tratar Links do catálogo de trilhas e treinamentos do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.LinkService} 
*/
fluigAPI.getLinkService = function() {}
/**
* Recupera serviço para tratar Turmas do LMS
* @memberOf fluigAPI
* @returns {com.fluig.sdk.service.LMSTaskService} 
*/
fluigAPI.getLMSTaskService = function() {}
com.fluig.sdk.service.SecurityService.prototype = {
	/**
	* Verifica se o usuário logado possui certa permissão no recurso dado
	* @memberOf fluigAPI
	* @param {String} resource 
	* @param {String} permiss 
	* @returns {boolean} 
	*/
	"hasPermission": function(resource, permiss) {}, 
	/**
	* Lista os recursos da categoria informada
	* @memberOf fluigAPI
	* @param {String} category 
	* @param {String} filter 
	* @param {int} offset 
	* @param {int} limit 
	* @returns {List&lt;com.fluig.sdk.api.permission.PermissionAssetVO&gt;} 
	*/
	"listResourcesByCategory": function(category, filter, offset, limit) {}, 
	/**
	* Lista as permissões do recurso informado
	* @memberOf fluigAPI
	* @param {String} resourceCode 
	* @returns {List&lt;com.fluig.sdk.api.permission.PermissionVO&gt;} 
	*/
	"getPermissionsByResourceCode": function(resourceCode) {}, 
	/**
	* Cria as permissões para um determinado recurso
	* @memberOf fluigAPI
	* @param {String} resourceCode 
	* @param {List} permissions 
	*/
	"createPermissions": function(resourceCode, permissions) {}, 
	/**
	* Deleta as permissões para um determinado recurso
	* @memberOf fluigAPI
	* @param {String} resourceCode 
	* @param {List} permissions 
	*/
	"deletePermissions": function(resourceCode, permissions) {}, 
	/**
	* Retorna a lista de tentants
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.tenant.TenantVO&gt;} 
	*/
	"findTenants": function() {}, 
	/**
	* Retorna o tenantId logado
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCurrentTenantId": function() {}, 
	/**
	* Retorna o grupo por code e tenant
	* @memberOf fluigAPI
	* @param {long} tenantId 
	* @param {String} code 
	* @returns {com.fluig.sdk.api.group.GroupVO} 
	*/
	"findGroupByTenantIdAndCode": function(tenantId, code) {}, 
	/**
	* Cria um bjeto chave/valor no tenantData
	* @memberOf fluigAPI
	* @param {String} key 
	* @param {String} value 
	* @returns {boolean} 
	*/
	"createOrUpdateTenantData": function(key, value) {}, 
	/**
	* Retorna os admins de um tenant
	* @memberOf fluigAPI
	* @param {long} tenantId 
	* @returns {List&lt;com.fluig.sdk.tenant.AdminUserVO&gt;} 
	*/
	"listTenantAdmins": function(tenantId) {}, 
	/**
	* Change user password
	* @memberOf fluigAPI
	* @param {String} login 
	* @param {String} currentPassword 
	* @param {String} newPassword 
	* @param {String} confirmNewPassword 
	*/
	"changeUserPassword": function(login, currentPassword, newPassword, confirmNewPassword) {}, 
	/**
	* Get the current tenant
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.tenant.TenantVO} 
	*/
	"getCurrentTenant": function() {}
};
SecurityService.prototype = {
	/**
	* Verifica se o usuário logado possui certa permissão no recurso dado
	* @memberOf fluigAPI
	* @param {String} resource 
	* @param {String} permiss 
	* @returns {boolean} 
	*/
	"hasPermission": function(resource, permiss) {}, 
	/**
	* Lista os recursos da categoria informada
	* @memberOf fluigAPI
	* @param {String} category 
	* @param {String} filter 
	* @param {int} offset 
	* @param {int} limit 
	* @returns {List&lt;com.fluig.sdk.api.permission.PermissionAssetVO&gt;} 
	*/
	"listResourcesByCategory": function(category, filter, offset, limit) {}, 
	/**
	* Lista as permissões do recurso informado
	* @memberOf fluigAPI
	* @param {String} resourceCode 
	* @returns {List&lt;com.fluig.sdk.api.permission.PermissionVO&gt;} 
	*/
	"getPermissionsByResourceCode": function(resourceCode) {}, 
	/**
	* Cria as permissões para um determinado recurso
	* @memberOf fluigAPI
	* @param {String} resourceCode 
	* @param {List} permissions 
	*/
	"createPermissions": function(resourceCode, permissions) {}, 
	/**
	* Deleta as permissões para um determinado recurso
	* @memberOf fluigAPI
	* @param {String} resourceCode 
	* @param {List} permissions 
	*/
	"deletePermissions": function(resourceCode, permissions) {}, 
	/**
	* Retorna a lista de tentants
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.tenant.TenantVO&gt;} 
	*/
	"findTenants": function() {}, 
	/**
	* Retorna o tenantId logado
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCurrentTenantId": function() {}, 
	/**
	* Retorna o grupo por code e tenant
	* @memberOf fluigAPI
	* @param {long} tenantId 
	* @param {String} code 
	* @returns {com.fluig.sdk.api.group.GroupVO} 
	*/
	"findGroupByTenantIdAndCode": function(tenantId, code) {}, 
	/**
	* Cria um bjeto chave/valor no tenantData
	* @memberOf fluigAPI
	* @param {String} key 
	* @param {String} value 
	* @returns {boolean} 
	*/
	"createOrUpdateTenantData": function(key, value) {}, 
	/**
	* Retorna os admins de um tenant
	* @memberOf fluigAPI
	* @param {long} tenantId 
	* @returns {List&lt;com.fluig.sdk.tenant.AdminUserVO&gt;} 
	*/
	"listTenantAdmins": function(tenantId) {}, 
	/**
	* Change user password
	* @memberOf fluigAPI
	* @param {String} login 
	* @param {String} currentPassword 
	* @param {String} newPassword 
	* @param {String} confirmNewPassword 
	*/
	"changeUserPassword": function(login, currentPassword, newPassword, confirmNewPassword) {}, 
	/**
	* Get the current tenant
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.tenant.TenantVO} 
	*/
	"getCurrentTenant": function() {}
};
com.fluig.sdk.service.LocalAPIService.prototype = {
	/**
	* Cria localização
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.local.LocalVO} local 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"create": function(local) {}, 
	/**
	* Deleta localização
	* @memberOf fluigAPI
	* @param {String} id 
	*/
	"delete": function(id) {}, 
	/**
	* Deleta localização
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"delete": function(id) {}, 
	/**
	* Pesquisa todas localizações da empresa do usuário logado
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.local.LocalVO&gt;} 
	*/
	"findAll": function() {}, 
	/**
	* Pesquisa localização com id específico
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {boolean} populateLocalUsers 
	* @param {boolean} populateHolidays 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"find": function(id, populateLocalUsers, populateHolidays) {}, 
	/**
	* Pesquisa localização com id específico
	* @memberOf fluigAPI
	* @param {String} id 
	* @param {String} expand 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"find": function(id, expand) {}, 
	/**
	* Atualiza localização
	* @memberOf fluigAPI
	* @param {String} id 
	* @param {com.fluig.sdk.api.local.LocalVO} local 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"update": function(id, local) {}, 
	/**
	* Atualiza localização
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.local.LocalVO} local 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"update": function(local) {}, 
	/**
	* Atualiza parametros específicos da localização
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.local.LocalVO} local 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"patch": function(local) {}, 
	/**
	* Atualiza estado padrão da localização
	* @memberOf fluigAPI
	* @param {String} id 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"updateDefault": function(id) {}, 
	/**
	* Pesquisa por parametros localização
	* @memberOf fluigAPI
	* @param {String} name 
	* @param {String} order 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} expand 
	*/
	"find": function(name, order, page, pageSize, expand) {}, 
	/**
	* Pesquisa por parametros localização
	* @memberOf fluigAPI
	* @param {String} name 
	* @param {List} orderParams 
	* @param {int} page 
	* @param {int} pageSize 
	* @param {boolean} populateUsers 
	* @param {boolean} populateHolidays 
	*/
	"find": function(name, orderParams, page, pageSize, populateUsers, populateHolidays) {}, 
	/**
	* Pesquisa por parametros localização
	* @memberOf fluigAPI
	* @param {String} name 
	* @param {String} order 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} offset 
	* @param {String} limit 
	* @param {String} expand 
	*/
	"find": function(name, order, page, pageSize, offset, limit, expand) {}, 
	/**
	* Pesquisa por parametros localização
	* @memberOf fluigAPI
	* @param {String} name 
	* @param {List} orderParams 
	* @param {int} page 
	* @param {int} pageSize 
	* @param {int} offset 
	* @param {int} limit 
	* @param {boolean} populateUsers 
	* @param {boolean} populateHolidays 
	*/
	"find": function(name, orderParams, page, pageSize, offset, limit, populateUsers, populateHolidays) {}, 
	/**
	* Pesquisa por relações entre usuários e localizações
	* @memberOf fluigAPI
	* @param {String} localId 
	* @param {String} name 
	* @param {String} order 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} offset 
	* @param {String} limit 
	*/
	"findUsers": function(localId, name, order, page, pageSize, offset, limit) {}, 
	/**
	* Pesquisa por relações entre usuários e localizações
	* @memberOf fluigAPI
	* @param {long} localId 
	* @param {String} name 
	* @param {List} orderParams 
	* @param {int} page 
	* @param {int} pageSize 
	* @param {int} offset 
	* @param {int} limit 
	*/
	"findUsers": function(localId, name, orderParams, page, pageSize, offset, limit) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {com.fluig.sdk.api.local.LocalUserVO} localUserVO 
	* @returns {com.fluig.sdk.api.local.LocalUserVO} 
	*/
	"createLocalUser": function(id, localUserVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} id 
	* @param {com.fluig.sdk.api.local.LocalUserVO} localUserVO 
	* @returns {com.fluig.sdk.api.local.LocalUserVO} 
	*/
	"createLocalUser": function(id, localUserVO) {}, 
	/**
	* Pesquisa por usuários sem relações com qualquer local
	* @memberOf fluigAPI
	* @param {String} id 
	* @param {String} name 
	* @param {String} order 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} offset 
	* @param {String} limit 
	*/
	"findUnrelatedUsers": function(id, name, order, page, pageSize, offset, limit) {}, 
	/**
	* Pesquisa por usuários sem relações com qualquer local
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {String} name 
	* @param {List} orderParams 
	* @param {int} page 
	* @param {int} pageSize 
	* @param {int} offset 
	* @param {int} limit 
	*/
	"findUnrelatedUsers": function(id, name, orderParams, page, pageSize, offset, limit) {}, 
	/**
	* Deleta localização
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {String} userCode 
	*/
	"deleteLocalUser": function(id, userCode) {}, 
	/**
	* Deleta localização
	* @memberOf fluigAPI
	* @param {String} id 
	* @param {String} userCode 
	*/
	"deleteLocalUser": function(id, userCode) {}, 
	/**
	* Procura pelo local do usuário
	* @memberOf fluigAPI
	* @param {String} userCode 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"findByUser": function(userCode) {}, 
	/**
	* Procura pelo local do usuário
	* @memberOf fluigAPI
	* @param {String} userCode 
	* @param {String} expand 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"findByUser": function(userCode, expand) {}, 
	/**
	* Atualiza parametros específicos da localização
	* @memberOf fluigAPI
	* @param {String} id 
	* @param {com.fluig.sdk.api.local.LocalVO} local 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"patch": function(id, local) {}, 
	/**
	* Deleta o vínculo do feriado ao local
	* @memberOf fluigAPI
	* @param {String} id 
	* @param {String} holidayId 
	*/
	"deleteLocalHoliday": function(id, holidayId) {}, 
	/**
	* Deleta o vínculo do feriado ao local
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {long} holidayId 
	*/
	"deleteHoliday": function(id, holidayId) {}, 
	/**
	* Busca o timezone pela latitude e longitude informada
	* @memberOf fluigAPI
	* @param {String} latitude 
	* @param {String} longitude 
	* @returns {String} 
	*/
	"getTimezone": function(latitude, longitude) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} localId 
	* @param {String} group 
	* @returns {List&lt;com.fluig.sdk.api.local.LocalUserVO&gt;} 
	*/
	"createLocalUserByGroup": function(localId, group) {}
};
LocalAPIService.prototype = {
	/**
	* Cria localização
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.local.LocalVO} local 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"create": function(local) {}, 
	/**
	* Deleta localização
	* @memberOf fluigAPI
	* @param {String} id 
	*/
	"delete": function(id) {}, 
	/**
	* Deleta localização
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"delete": function(id) {}, 
	/**
	* Pesquisa todas localizações da empresa do usuário logado
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.local.LocalVO&gt;} 
	*/
	"findAll": function() {}, 
	/**
	* Pesquisa localização com id específico
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {boolean} populateLocalUsers 
	* @param {boolean} populateHolidays 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"find": function(id, populateLocalUsers, populateHolidays) {}, 
	/**
	* Pesquisa localização com id específico
	* @memberOf fluigAPI
	* @param {String} id 
	* @param {String} expand 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"find": function(id, expand) {}, 
	/**
	* Atualiza localização
	* @memberOf fluigAPI
	* @param {String} id 
	* @param {com.fluig.sdk.api.local.LocalVO} local 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"update": function(id, local) {}, 
	/**
	* Atualiza localização
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.local.LocalVO} local 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"update": function(local) {}, 
	/**
	* Atualiza parametros específicos da localização
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.local.LocalVO} local 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"patch": function(local) {}, 
	/**
	* Atualiza estado padrão da localização
	* @memberOf fluigAPI
	* @param {String} id 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"updateDefault": function(id) {}, 
	/**
	* Pesquisa por parametros localização
	* @memberOf fluigAPI
	* @param {String} name 
	* @param {String} order 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} expand 
	*/
	"find": function(name, order, page, pageSize, expand) {}, 
	/**
	* Pesquisa por parametros localização
	* @memberOf fluigAPI
	* @param {String} name 
	* @param {List} orderParams 
	* @param {int} page 
	* @param {int} pageSize 
	* @param {boolean} populateUsers 
	* @param {boolean} populateHolidays 
	*/
	"find": function(name, orderParams, page, pageSize, populateUsers, populateHolidays) {}, 
	/**
	* Pesquisa por parametros localização
	* @memberOf fluigAPI
	* @param {String} name 
	* @param {String} order 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} offset 
	* @param {String} limit 
	* @param {String} expand 
	*/
	"find": function(name, order, page, pageSize, offset, limit, expand) {}, 
	/**
	* Pesquisa por parametros localização
	* @memberOf fluigAPI
	* @param {String} name 
	* @param {List} orderParams 
	* @param {int} page 
	* @param {int} pageSize 
	* @param {int} offset 
	* @param {int} limit 
	* @param {boolean} populateUsers 
	* @param {boolean} populateHolidays 
	*/
	"find": function(name, orderParams, page, pageSize, offset, limit, populateUsers, populateHolidays) {}, 
	/**
	* Pesquisa por relações entre usuários e localizações
	* @memberOf fluigAPI
	* @param {String} localId 
	* @param {String} name 
	* @param {String} order 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} offset 
	* @param {String} limit 
	*/
	"findUsers": function(localId, name, order, page, pageSize, offset, limit) {}, 
	/**
	* Pesquisa por relações entre usuários e localizações
	* @memberOf fluigAPI
	* @param {long} localId 
	* @param {String} name 
	* @param {List} orderParams 
	* @param {int} page 
	* @param {int} pageSize 
	* @param {int} offset 
	* @param {int} limit 
	*/
	"findUsers": function(localId, name, orderParams, page, pageSize, offset, limit) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {com.fluig.sdk.api.local.LocalUserVO} localUserVO 
	* @returns {com.fluig.sdk.api.local.LocalUserVO} 
	*/
	"createLocalUser": function(id, localUserVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} id 
	* @param {com.fluig.sdk.api.local.LocalUserVO} localUserVO 
	* @returns {com.fluig.sdk.api.local.LocalUserVO} 
	*/
	"createLocalUser": function(id, localUserVO) {}, 
	/**
	* Pesquisa por usuários sem relações com qualquer local
	* @memberOf fluigAPI
	* @param {String} id 
	* @param {String} name 
	* @param {String} order 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} offset 
	* @param {String} limit 
	*/
	"findUnrelatedUsers": function(id, name, order, page, pageSize, offset, limit) {}, 
	/**
	* Pesquisa por usuários sem relações com qualquer local
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {String} name 
	* @param {List} orderParams 
	* @param {int} page 
	* @param {int} pageSize 
	* @param {int} offset 
	* @param {int} limit 
	*/
	"findUnrelatedUsers": function(id, name, orderParams, page, pageSize, offset, limit) {}, 
	/**
	* Deleta localização
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {String} userCode 
	*/
	"deleteLocalUser": function(id, userCode) {}, 
	/**
	* Deleta localização
	* @memberOf fluigAPI
	* @param {String} id 
	* @param {String} userCode 
	*/
	"deleteLocalUser": function(id, userCode) {}, 
	/**
	* Procura pelo local do usuário
	* @memberOf fluigAPI
	* @param {String} userCode 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"findByUser": function(userCode) {}, 
	/**
	* Procura pelo local do usuário
	* @memberOf fluigAPI
	* @param {String} userCode 
	* @param {String} expand 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"findByUser": function(userCode, expand) {}, 
	/**
	* Atualiza parametros específicos da localização
	* @memberOf fluigAPI
	* @param {String} id 
	* @param {com.fluig.sdk.api.local.LocalVO} local 
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"patch": function(id, local) {}, 
	/**
	* Deleta o vínculo do feriado ao local
	* @memberOf fluigAPI
	* @param {String} id 
	* @param {String} holidayId 
	*/
	"deleteLocalHoliday": function(id, holidayId) {}, 
	/**
	* Deleta o vínculo do feriado ao local
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {long} holidayId 
	*/
	"deleteHoliday": function(id, holidayId) {}, 
	/**
	* Busca o timezone pela latitude e longitude informada
	* @memberOf fluigAPI
	* @param {String} latitude 
	* @param {String} longitude 
	* @returns {String} 
	*/
	"getTimezone": function(latitude, longitude) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} localId 
	* @param {String} group 
	* @returns {List&lt;com.fluig.sdk.api.local.LocalUserVO&gt;} 
	*/
	"createLocalUserByGroup": function(localId, group) {}
};
com.fluig.sdk.service.HolidayAPIService.prototype = {
	/**
	* Cria feriado
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.holiday.HolidayVO} holidayVO 
	* @returns {com.fluig.sdk.api.holiday.HolidayVO} 
	*/
	"create": function(holidayVO) {}, 
	/**
	* Deleta feriado
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"delete": function(id) {}, 
	/**
	* Atualiza feriado
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {com.fluig.sdk.api.holiday.HolidayVO} holidayVO 
	* @returns {com.fluig.sdk.api.holiday.HolidayVO} 
	*/
	"update": function(id, holidayVO) {}, 
	/**
	* Busca feriado
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {String} expand 
	* @returns {com.fluig.sdk.api.holiday.HolidayVO} 
	*/
	"find": function(id, expand) {}, 
	/**
	* Busca todos os feriados da base a partir do código da empresa do usuário logado
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.holiday.HolidayVO&gt;} 
	*/
	"findAll": function() {}, 
	/**
	* Atualiza feriado
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {com.fluig.sdk.api.holiday.HolidayVO} holidayVO 
	* @returns {com.fluig.sdk.api.holiday.HolidayVO} 
	*/
	"patch": function(id, holidayVO) {}, 
	/**
	* Busca feriado
	* @memberOf fluigAPI
	* @param {String} description 
	* @param {String} localId 
	* @param {String} order 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} offset 
	* @param {String} limit 
	* @param {String} expand 
	* @param {String} exclusive 
	*/
	"find": function(description, localId, order, page, pageSize, offset, limit, expand, exclusive) {}, 
	/**
	* Busca feriado
	* @memberOf fluigAPI
	* @param {String} description 
	* @param {long} localId 
	* @param {List} orderParams 
	* @param {int} page 
	* @param {int} pageSize 
	* @param {int} offset 
	* @param {int} limit 
	* @param {boolean} populateLocals 
	* @param {boolean} populateUsers 
	* @param {boolean} exclusive 
	*/
	"find": function(description, localId, orderParams, page, pageSize, offset, limit, populateLocals, populateUsers, exclusive) {}
};
HolidayAPIService.prototype = {
	/**
	* Cria feriado
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.holiday.HolidayVO} holidayVO 
	* @returns {com.fluig.sdk.api.holiday.HolidayVO} 
	*/
	"create": function(holidayVO) {}, 
	/**
	* Deleta feriado
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"delete": function(id) {}, 
	/**
	* Atualiza feriado
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {com.fluig.sdk.api.holiday.HolidayVO} holidayVO 
	* @returns {com.fluig.sdk.api.holiday.HolidayVO} 
	*/
	"update": function(id, holidayVO) {}, 
	/**
	* Busca feriado
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {String} expand 
	* @returns {com.fluig.sdk.api.holiday.HolidayVO} 
	*/
	"find": function(id, expand) {}, 
	/**
	* Busca todos os feriados da base a partir do código da empresa do usuário logado
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.holiday.HolidayVO&gt;} 
	*/
	"findAll": function() {}, 
	/**
	* Atualiza feriado
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {com.fluig.sdk.api.holiday.HolidayVO} holidayVO 
	* @returns {com.fluig.sdk.api.holiday.HolidayVO} 
	*/
	"patch": function(id, holidayVO) {}, 
	/**
	* Busca feriado
	* @memberOf fluigAPI
	* @param {String} description 
	* @param {String} localId 
	* @param {String} order 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} offset 
	* @param {String} limit 
	* @param {String} expand 
	* @param {String} exclusive 
	*/
	"find": function(description, localId, order, page, pageSize, offset, limit, expand, exclusive) {}, 
	/**
	* Busca feriado
	* @memberOf fluigAPI
	* @param {String} description 
	* @param {long} localId 
	* @param {List} orderParams 
	* @param {int} page 
	* @param {int} pageSize 
	* @param {int} offset 
	* @param {int} limit 
	* @param {boolean} populateLocals 
	* @param {boolean} populateUsers 
	* @param {boolean} exclusive 
	*/
	"find": function(description, localId, orderParams, page, pageSize, offset, limit, populateLocals, populateUsers, exclusive) {}
};
com.fluig.sdk.service.UserService.prototype = {
	/**
	* Cria um novo usuário
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.user.UserVO} vo 
	* @returns {com.fluig.sdk.user.UserVO} 
	*/
	"create": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	* @param {com.fluig.sdk.user.UserVO} vo 
	* @returns {com.fluig.sdk.user.UserVO} 
	*/
	"create": function(tenantId, vo) {}, 
	/**
	* Retorna o usuário corrente logado
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.user.UserVO} 
	*/
	"getCurrent": function() {}, 
	/**
	* Retorna o usuário pelo id
	* @memberOf fluigAPI
	* @param {long} id 
	* @returns {com.fluig.sdk.user.UserVO} 
	*/
	"findById": function(id) {}, 
	/**
	* Pesquisa por usuários baseado em um conjunto de parâmetros. Os valores aceitos como parametros são: - login Parte do login. - fullName Parte do nome. - limit: Número máximo de registros para retornar
	* @memberOf fluigAPI
	* @param {Map} params 
	* @param {int} offset 
	* @param {int} limit 
	* @returns {List&lt;com.fluig.sdk.user.UserVO&gt;} 
	*/
	"list": function(params, offset, limit) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} offset 
	* @param {int} limit 
	* @returns {List&lt;com.fluig.sdk.user.UserVO&gt;} 
	*/
	"list": function(offset, limit) {}, 
	/**
	* Pesquisa por usuários ativos e inativos baseado em um conjunto de parâmetros. Os valores aceitos como parametros são: - login Parte do login. - fullName Parte do nome. - sortField: Campos. - sortType: ASC e DESC. - limit: Número máximo de registros para retornar. - offset: offSet. - search: Valor a ser procurado
	* @memberOf fluigAPI
	* @param {String} sortField 
	* @param {String} sortType 
	* @param {int} limit 
	* @param {int} offset 
	* @param {String} search 
	* @returns {List&lt;com.fluig.sdk.user.UserVO&gt;} 
	*/
	"listAll": function(sortField, sortType, limit, offset, search) {}, 
	/**
	* Deactivate an user by his login, idpId or userCode
	* @memberOf fluigAPI
	* @param {String} genericId 
	*/
	"deactivateByCode": function(genericId) {}, 
	/**
	* Activate an user by his login, idpId or userCode
	* @memberOf fluigAPI
	* @param {String} genericId 
	*/
	"activateByCode": function(genericId) {}, 
	/**
	* UPDATE user. Basic informations: name lastName fullName timezone locale phone field
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.user.UserVO} vo 
	* @returns {com.fluig.sdk.user.UserVO} 
	*/
	"updateUser": function(vo) {}, 
	/**
	* UPDATE user data of logged user
	* @memberOf fluigAPI
	* @param {Map} data 
	* @returns {boolean} 
	*/
	"updateUserData": function(data) {}, 
	/**
	* Change the user password
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.user.UserPasswordVO} vo 
	*/
	"changeUserPassword": function(vo) {}, 
	/**
	* Pesquisa por usuários baseado em um conjunto de parâmetros. Os valores aceitos como parametros são: - login Parte do login. - fullName Parte do nome. - sortField: Campos. - sortType: ASC e DESC. - limit: Número máximo de registros para retornar. - offset: offSet. - search: Valor a ser procurado
	* @memberOf fluigAPI
	* @param {String} sortField 
	* @param {String} sortType 
	* @param {int} limit 
	* @param {int} offset 
	* @param {String} search 
	* @returns {List&lt;com.fluig.sdk.user.UserVO&gt;} 
	*/
	"list": function(sortField, sortType, limit, offset, search) {}, 
	/**
	* GET user by the generic id
	* @memberOf fluigAPI
	* @param {String} genericId 
	* @returns {com.fluig.sdk.user.UserVO} 
	*/
	"getUser": function(genericId) {}, 
	/**
	* List user roles specfying the login
	* @memberOf fluigAPI
	* @param {String} login 
	* @returns {List&lt;String&gt;} 
	*/
	"listRoles": function(login) {}, 
	/**
	* List all user data specfying the login
	* @memberOf fluigAPI
	* @param {String} login 
	* @returns {Map&lt;String,String&gt;} 
	*/
	"listData": function(login) {}, 
	/**
	* list the groups from a specific user
	* @memberOf fluigAPI
	* @param {String} login 
	* @returns {List&lt;String&gt;} 
	*/
	"listGroups": function(login) {}, 
	/**
	* UPDATE the user data
	* @memberOf fluigAPI
	* @param {Map} data 
	* @param {long} userId 
	* @returns {boolean} 
	*/
	"updateUserDataById": function(data, userId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} alias 
	* @param {String} key 
	*/
	"removeUserData": function(alias, key) {}, 
	/**
	* ADD user to a specific group
	* @memberOf fluigAPI
	* @param {long} tenantId 
	* @param {String} groupCode 
	* @param {com.fluig.sdk.user.UserVO} userVO 
	*/
	"addUserToGroup": function(tenantId, groupCode, userVO) {}, 
	/**
	* UPDATE the user information even one that is disabled
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.user.UserVO} vo 
	* @returns {com.fluig.sdk.user.UserVO} 
	*/
	"updateUserEvenDisabled": function(vo) {}
};
UserService.prototype = {
	/**
	* Cria um novo usuário
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.user.UserVO} vo 
	* @returns {com.fluig.sdk.user.UserVO} 
	*/
	"create": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	* @param {com.fluig.sdk.user.UserVO} vo 
	* @returns {com.fluig.sdk.user.UserVO} 
	*/
	"create": function(tenantId, vo) {}, 
	/**
	* Retorna o usuário corrente logado
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.user.UserVO} 
	*/
	"getCurrent": function() {}, 
	/**
	* Retorna o usuário pelo id
	* @memberOf fluigAPI
	* @param {long} id 
	* @returns {com.fluig.sdk.user.UserVO} 
	*/
	"findById": function(id) {}, 
	/**
	* Pesquisa por usuários baseado em um conjunto de parâmetros. Os valores aceitos como parametros são: - login Parte do login. - fullName Parte do nome. - limit: Número máximo de registros para retornar
	* @memberOf fluigAPI
	* @param {Map} params 
	* @param {int} offset 
	* @param {int} limit 
	* @returns {List&lt;com.fluig.sdk.user.UserVO&gt;} 
	*/
	"list": function(params, offset, limit) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} offset 
	* @param {int} limit 
	* @returns {List&lt;com.fluig.sdk.user.UserVO&gt;} 
	*/
	"list": function(offset, limit) {}, 
	/**
	* Pesquisa por usuários ativos e inativos baseado em um conjunto de parâmetros. Os valores aceitos como parametros são: - login Parte do login. - fullName Parte do nome. - sortField: Campos. - sortType: ASC e DESC. - limit: Número máximo de registros para retornar. - offset: offSet. - search: Valor a ser procurado
	* @memberOf fluigAPI
	* @param {String} sortField 
	* @param {String} sortType 
	* @param {int} limit 
	* @param {int} offset 
	* @param {String} search 
	* @returns {List&lt;com.fluig.sdk.user.UserVO&gt;} 
	*/
	"listAll": function(sortField, sortType, limit, offset, search) {}, 
	/**
	* Deactivate an user by his login, idpId or userCode
	* @memberOf fluigAPI
	* @param {String} genericId 
	*/
	"deactivateByCode": function(genericId) {}, 
	/**
	* Activate an user by his login, idpId or userCode
	* @memberOf fluigAPI
	* @param {String} genericId 
	*/
	"activateByCode": function(genericId) {}, 
	/**
	* UPDATE user. Basic informations: name lastName fullName timezone locale phone field
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.user.UserVO} vo 
	* @returns {com.fluig.sdk.user.UserVO} 
	*/
	"updateUser": function(vo) {}, 
	/**
	* UPDATE user data of logged user
	* @memberOf fluigAPI
	* @param {Map} data 
	* @returns {boolean} 
	*/
	"updateUserData": function(data) {}, 
	/**
	* Change the user password
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.user.UserPasswordVO} vo 
	*/
	"changeUserPassword": function(vo) {}, 
	/**
	* Pesquisa por usuários baseado em um conjunto de parâmetros. Os valores aceitos como parametros são: - login Parte do login. - fullName Parte do nome. - sortField: Campos. - sortType: ASC e DESC. - limit: Número máximo de registros para retornar. - offset: offSet. - search: Valor a ser procurado
	* @memberOf fluigAPI
	* @param {String} sortField 
	* @param {String} sortType 
	* @param {int} limit 
	* @param {int} offset 
	* @param {String} search 
	* @returns {List&lt;com.fluig.sdk.user.UserVO&gt;} 
	*/
	"list": function(sortField, sortType, limit, offset, search) {}, 
	/**
	* GET user by the generic id
	* @memberOf fluigAPI
	* @param {String} genericId 
	* @returns {com.fluig.sdk.user.UserVO} 
	*/
	"getUser": function(genericId) {}, 
	/**
	* List user roles specfying the login
	* @memberOf fluigAPI
	* @param {String} login 
	* @returns {List&lt;String&gt;} 
	*/
	"listRoles": function(login) {}, 
	/**
	* List all user data specfying the login
	* @memberOf fluigAPI
	* @param {String} login 
	* @returns {Map&lt;String,String&gt;} 
	*/
	"listData": function(login) {}, 
	/**
	* list the groups from a specific user
	* @memberOf fluigAPI
	* @param {String} login 
	* @returns {List&lt;String&gt;} 
	*/
	"listGroups": function(login) {}, 
	/**
	* UPDATE the user data
	* @memberOf fluigAPI
	* @param {Map} data 
	* @param {long} userId 
	* @returns {boolean} 
	*/
	"updateUserDataById": function(data, userId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} alias 
	* @param {String} key 
	*/
	"removeUserData": function(alias, key) {}, 
	/**
	* ADD user to a specific group
	* @memberOf fluigAPI
	* @param {long} tenantId 
	* @param {String} groupCode 
	* @param {com.fluig.sdk.user.UserVO} userVO 
	*/
	"addUserToGroup": function(tenantId, groupCode, userVO) {}, 
	/**
	* UPDATE the user information even one that is disabled
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.user.UserVO} vo 
	* @returns {com.fluig.sdk.user.UserVO} 
	*/
	"updateUserEvenDisabled": function(vo) {}
};
com.fluig.sdk.service.GroupService.prototype = {
	/**
	* Cria um novo grupo
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.group.GroupVO} vo 
	* @returns {com.fluig.sdk.api.group.GroupVO} 
	*/
	"create": function(vo) {}, 
	/**
	* Verifica se o usuário pertence ao grupo
	* @memberOf fluigAPI
	* @param {String} groupCode 
	* @param {String} genericId 
	* @returns {boolean} 
	*/
	"containsUser": function(groupCode, genericId) {}, 
	/**
	* Adiciona um usuário ao grupo
	* @memberOf fluigAPI
	* @param {String} groupCode 
	* @param {List} logins 
	*/
	"addUsers": function(groupCode, logins) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	* @param {String} groupCode 
	* @param {List} logins 
	*/
	"addUsers": function(tenantId, groupCode, logins) {}, 
	/**
	* Remove um usuário do grupo
	* @memberOf fluigAPI
	* @param {long} tenantId 
	* @param {String} groupCode 
	* @param {String} alias 
	*/
	"removeUser": function(tenantId, groupCode, alias) {}, 
	/**
	* Retorna usuários por grupo
	* @memberOf fluigAPI
	* @param {String} groupId 
	* @param {String} pattern 
	* @param {int} limit 
	* @param {int} offset 
	* @param {String} order 
	* @returns {List&lt;com.fluig.sdk.user.ColleagueVO&gt;} 
	*/
	"findUsersByGroup": function(groupId, pattern, limit, offset, order) {}, 
	/**
	* Retorna grupo por usuário
	* @memberOf fluigAPI
	* @param {String} genericId 
	* @param {String} pattern 
	* @returns {List&lt;com.fluig.sdk.api.group.GroupVO&gt;} 
	*/
	"findGroupsByUser": function(genericId, pattern) {}, 
	/**
	* Create grupo
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.group.GroupVO} vo 
	* @param {long} tenantId 
	* @returns {com.fluig.sdk.api.group.GroupVO} 
	*/
	"create": function(vo, tenantId) {}
};
GroupService.prototype = {
	/**
	* Cria um novo grupo
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.group.GroupVO} vo 
	* @returns {com.fluig.sdk.api.group.GroupVO} 
	*/
	"create": function(vo) {}, 
	/**
	* Verifica se o usuário pertence ao grupo
	* @memberOf fluigAPI
	* @param {String} groupCode 
	* @param {String} genericId 
	* @returns {boolean} 
	*/
	"containsUser": function(groupCode, genericId) {}, 
	/**
	* Adiciona um usuário ao grupo
	* @memberOf fluigAPI
	* @param {String} groupCode 
	* @param {List} logins 
	*/
	"addUsers": function(groupCode, logins) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	* @param {String} groupCode 
	* @param {List} logins 
	*/
	"addUsers": function(tenantId, groupCode, logins) {}, 
	/**
	* Remove um usuário do grupo
	* @memberOf fluigAPI
	* @param {long} tenantId 
	* @param {String} groupCode 
	* @param {String} alias 
	*/
	"removeUser": function(tenantId, groupCode, alias) {}, 
	/**
	* Retorna usuários por grupo
	* @memberOf fluigAPI
	* @param {String} groupId 
	* @param {String} pattern 
	* @param {int} limit 
	* @param {int} offset 
	* @param {String} order 
	* @returns {List&lt;com.fluig.sdk.user.ColleagueVO&gt;} 
	*/
	"findUsersByGroup": function(groupId, pattern, limit, offset, order) {}, 
	/**
	* Retorna grupo por usuário
	* @memberOf fluigAPI
	* @param {String} genericId 
	* @param {String} pattern 
	* @returns {List&lt;com.fluig.sdk.api.group.GroupVO&gt;} 
	*/
	"findGroupsByUser": function(genericId, pattern) {}, 
	/**
	* Create grupo
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.group.GroupVO} vo 
	* @param {long} tenantId 
	* @returns {com.fluig.sdk.api.group.GroupVO} 
	*/
	"create": function(vo, tenantId) {}
};
com.fluig.sdk.service.TenantService.prototype = {
	/**
	* Cria um novo tenante
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.tenant.TenantVO} vo 
	* @returns {com.fluig.sdk.tenant.TenantVO} 
	*/
	"create": function(vo) {}, 
	/**
	* Retorna, caso houver, objeto chaves/valores do tenantData
	* @memberOf fluigAPI
	* @param {String[]} keys 
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getTenantData": function(keys) {}
};
TenantService.prototype = {
	/**
	* Cria um novo tenante
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.tenant.TenantVO} vo 
	* @returns {com.fluig.sdk.tenant.TenantVO} 
	*/
	"create": function(vo) {}, 
	/**
	* Retorna, caso houver, objeto chaves/valores do tenantData
	* @memberOf fluigAPI
	* @param {String[]} keys 
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getTenantData": function(keys) {}
};
com.fluig.sdk.service.ContentFilesService.prototype = {
	/**
	* Executa o upload de um arquivo
	* @memberOf fluigAPI
	* @param {String} fileName 
	* @param {byte[]} fileContent 
	*/
	"upload": function(fileName, fileContent) {}, 
	/**
	* Recupera diretório do artefato a ser implantado
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDeployableArtifactsDirectory": function() {}
};
ContentFilesService.prototype = {
	/**
	* Executa o upload de um arquivo
	* @memberOf fluigAPI
	* @param {String} fileName 
	* @param {byte[]} fileContent 
	*/
	"upload": function(fileName, fileContent) {}, 
	/**
	* Recupera diretório do artefato a ser implantado
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDeployableArtifactsDirectory": function() {}
};
com.fluig.sdk.service.DocumentService.prototype = {
	/**
	* Retorna o documento ativo passado o ID do mesmo
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @returns {com.fluig.sdk.api.document.DocumentVO} 
	*/
	"getActive": function(documentId) {}, 
	/**
	* Retorna a permissão do usuário em um documento
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @param {int} version 
	* @param {String} user 
	* @returns {int} 
	*/
	"getUserPermissions": function(documentId, version, user) {}, 
	/**
	* Cria uma documento privado
	* @memberOf fluigAPI
	* @param {long} companyId 
	* @param {String} userId 
	* @param {String} fileName 
	* @param {String} filePath 
	* @returns {com.fluig.sdk.api.document.DocumentVO} 
	*/
	"createPrivateDocument": function(companyId, userId, fileName, filePath) {}, 
	/**
	* Cria uma documento privado
	* @memberOf fluigAPI
	* @param {long} companyId 
	* @param {String} userId 
	* @param {String} fileName 
	* @param  file 
	* @returns {com.fluig.sdk.api.document.DocumentVO} 
	*/
	"createPrivateDocument": function(companyId, userId, fileName, file) {}, 
	/**
	* Retorna documento com as informações de checkout
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @param {int} version 
	* @returns {com.fluig.sdk.api.document.AllocatedDocumentVO} 
	*/
	"getAllocatedDocument": function(documentId, version) {}, 
	/**
	* Retorna a url do documento
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @returns {String} 
	*/
	"getDownloadURL": function(documentId) {}, 
	/**
	* Cria o documento com permissões e aprovadors
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.document.DocumentVO} documentVO 
	* @returns {com.fluig.sdk.api.document.DocumentVO} 
	*/
	"createDocument": function(documentVO) {}, 
	/**
	* Remove o documento
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"deleteDocument": function(documentId) {}, 
	/**
	* Copia o documento que esta na área de uplaod
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @returns {String[]} 
	*/
	"copyDocumentToUploadArea": function(documentId) {}, 
	/**
	* Determina as permissões do documento
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @param {List} permissions 
	*/
	"setDocumentPermissions": function(documentId, permissions) {}, 
	/**
	* Retorna as permissões do documento
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @param {int} version 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentPermissionVO&gt;} 
	*/
	"getDocumentPermissions": function(documentId, version) {}, 
	/**
	* Aprova ou reprova um documento
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @param {int} version 
	* @param {boolean} approved 
	* @param {String} observation 
	*/
	"approveDocument": function(documentId, version, approved, observation) {}, 
	/**
	* Retrieve all document approvers and yours status
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentApproverVO&gt;} 
	*/
	"getDocumentApprovers": function(documentId) {}, 
	/**
	* Update file
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.document.DocumentVO} docVO 
	* @returns {com.fluig.sdk.api.document.DocumentVO} 
	*/
	"updateFile": function(docVO) {}, 
	/**
	* Set Approvers for a specific document
	* @memberOf fluigAPI
	* @param {long} companyId 
	* @param {com.fluig.sdk.api.document.DocumentSecurityVO} documentSecurityVO 
	*/
	"setDocumentApprovers": function(companyId, documentSecurityVO) {}, 
	/**
	* Return the approvements history of the document
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentApprovementHistoryVO&gt;} 
	*/
	"getDocumentApprovalHistory": function(documentId) {}
};
DocumentService.prototype = {
	/**
	* Retorna o documento ativo passado o ID do mesmo
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @returns {com.fluig.sdk.api.document.DocumentVO} 
	*/
	"getActive": function(documentId) {}, 
	/**
	* Retorna a permissão do usuário em um documento
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @param {int} version 
	* @param {String} user 
	* @returns {int} 
	*/
	"getUserPermissions": function(documentId, version, user) {}, 
	/**
	* Cria uma documento privado
	* @memberOf fluigAPI
	* @param {long} companyId 
	* @param {String} userId 
	* @param {String} fileName 
	* @param {String} filePath 
	* @returns {com.fluig.sdk.api.document.DocumentVO} 
	*/
	"createPrivateDocument": function(companyId, userId, fileName, filePath) {}, 
	/**
	* Cria uma documento privado
	* @memberOf fluigAPI
	* @param {long} companyId 
	* @param {String} userId 
	* @param {String} fileName 
	* @param  file 
	* @returns {com.fluig.sdk.api.document.DocumentVO} 
	*/
	"createPrivateDocument": function(companyId, userId, fileName, file) {}, 
	/**
	* Retorna documento com as informações de checkout
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @param {int} version 
	* @returns {com.fluig.sdk.api.document.AllocatedDocumentVO} 
	*/
	"getAllocatedDocument": function(documentId, version) {}, 
	/**
	* Retorna a url do documento
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @returns {String} 
	*/
	"getDownloadURL": function(documentId) {}, 
	/**
	* Cria o documento com permissões e aprovadors
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.document.DocumentVO} documentVO 
	* @returns {com.fluig.sdk.api.document.DocumentVO} 
	*/
	"createDocument": function(documentVO) {}, 
	/**
	* Remove o documento
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"deleteDocument": function(documentId) {}, 
	/**
	* Copia o documento que esta na área de uplaod
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @returns {String[]} 
	*/
	"copyDocumentToUploadArea": function(documentId) {}, 
	/**
	* Determina as permissões do documento
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @param {List} permissions 
	*/
	"setDocumentPermissions": function(documentId, permissions) {}, 
	/**
	* Retorna as permissões do documento
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @param {int} version 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentPermissionVO&gt;} 
	*/
	"getDocumentPermissions": function(documentId, version) {}, 
	/**
	* Aprova ou reprova um documento
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @param {int} version 
	* @param {boolean} approved 
	* @param {String} observation 
	*/
	"approveDocument": function(documentId, version, approved, observation) {}, 
	/**
	* Retrieve all document approvers and yours status
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentApproverVO&gt;} 
	*/
	"getDocumentApprovers": function(documentId) {}, 
	/**
	* Update file
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.document.DocumentVO} docVO 
	* @returns {com.fluig.sdk.api.document.DocumentVO} 
	*/
	"updateFile": function(docVO) {}, 
	/**
	* Set Approvers for a specific document
	* @memberOf fluigAPI
	* @param {long} companyId 
	* @param {com.fluig.sdk.api.document.DocumentSecurityVO} documentSecurityVO 
	*/
	"setDocumentApprovers": function(companyId, documentSecurityVO) {}, 
	/**
	* Return the approvements history of the document
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentApprovementHistoryVO&gt;} 
	*/
	"getDocumentApprovalHistory": function(documentId) {}
};
com.fluig.sdk.service.FolderDocumentService.prototype = {
	/**
	* Recupera um documento através do id
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @returns {com.fluig.sdk.api.document.DocumentVO} 
	*/
	"get": function(documentId) {}, 
	/**
	* Criação de uma nova pasta
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.document.FolderVO} vo 
	* @returns {com.fluig.sdk.api.document.FolderVO} 
	*/
	"create": function(vo) {}, 
	/**
	* Recupera lista de documentos através do id da pasta
	* @memberOf fluigAPI
	* @param {int} folderId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentVO&gt;} 
	*/
	"list": function(folderId) {}, 
	/**
	* Atualiza documento ou pasta
	* @memberOf fluigAPI
	* @param {long} companyId 
	* @param {int} documentId 
	* @param {String} description 
	* @returns {com.fluig.sdk.api.document.DocumentVO} 
	*/
	"updateDocumentDescription": function(companyId, documentId, description) {}, 
	/**
	* Recupera lista de documentos através do id da pasta
	* @memberOf fluigAPI
	* @param {int} folderId 
	* @param {int} permission 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentVO&gt;} 
	*/
	"list": function(folderId, permission) {}, 
	/**
	* Retorna os documentos de uma pasta
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.document.FolderVO} folderVO 
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentVO&gt;} 
	*/
	"listDocumentsByFolder": function(folderVO, limit, offset) {}
};
FolderDocumentService.prototype = {
	/**
	* Recupera um documento através do id
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @returns {com.fluig.sdk.api.document.DocumentVO} 
	*/
	"get": function(documentId) {}, 
	/**
	* Criação de uma nova pasta
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.document.FolderVO} vo 
	* @returns {com.fluig.sdk.api.document.FolderVO} 
	*/
	"create": function(vo) {}, 
	/**
	* Recupera lista de documentos através do id da pasta
	* @memberOf fluigAPI
	* @param {int} folderId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentVO&gt;} 
	*/
	"list": function(folderId) {}, 
	/**
	* Atualiza documento ou pasta
	* @memberOf fluigAPI
	* @param {long} companyId 
	* @param {int} documentId 
	* @param {String} description 
	* @returns {com.fluig.sdk.api.document.DocumentVO} 
	*/
	"updateDocumentDescription": function(companyId, documentId, description) {}, 
	/**
	* Recupera lista de documentos através do id da pasta
	* @memberOf fluigAPI
	* @param {int} folderId 
	* @param {int} permission 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentVO&gt;} 
	*/
	"list": function(folderId, permission) {}, 
	/**
	* Retorna os documentos de uma pasta
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.document.FolderVO} folderVO 
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentVO&gt;} 
	*/
	"listDocumentsByFolder": function(folderVO, limit, offset) {}
};
com.fluig.sdk.service.WorkflowAPIService.prototype = {
	/**
	* Retorna todos os processos da empresa
	* @memberOf fluigAPI
	* @param {String} pattern 
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessDefinitionVO&gt;} 
	*/
	"listProcess": function(pattern, limit, offset) {}, 
	/**
	* Retorna a versão de um processo
	* @memberOf fluigAPI
	* @param {String} processId 
	* @returns {int} 
	*/
	"getProcessVersion": function(processId) {}, 
	/**
	* Retorna uma lista de processos disponíveis para o usuário
	* @memberOf fluigAPI
	* @param {long} tenantId 
	* @param {String} userId 
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessVersionVO&gt;} 
	*/
	"getAvailableProcess": function(tenantId, userId) {}, 
	/**
	* Retorna uma lista das atividades pendentes de um processo
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	* @returns {com.fluig.sdk.api.workflow.ProcessInstanceInfoVO} 
	*/
	"getActiveTasks": function(processInstanceId) {}, 
	/**
	* Insere um complemento em uma solicitação
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.ProcessObservationVO} processObservationVO 
	* @returns {com.fluig.sdk.api.workflow.ProcessObservationVO} 
	*/
	"createProcessObservation": function(processObservationVO) {}, 
	/**
	* Retorna a lista de complementos em uma solicitação
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	* @param {int} stateSequence 
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessObservationVO&gt;} 
	*/
	"findObservations": function(processInstanceId, stateSequence) {}, 
	/**
	* Faz com que o usuário repassado assuma a tarefa
	* @memberOf fluigAPI
	* @param {long} companyId 
	* @param {String} userId 
	* @param {int} processInstanceId 
	* @param {int} movementSequence 
	* @param {String} replacementId 
	* @returns {com.fluig.sdk.api.workflow.ProcessTaskVO} 
	*/
	"assumeProcessTask": function(companyId, userId, processInstanceId, movementSequence, replacementId) {}, 
	/**
	* Faz com que o usuário repassado assuma a tarefa
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.AssumeProcessTaskVO} assumeProcessTaskVO 
	* @returns {com.fluig.sdk.api.workflow.AssumeProcessTaskResultVO} 
	*/
	"assumeProcessTask": function(assumeProcessTaskVO) {}, 
	/**
	* Faz com que os usuários repassados assumam as tarefas vinculadas aos mesmos
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.AssumeProcessTasksVO} assumeProcessTasksVO 
	* @returns {com.fluig.sdk.api.workflow.AssumeProcessTasksResultVO} 
	*/
	"assumeProcessTasks": function(assumeProcessTasksVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.CancelInstanceVO} cancelInstanceVO 
	* @returns {com.fluig.sdk.api.workflow.CancelInstanceResultVO} 
	*/
	"cancelInstance": function(cancelInstanceVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.CancelInstancesVO} cancelInstanceVO 
	* @returns {com.fluig.sdk.api.workflow.CancelInstancesResultVO} 
	*/
	"cancelInstances": function(cancelInstanceVO) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @param {Map} cardFilters 
	* @param {List} countersRequiredList 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLA": function(processes, cardFilters, countersRequiredList) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @param {Map} cardFilters 
	* @param {List} countersRequiredList 
	* @param {Date} initialStartDate 
	* @param {Date} finalStartDate 
	* @param {Date} initialDeadlineDate 
	* @param {Date} finalDeadlineDate 
	* @param {Date} initialWarningDate 
	* @param {Date} finalWarningDate 
	* @param {String} requester 
	* @param {String} assignee 
	* @param {String} manager 
	* @param {List} requesterLocalsList 
	* @param {List} assigneeLocalsList 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLA": function(processes, cardFilters, countersRequiredList, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, requester, assignee, manager, requesterLocalsList, assigneeLocalsList) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLA": function() {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLA": function(processes) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @param {Map} cardFilters 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLA": function(processes, cardFilters) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} countersRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} requester 
	* @param {String} assignee 
	* @param {String} manager 
	* @param {String} requesterLocals 
	* @param {String} assigneeLocals 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLA": function(processes, cardFilters, countersRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, requester, assignee, manager, requesterLocals, assigneeLocals) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} statusRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} expand 
	* @param {String} requester 
	* @param {String} assignee 
	* @param {String} manager 
	* @param {String} requesterLocals 
	* @param {String} assigneeLocals 
	* @param {String} order 
	* @param {String} calculate 
	* @param {String} page 
	* @param {String} pageSize 
	*/
	"findRequestsSLA": function(processes, cardFilters, statusRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, expand, requester, assignee, manager, requesterLocals, assigneeLocals, order, calculate, page, pageSize) {}, 
	/**
	* Recupera uma lista das solicitações de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @param {Map} cardFilters 
	* @param {List} statusRequiredList 
	* @param {Date} initialStartDate 
	* @param {Date} finalStartDate 
	* @param {Date} initialDeadlineDate 
	* @param {Date} finalDeadlineDate 
	* @param {Date} initialWarningDate 
	* @param {Date} finalWarningDate 
	* @param {boolean} returnCurrentTasks 
	* @param {String} requester 
	* @param {String} assignee 
	* @param {String} manager 
	* @param {List} requesterLocals 
	* @param {List} assigneeLocals 
	* @param {List} orderParams 
	* @param {boolean} calculate 
	* @param {int} page 
	* @param {int} pageSize 
	* @param {boolean} populateCardFields 
	* @param {boolean} populateLocalsValue 
	* @param {boolean} populateAssigneeLocalsValue 
	*/
	"findRequestsSLA": function(processes, cardFilters, statusRequiredList, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, returnCurrentTasks, requester, assignee, manager, requesterLocals, assigneeLocals, orderParams, calculate, page, pageSize, populateCardFields, populateLocalsValue, populateAssigneeLocalsValue) {}, 
	/**
	* Recupera uma lista das solicitações de SLA dos processos configurados
	* @memberOf fluigAPI
	*/
	"findRequestsSLA": function() {}, 
	/**
	* Recupera uma lista das solicitações de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	*/
	"findRequestsSLA": function(processes) {}, 
	/**
	* Recupera uma lista das solicitações de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @param {List} statusRequiredList 
	*/
	"findRequestsSLA": function(processes, statusRequiredList) {}, 
	/**
	* Recupera uma lista das solicitações de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @param {List} statusRequiredList 
	* @param {boolean} returnCurrentTasks 
	*/
	"findRequestsSLA": function(processes, statusRequiredList, returnCurrentTasks) {}, 
	/**
	* Recupera uma lista das solicitações de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @param {Map} cardFilters 
	* @param {List} statusRequiredList 
	* @param {boolean} returnCurrentTasks 
	*/
	"findRequestsSLA": function(processes, cardFilters, statusRequiredList, returnCurrentTasks) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como requisitante
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} statusRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} expand 
	* @param {String} assignee 
	* @param {String} manager 
	* @param {String} order 
	* @param {String} calculate 
	* @param {String} page 
	* @param {String} pageSize 
	*/
	"findMyRequestsSLA": function(processes, cardFilters, statusRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, expand, assignee, manager, order, calculate, page, pageSize) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como responsável
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} statusRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} expand 
	* @param {String} requester 
	* @param {String} manager 
	* @param {String} requesterLocals 
	* @param {String} assigneeLocals 
	* @param {String} order 
	* @param {String} calculate 
	* @param {String} page 
	* @param {String} pageSize 
	*/
	"findRequestsSLAAssignedToMe": function(processes, cardFilters, statusRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, expand, requester, manager, requesterLocals, assigneeLocals, order, calculate, page, pageSize) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como requisitante
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} countersRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} assignee 
	* @param {String} manager 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeMyRequestsSLA": function(processes, cardFilters, countersRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, assignee, manager) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como responsável
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} countersRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} requester 
	* @param {String} manager 
	* @param {String} requesterLocals 
	* @param {String} assigneeLocals 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLAAssignedToMe": function(processes, cardFilters, countersRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, requester, manager, requesterLocals, assigneeLocals) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como responsável
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	* @param {boolean} populateCurrentTasks 
	* @param {boolean} calculate 
	* @param {boolean} populateCardFields 
	* @param {boolean} populateLocals 
	* @param {boolean} assigneeLocals 
	* @returns {com.fluig.sdk.api.workflow.RequestSLAVO} 
	*/
	"findRequestSLAByProcessInstanceId": function(processInstanceId, populateCurrentTasks, calculate, populateCardFields, populateLocals, assigneeLocals) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como responsável
	* @memberOf fluigAPI
	* @param {String} processInstanceId 
	* @param {String} expand 
	* @param {String} calculate 
	* @returns {com.fluig.sdk.api.workflow.RequestSLAVO} 
	*/
	"findRequestSLAByProcessInstanceId": function(processInstanceId, expand, calculate) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como gestor
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} statusRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} expand 
	* @param {String} requester 
	* @param {String} assignee 
	* @param {String} requesterLocals 
	* @param {String} assigneeLocals 
	* @param {String} order 
	* @param {String} calculate 
	* @param {String} page 
	* @param {String} pageSize 
	*/
	"findRequestsSLAManagedByMe": function(processes, cardFilters, statusRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, expand, requester, assignee, requesterLocals, assigneeLocals, order, calculate, page, pageSize) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como gestor
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} countersRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} requester 
	* @param {String} assignee 
	* @param {String} requesterLocals 
	* @param {String} assigneeLocals 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLAManagedByMe": function(processes, cardFilters, countersRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, requester, assignee, requesterLocals, assigneeLocals) {}, 
	/**
	* Retorna todos os processos da empresa
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessDefinitionVO&gt;} 
	*/
	"listSlaProcess": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	* @param {String} startDate 
	* @param {String} endDate 
	* @param {String} assignee 
	* @param {String} manager 
	* @returns {com.fluig.sdk.api.workflow.ResumeProcessTaskVO} 
	*/
	"resumeMyRequestsTasks": function(processId, startDate, endDate, assignee, manager) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	* @param {String} startDate 
	* @param {String} endDate 
	* @param {String} requester 
	* @param {String} manager 
	* @returns {com.fluig.sdk.api.workflow.ResumeProcessTaskVO} 
	*/
	"resumeAssignedToMeTasks": function(processId, startDate, endDate, requester, manager) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	* @param {String} startDate 
	* @param {String} endDate 
	* @param {String} requester 
	* @param {String} assignee 
	* @returns {com.fluig.sdk.api.workflow.ResumeProcessTaskVO} 
	*/
	"resumeManagedByMeTasks": function(processId, startDate, endDate, requester, assignee) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} assignee 
	* @param {String} manager 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} statusTypeTaskRequest 
	*/
	"findMyRequestsTasks": function(processId, initialStartDate, finalStartDate, assignee, manager, page, pageSize, statusTypeTaskRequest) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} requester 
	* @param {String} manager 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} statusTypeTaskRequest 
	*/
	"findAssignedToMeTasks": function(processId, initialStartDate, finalStartDate, requester, manager, page, pageSize, statusTypeTaskRequest) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} assignee 
	* @param {String} requester 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} statusTypeTaskRequest 
	*/
	"findManagedByMeTasks": function(processId, initialStartDate, finalStartDate, assignee, requester, page, pageSize, statusTypeTaskRequest) {}
};
WorkflowAPIService.prototype = {
	/**
	* Retorna todos os processos da empresa
	* @memberOf fluigAPI
	* @param {String} pattern 
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessDefinitionVO&gt;} 
	*/
	"listProcess": function(pattern, limit, offset) {}, 
	/**
	* Retorna a versão de um processo
	* @memberOf fluigAPI
	* @param {String} processId 
	* @returns {int} 
	*/
	"getProcessVersion": function(processId) {}, 
	/**
	* Retorna uma lista de processos disponíveis para o usuário
	* @memberOf fluigAPI
	* @param {long} tenantId 
	* @param {String} userId 
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessVersionVO&gt;} 
	*/
	"getAvailableProcess": function(tenantId, userId) {}, 
	/**
	* Retorna uma lista das atividades pendentes de um processo
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	* @returns {com.fluig.sdk.api.workflow.ProcessInstanceInfoVO} 
	*/
	"getActiveTasks": function(processInstanceId) {}, 
	/**
	* Insere um complemento em uma solicitação
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.ProcessObservationVO} processObservationVO 
	* @returns {com.fluig.sdk.api.workflow.ProcessObservationVO} 
	*/
	"createProcessObservation": function(processObservationVO) {}, 
	/**
	* Retorna a lista de complementos em uma solicitação
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	* @param {int} stateSequence 
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessObservationVO&gt;} 
	*/
	"findObservations": function(processInstanceId, stateSequence) {}, 
	/**
	* Faz com que o usuário repassado assuma a tarefa
	* @memberOf fluigAPI
	* @param {long} companyId 
	* @param {String} userId 
	* @param {int} processInstanceId 
	* @param {int} movementSequence 
	* @param {String} replacementId 
	* @returns {com.fluig.sdk.api.workflow.ProcessTaskVO} 
	*/
	"assumeProcessTask": function(companyId, userId, processInstanceId, movementSequence, replacementId) {}, 
	/**
	* Faz com que o usuário repassado assuma a tarefa
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.AssumeProcessTaskVO} assumeProcessTaskVO 
	* @returns {com.fluig.sdk.api.workflow.AssumeProcessTaskResultVO} 
	*/
	"assumeProcessTask": function(assumeProcessTaskVO) {}, 
	/**
	* Faz com que os usuários repassados assumam as tarefas vinculadas aos mesmos
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.AssumeProcessTasksVO} assumeProcessTasksVO 
	* @returns {com.fluig.sdk.api.workflow.AssumeProcessTasksResultVO} 
	*/
	"assumeProcessTasks": function(assumeProcessTasksVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.CancelInstanceVO} cancelInstanceVO 
	* @returns {com.fluig.sdk.api.workflow.CancelInstanceResultVO} 
	*/
	"cancelInstance": function(cancelInstanceVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.CancelInstancesVO} cancelInstanceVO 
	* @returns {com.fluig.sdk.api.workflow.CancelInstancesResultVO} 
	*/
	"cancelInstances": function(cancelInstanceVO) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @param {Map} cardFilters 
	* @param {List} countersRequiredList 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLA": function(processes, cardFilters, countersRequiredList) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @param {Map} cardFilters 
	* @param {List} countersRequiredList 
	* @param {Date} initialStartDate 
	* @param {Date} finalStartDate 
	* @param {Date} initialDeadlineDate 
	* @param {Date} finalDeadlineDate 
	* @param {Date} initialWarningDate 
	* @param {Date} finalWarningDate 
	* @param {String} requester 
	* @param {String} assignee 
	* @param {String} manager 
	* @param {List} requesterLocalsList 
	* @param {List} assigneeLocalsList 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLA": function(processes, cardFilters, countersRequiredList, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, requester, assignee, manager, requesterLocalsList, assigneeLocalsList) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLA": function() {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLA": function(processes) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @param {Map} cardFilters 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLA": function(processes, cardFilters) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} countersRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} requester 
	* @param {String} assignee 
	* @param {String} manager 
	* @param {String} requesterLocals 
	* @param {String} assigneeLocals 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLA": function(processes, cardFilters, countersRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, requester, assignee, manager, requesterLocals, assigneeLocals) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} statusRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} expand 
	* @param {String} requester 
	* @param {String} assignee 
	* @param {String} manager 
	* @param {String} requesterLocals 
	* @param {String} assigneeLocals 
	* @param {String} order 
	* @param {String} calculate 
	* @param {String} page 
	* @param {String} pageSize 
	*/
	"findRequestsSLA": function(processes, cardFilters, statusRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, expand, requester, assignee, manager, requesterLocals, assigneeLocals, order, calculate, page, pageSize) {}, 
	/**
	* Recupera uma lista das solicitações de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @param {Map} cardFilters 
	* @param {List} statusRequiredList 
	* @param {Date} initialStartDate 
	* @param {Date} finalStartDate 
	* @param {Date} initialDeadlineDate 
	* @param {Date} finalDeadlineDate 
	* @param {Date} initialWarningDate 
	* @param {Date} finalWarningDate 
	* @param {boolean} returnCurrentTasks 
	* @param {String} requester 
	* @param {String} assignee 
	* @param {String} manager 
	* @param {List} requesterLocals 
	* @param {List} assigneeLocals 
	* @param {List} orderParams 
	* @param {boolean} calculate 
	* @param {int} page 
	* @param {int} pageSize 
	* @param {boolean} populateCardFields 
	* @param {boolean} populateLocalsValue 
	* @param {boolean} populateAssigneeLocalsValue 
	*/
	"findRequestsSLA": function(processes, cardFilters, statusRequiredList, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, returnCurrentTasks, requester, assignee, manager, requesterLocals, assigneeLocals, orderParams, calculate, page, pageSize, populateCardFields, populateLocalsValue, populateAssigneeLocalsValue) {}, 
	/**
	* Recupera uma lista das solicitações de SLA dos processos configurados
	* @memberOf fluigAPI
	*/
	"findRequestsSLA": function() {}, 
	/**
	* Recupera uma lista das solicitações de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	*/
	"findRequestsSLA": function(processes) {}, 
	/**
	* Recupera uma lista das solicitações de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @param {List} statusRequiredList 
	*/
	"findRequestsSLA": function(processes, statusRequiredList) {}, 
	/**
	* Recupera uma lista das solicitações de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @param {List} statusRequiredList 
	* @param {boolean} returnCurrentTasks 
	*/
	"findRequestsSLA": function(processes, statusRequiredList, returnCurrentTasks) {}, 
	/**
	* Recupera uma lista das solicitações de SLA dos processos configurados
	* @memberOf fluigAPI
	* @param {List} processes 
	* @param {Map} cardFilters 
	* @param {List} statusRequiredList 
	* @param {boolean} returnCurrentTasks 
	*/
	"findRequestsSLA": function(processes, cardFilters, statusRequiredList, returnCurrentTasks) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como requisitante
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} statusRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} expand 
	* @param {String} assignee 
	* @param {String} manager 
	* @param {String} order 
	* @param {String} calculate 
	* @param {String} page 
	* @param {String} pageSize 
	*/
	"findMyRequestsSLA": function(processes, cardFilters, statusRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, expand, assignee, manager, order, calculate, page, pageSize) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como responsável
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} statusRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} expand 
	* @param {String} requester 
	* @param {String} manager 
	* @param {String} requesterLocals 
	* @param {String} assigneeLocals 
	* @param {String} order 
	* @param {String} calculate 
	* @param {String} page 
	* @param {String} pageSize 
	*/
	"findRequestsSLAAssignedToMe": function(processes, cardFilters, statusRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, expand, requester, manager, requesterLocals, assigneeLocals, order, calculate, page, pageSize) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como requisitante
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} countersRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} assignee 
	* @param {String} manager 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeMyRequestsSLA": function(processes, cardFilters, countersRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, assignee, manager) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como responsável
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} countersRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} requester 
	* @param {String} manager 
	* @param {String} requesterLocals 
	* @param {String} assigneeLocals 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLAAssignedToMe": function(processes, cardFilters, countersRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, requester, manager, requesterLocals, assigneeLocals) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como responsável
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	* @param {boolean} populateCurrentTasks 
	* @param {boolean} calculate 
	* @param {boolean} populateCardFields 
	* @param {boolean} populateLocals 
	* @param {boolean} assigneeLocals 
	* @returns {com.fluig.sdk.api.workflow.RequestSLAVO} 
	*/
	"findRequestSLAByProcessInstanceId": function(processInstanceId, populateCurrentTasks, calculate, populateCardFields, populateLocals, assigneeLocals) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como responsável
	* @memberOf fluigAPI
	* @param {String} processInstanceId 
	* @param {String} expand 
	* @param {String} calculate 
	* @returns {com.fluig.sdk.api.workflow.RequestSLAVO} 
	*/
	"findRequestSLAByProcessInstanceId": function(processInstanceId, expand, calculate) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como gestor
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} statusRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} expand 
	* @param {String} requester 
	* @param {String} assignee 
	* @param {String} requesterLocals 
	* @param {String} assigneeLocals 
	* @param {String} order 
	* @param {String} calculate 
	* @param {String} page 
	* @param {String} pageSize 
	*/
	"findRequestsSLAManagedByMe": function(processes, cardFilters, statusRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, expand, requester, assignee, requesterLocals, assigneeLocals, order, calculate, page, pageSize) {}, 
	/**
	* Recupera um resumo dos indicadores de SLA dos processos configurados considerando o usuário logado como gestor
	* @memberOf fluigAPI
	* @param {String} processes 
	* @param {String} cardFilters 
	* @param {String} countersRequired 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} initialDeadlineDate 
	* @param {String} finalDeadlineDate 
	* @param {String} initialWarningDate 
	* @param {String} finalWarningDate 
	* @param {String} requester 
	* @param {String} assignee 
	* @param {String} requesterLocals 
	* @param {String} assigneeLocals 
	* @returns {com.fluig.sdk.api.workflow.ResumeRequestsSLAVO} 
	*/
	"resumeRequestsSLAManagedByMe": function(processes, cardFilters, countersRequired, initialStartDate, finalStartDate, initialDeadlineDate, finalDeadlineDate, initialWarningDate, finalWarningDate, requester, assignee, requesterLocals, assigneeLocals) {}, 
	/**
	* Retorna todos os processos da empresa
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessDefinitionVO&gt;} 
	*/
	"listSlaProcess": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	* @param {String} startDate 
	* @param {String} endDate 
	* @param {String} assignee 
	* @param {String} manager 
	* @returns {com.fluig.sdk.api.workflow.ResumeProcessTaskVO} 
	*/
	"resumeMyRequestsTasks": function(processId, startDate, endDate, assignee, manager) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	* @param {String} startDate 
	* @param {String} endDate 
	* @param {String} requester 
	* @param {String} manager 
	* @returns {com.fluig.sdk.api.workflow.ResumeProcessTaskVO} 
	*/
	"resumeAssignedToMeTasks": function(processId, startDate, endDate, requester, manager) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	* @param {String} startDate 
	* @param {String} endDate 
	* @param {String} requester 
	* @param {String} assignee 
	* @returns {com.fluig.sdk.api.workflow.ResumeProcessTaskVO} 
	*/
	"resumeManagedByMeTasks": function(processId, startDate, endDate, requester, assignee) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} assignee 
	* @param {String} manager 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} statusTypeTaskRequest 
	*/
	"findMyRequestsTasks": function(processId, initialStartDate, finalStartDate, assignee, manager, page, pageSize, statusTypeTaskRequest) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} requester 
	* @param {String} manager 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} statusTypeTaskRequest 
	*/
	"findAssignedToMeTasks": function(processId, initialStartDate, finalStartDate, requester, manager, page, pageSize, statusTypeTaskRequest) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	* @param {String} initialStartDate 
	* @param {String} finalStartDate 
	* @param {String} assignee 
	* @param {String} requester 
	* @param {String} page 
	* @param {String} pageSize 
	* @param {String} statusTypeTaskRequest 
	*/
	"findManagedByMeTasks": function(processId, initialStartDate, finalStartDate, assignee, requester, page, pageSize, statusTypeTaskRequest) {}
};
com.fluig.sdk.service.CardService.prototype = {
	/**
	* Criação de um novo card
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.CardItemVO} vo 
	* @returns {com.fluig.sdk.api.workflow.CardItemVO} 
	*/
	"createItem": function(vo) {}
};
CardService.prototype = {
	/**
	* Criação de um novo card
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.CardItemVO} vo 
	* @returns {com.fluig.sdk.api.workflow.CardItemVO} 
	*/
	"createItem": function(vo) {}
};
com.fluig.sdk.service.CardIndexService.prototype = {
	/**
	* Criação de um novo card index
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.CardIndexVO} vo 
	* @returns {com.fluig.sdk.api.workflow.CardIndexVO} 
	*/
	"create": function(vo) {}, 
	/**
	* Exclusão de um card index
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"delete": function(documentId) {}, 
	/**
	* Retorna a pasta padrão de formulário
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDefaultFormFolderId": function() {}
};
CardIndexService.prototype = {
	/**
	* Criação de um novo card index
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.CardIndexVO} vo 
	* @returns {com.fluig.sdk.api.workflow.CardIndexVO} 
	*/
	"create": function(vo) {}, 
	/**
	* Exclusão de um card index
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"delete": function(documentId) {}, 
	/**
	* Retorna a pasta padrão de formulário
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDefaultFormFolderId": function() {}
};
com.fluig.sdk.service.JobService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.job.JobVO} vo 
	* @returns {com.fluig.sdk.api.job.JobVO} 
	*/
	"createDaily": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.job.JobVO} vo 
	* @returns {com.fluig.sdk.api.job.JobVO} 
	*/
	"createWeekly": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.job.JobVO} vo 
	* @returns {com.fluig.sdk.api.job.JobVO} 
	*/
	"createMonthly": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.job.JobVO} vo 
	*/
	"delete": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} limit 
	* @param {int} offset 
	* @param {String} filter 
	* @returns {List&lt;com.fluig.sdk.api.job.JobVO&gt;} 
	*/
	"list": function(limit, offset, filter) {}
};
JobService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.job.JobVO} vo 
	* @returns {com.fluig.sdk.api.job.JobVO} 
	*/
	"createDaily": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.job.JobVO} vo 
	* @returns {com.fluig.sdk.api.job.JobVO} 
	*/
	"createWeekly": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.job.JobVO} vo 
	* @returns {com.fluig.sdk.api.job.JobVO} 
	*/
	"createMonthly": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.job.JobVO} vo 
	*/
	"delete": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} limit 
	* @param {int} offset 
	* @param {String} filter 
	* @returns {List&lt;com.fluig.sdk.api.job.JobVO&gt;} 
	*/
	"list": function(limit, offset, filter) {}
};
com.fluig.sdk.service.PageService.prototype = {
	/**
	* Seta o valor de uma preferência para uma instância de uma widget
	* @memberOf fluigAPI
	* @param {long} instanceId 
	* @param {String} key 
	* @param {String} value 
	*/
	"setWidgetPreference": function(instanceId, key, value) {}, 
	/**
	* Recupera os valores de preferências para uma instância de uma widget
	* @memberOf fluigAPI
	* @param {long} instanceId 
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getWidgetPreferences": function(instanceId) {}, 
	/**
	* Consulta páginas do fluig
	* @memberOf fluigAPI
	* @param {String} parentPageCode 
	* @param {boolean} isMobile 
	* @param {String} filter 
	* @param {int} start 
	* @param {int} size 
	* @param {int} searchLevel 
	* @param {boolean} internalPages 
	* @returns {List&lt;com.fluig.sdk.page.PublicApiPageVO&gt;} 
	*/
	"findPages": function(parentPageCode, isMobile, filter, start, size, searchLevel, internalPages) {}, 
	/**
	* Consulta páginas do fluig
	* @memberOf fluigAPI
	* @param {String} parentPageCode 
	* @param {boolean} isMobile 
	* @param {String} filter 
	* @param {int} start 
	* @param {int} size 
	* @param {int} searchLevel 
	* @param {boolean} internalPages 
	* @param {String} codePage 
	* @returns {List&lt;com.fluig.sdk.page.PublicApiPageVO&gt;} 
	*/
	"findPages": function(parentPageCode, isMobile, filter, start, size, searchLevel, internalPages, codePage) {}, 
	/**
	* Retorna itens de menu da página
	* @memberOf fluigAPI
	* @param {String} pageCode 
	* @returns {List&lt;com.fluig.sdk.page.PublicApiPageVO&gt;} 
	*/
	"findMenuFromPage": function(pageCode) {}, 
	/**
	* Retorna o endereco emque o servidor foi instalado
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getServerURL": function() {}, 
	/**
	* Recarrega o layout de uma página
	* @memberOf fluigAPI
	* @param {String} pageCode 
	*/
	"reloadPageLayout": function(pageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	* @param {String} publicationDescription 
	*/
	"publishPageDraft": function(pageCode, publicationDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	* @param  pageVersion 
	*/
	"createPageDraftFromVersion": function(pageCode, pageVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	* @returns {List&lt;String&gt;} 
	*/
	"pageHistory": function(pageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	* @returns {com.fluig.sdk.page.PageMobileApiVO} 
	*/
	"mobileMapping": function(pageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	*/
	"hide": function(pageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	*/
	"show": function(pageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	*/
	"enable": function(pageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	*/
	"disable": function(pageCode) {}
};
PageService.prototype = {
	/**
	* Seta o valor de uma preferência para uma instância de uma widget
	* @memberOf fluigAPI
	* @param {long} instanceId 
	* @param {String} key 
	* @param {String} value 
	*/
	"setWidgetPreference": function(instanceId, key, value) {}, 
	/**
	* Recupera os valores de preferências para uma instância de uma widget
	* @memberOf fluigAPI
	* @param {long} instanceId 
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getWidgetPreferences": function(instanceId) {}, 
	/**
	* Consulta páginas do fluig
	* @memberOf fluigAPI
	* @param {String} parentPageCode 
	* @param {boolean} isMobile 
	* @param {String} filter 
	* @param {int} start 
	* @param {int} size 
	* @param {int} searchLevel 
	* @param {boolean} internalPages 
	* @returns {List&lt;com.fluig.sdk.page.PublicApiPageVO&gt;} 
	*/
	"findPages": function(parentPageCode, isMobile, filter, start, size, searchLevel, internalPages) {}, 
	/**
	* Consulta páginas do fluig
	* @memberOf fluigAPI
	* @param {String} parentPageCode 
	* @param {boolean} isMobile 
	* @param {String} filter 
	* @param {int} start 
	* @param {int} size 
	* @param {int} searchLevel 
	* @param {boolean} internalPages 
	* @param {String} codePage 
	* @returns {List&lt;com.fluig.sdk.page.PublicApiPageVO&gt;} 
	*/
	"findPages": function(parentPageCode, isMobile, filter, start, size, searchLevel, internalPages, codePage) {}, 
	/**
	* Retorna itens de menu da página
	* @memberOf fluigAPI
	* @param {String} pageCode 
	* @returns {List&lt;com.fluig.sdk.page.PublicApiPageVO&gt;} 
	*/
	"findMenuFromPage": function(pageCode) {}, 
	/**
	* Retorna o endereco emque o servidor foi instalado
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getServerURL": function() {}, 
	/**
	* Recarrega o layout de uma página
	* @memberOf fluigAPI
	* @param {String} pageCode 
	*/
	"reloadPageLayout": function(pageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	* @param {String} publicationDescription 
	*/
	"publishPageDraft": function(pageCode, publicationDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	* @param  pageVersion 
	*/
	"createPageDraftFromVersion": function(pageCode, pageVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	* @returns {List&lt;String&gt;} 
	*/
	"pageHistory": function(pageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	* @returns {com.fluig.sdk.page.PageMobileApiVO} 
	*/
	"mobileMapping": function(pageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	*/
	"hide": function(pageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	*/
	"show": function(pageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	*/
	"enable": function(pageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	*/
	"disable": function(pageCode) {}
};
com.fluig.sdk.service.PageWidgetService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} instanceId 
	*/
	"enableForMobileApp": function(instanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} instanceId 
	*/
	"disableForMobileApp": function(instanceId) {}
};
PageWidgetService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} instanceId 
	*/
	"enableForMobileApp": function(instanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} instanceId 
	*/
	"disableForMobileApp": function(instanceId) {}
};
com.fluig.sdk.service.DocumentationProxyServiceService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} expression 
	* @returns {String} 
	*/
	"getUrlResult": function(expression) {}
};
DocumentationProxyServiceService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} expression 
	* @returns {String} 
	*/
	"getUrlResult": function(expression) {}
};
com.fluig.sdk.service.I18NService.prototype = {
	/**
	* Retorna a tradução de uma String padrão do Fluig
	* @memberOf fluigAPI
	* @param {String} message 
	* @param  params 
	* @returns {String} 
	*/
	"transalateString": function(message, params) {}, 
	/**
	* Retorna a tradução de uma String associada a um Bundle específico
	* @memberOf fluigAPI
	* @param {String} code 
	* @param {String} message 
	* @param  params 
	* @returns {String} 
	*/
	"transalateString": function(code, message, params) {}, 
	/**
	* Retorna a tradução de uma exception
	* @memberOf fluigAPI
	* @param  ex 
	* @returns {String[]} 
	*/
	"translateException": function(ex) {}, 
	/**
	* Registra um ResourceBundle para um determinado componente
	* @memberOf fluigAPI
	* @param  locale 
	* @param {String} code 
	* @param  props 
	*/
	"addResourceBundle": function(locale, code, props) {}
};
I18NService.prototype = {
	/**
	* Retorna a tradução de uma String padrão do Fluig
	* @memberOf fluigAPI
	* @param {String} message 
	* @param  params 
	* @returns {String} 
	*/
	"transalateString": function(message, params) {}, 
	/**
	* Retorna a tradução de uma String associada a um Bundle específico
	* @memberOf fluigAPI
	* @param {String} code 
	* @param {String} message 
	* @param  params 
	* @returns {String} 
	*/
	"transalateString": function(code, message, params) {}, 
	/**
	* Retorna a tradução de uma exception
	* @memberOf fluigAPI
	* @param  ex 
	* @returns {String[]} 
	*/
	"translateException": function(ex) {}, 
	/**
	* Registra um ResourceBundle para um determinado componente
	* @memberOf fluigAPI
	* @param  locale 
	* @param {String} code 
	* @param  props 
	*/
	"addResourceBundle": function(locale, code, props) {}
};
com.fluig.sdk.service.PostService.prototype = {
	/**
	* Realiza um post em uma timeline, seja pessoal ou de alguma comunidade
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.PostVO} vo 
	* @returns {com.fluig.sdk.api.social.PostVO} 
	*/
	"create": function(vo) {}, 
	/**
	* Realiza um post com anexo em uma timeline, seja pessoal ou de alguma comunidade
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.PostVO} vo 
	* @returns {com.fluig.sdk.api.social.PostVO} 
	*/
	"createWithUpload": function(vo) {}, 
	/**
	* Edit a single post
	* @memberOf fluigAPI
	* @param {long} postId 
	* @param {String} text 
	*/
	"editPost": function(postId, text) {}
};
PostService.prototype = {
	/**
	* Realiza um post em uma timeline, seja pessoal ou de alguma comunidade
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.PostVO} vo 
	* @returns {com.fluig.sdk.api.social.PostVO} 
	*/
	"create": function(vo) {}, 
	/**
	* Realiza um post com anexo em uma timeline, seja pessoal ou de alguma comunidade
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.PostVO} vo 
	* @returns {com.fluig.sdk.api.social.PostVO} 
	*/
	"createWithUpload": function(vo) {}, 
	/**
	* Edit a single post
	* @memberOf fluigAPI
	* @param {long} postId 
	* @param {String} text 
	*/
	"editPost": function(postId, text) {}
};
com.fluig.sdk.service.ArticleService.prototype = {
	/**
	* Remove an article by his id
	* @memberOf fluigAPI
	* @param {long} articleId 
	*/
	"delete": function(articleId) {}, 
	/**
	* Retrieve an article<br><br>Return an article published in a community.<br>
	* @memberOf fluigAPI
	* @param {String} alias 
	* @param {long} articleId 
	* @param {boolean} draft 
	* @returns {com.fluig.sdk.api.social.ArticleVO} 
	*/
	"get": function(alias, articleId, draft) {}, 
	/**
	* Retrieve a list of article<br><br>Return a list of article published in a community.<br>
	* @memberOf fluigAPI
	* @param {String} alias 
	* @param {long} categoryId 
	* @param {int} limit 
	* @param {int} offset 
	* @param {String} filterBy 
	* @param {String} orderBy 
	* @param {String} searchBy 
	* @returns {List&lt;com.fluig.sdk.api.social.ArticleVO&gt;} 
	*/
	"list": function(alias, categoryId, limit, offset, filterBy, orderBy, searchBy) {}, 
	/**
	* Create an article in draft mode.<br><br>Return the article that was created in a draft mode.<br>
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.ArticleVO} vo 
	* @returns {com.fluig.sdk.api.social.ArticleVO} 
	*/
	"createDraft": function(vo) {}, 
	/**
	* Save and update an article.<br> <br>Return the article that was updated in a community.<br>
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.ArticleVO} vo 
	* @returns {com.fluig.sdk.api.social.ArticleVO} 
	*/
	"update": function(vo) {}, 
	/**
	* Create an article.<br> <br>Return the article that was updated in a community.<br>
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.ArticleVO} vo 
	* @returns {com.fluig.sdk.api.social.ArticleVO} 
	*/
	"create": function(vo) {}, 
	/**
	* Update the cover image of an existing article.<br><br>Return the article that was updated in a community.<br>
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.ArticleVO} sdkVO 
	* @returns {com.fluig.sdk.api.social.ArticleVO} 
	*/
	"changeCover": function(sdkVO) {}, 
	/**
	* Remove the cover image of an existing article.<br><br>Return the article that was updated in a community.<br>
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.ArticleVO} sdkVO 
	* @returns {com.fluig.sdk.api.social.ArticleVO} 
	*/
	"removeCover": function(sdkVO) {}, 
	/**
	* Retrive the next or previous article of one specific article.<br><br>Return the article that is the next or previous of the article passed by parameter.<br>
	* @memberOf fluigAPI
	* @param {long} folderId 
	* @param {long} articleId 
	* @param {String} order 
	* @returns {com.fluig.sdk.api.social.ArticleVO} 
	*/
	"getNextOrPrev": function(folderId, articleId, order) {}, 
	/**
	* Remove a version in draft of article<br> <br>Remove a draft version of article by his id. If the article isn't in draft,      a Error message wil be returned<br>
	* @memberOf fluigAPI
	* @param {String} alias 
	* @param {long} articleId 
	*/
	"deleteDraft": function(alias, articleId) {}
};
ArticleService.prototype = {
	/**
	* Remove an article by his id
	* @memberOf fluigAPI
	* @param {long} articleId 
	*/
	"delete": function(articleId) {}, 
	/**
	* Retrieve an article<br><br>Return an article published in a community.<br>
	* @memberOf fluigAPI
	* @param {String} alias 
	* @param {long} articleId 
	* @param {boolean} draft 
	* @returns {com.fluig.sdk.api.social.ArticleVO} 
	*/
	"get": function(alias, articleId, draft) {}, 
	/**
	* Retrieve a list of article<br><br>Return a list of article published in a community.<br>
	* @memberOf fluigAPI
	* @param {String} alias 
	* @param {long} categoryId 
	* @param {int} limit 
	* @param {int} offset 
	* @param {String} filterBy 
	* @param {String} orderBy 
	* @param {String} searchBy 
	* @returns {List&lt;com.fluig.sdk.api.social.ArticleVO&gt;} 
	*/
	"list": function(alias, categoryId, limit, offset, filterBy, orderBy, searchBy) {}, 
	/**
	* Create an article in draft mode.<br><br>Return the article that was created in a draft mode.<br>
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.ArticleVO} vo 
	* @returns {com.fluig.sdk.api.social.ArticleVO} 
	*/
	"createDraft": function(vo) {}, 
	/**
	* Save and update an article.<br> <br>Return the article that was updated in a community.<br>
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.ArticleVO} vo 
	* @returns {com.fluig.sdk.api.social.ArticleVO} 
	*/
	"update": function(vo) {}, 
	/**
	* Create an article.<br> <br>Return the article that was updated in a community.<br>
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.ArticleVO} vo 
	* @returns {com.fluig.sdk.api.social.ArticleVO} 
	*/
	"create": function(vo) {}, 
	/**
	* Update the cover image of an existing article.<br><br>Return the article that was updated in a community.<br>
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.ArticleVO} sdkVO 
	* @returns {com.fluig.sdk.api.social.ArticleVO} 
	*/
	"changeCover": function(sdkVO) {}, 
	/**
	* Remove the cover image of an existing article.<br><br>Return the article that was updated in a community.<br>
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.ArticleVO} sdkVO 
	* @returns {com.fluig.sdk.api.social.ArticleVO} 
	*/
	"removeCover": function(sdkVO) {}, 
	/**
	* Retrive the next or previous article of one specific article.<br><br>Return the article that is the next or previous of the article passed by parameter.<br>
	* @memberOf fluigAPI
	* @param {long} folderId 
	* @param {long} articleId 
	* @param {String} order 
	* @returns {com.fluig.sdk.api.social.ArticleVO} 
	*/
	"getNextOrPrev": function(folderId, articleId, order) {}, 
	/**
	* Remove a version in draft of article<br> <br>Remove a draft version of article by his id. If the article isn't in draft,      a Error message wil be returned<br>
	* @memberOf fluigAPI
	* @param {String} alias 
	* @param {long} articleId 
	*/
	"deleteDraft": function(alias, articleId) {}
};
com.fluig.sdk.service.SocialBreadcrumbService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} alias 
	* @param {long} documentId 
	* @param {String} folderType 
	* @returns {com.fluig.sdk.api.social.SocialBreadcrumbVO} 
	*/
	"get": function(alias, documentId, folderType) {}
};
SocialBreadcrumbService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} alias 
	* @param {long} documentId 
	* @param {String} folderType 
	* @returns {com.fluig.sdk.api.social.SocialBreadcrumbVO} 
	*/
	"get": function(alias, documentId, folderType) {}
};
com.fluig.sdk.service.CommunityService.prototype = {
	/**
	* Cria uma nova comunidade
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.CommunityVO} vo 
	* @returns {com.fluig.sdk.api.social.CommunityVO} 
	*/
	"create": function(vo) {}, 
	/**
	* Adiciona um usuário em uma comunidade
	* @memberOf fluigAPI
	* @param {long} communityId 
	* @param {String} alias 
	*/
	"addUser": function(communityId, alias) {}, 
	/**
	* Adiciona uma lista de usuários na comunidade
	* @memberOf fluigAPI
	* @param {String} communityAlias 
	* @param {List} users 
	*/
	"addUsers": function(communityAlias, users) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.CommunityVO} vo 
	* @returns {com.fluig.sdk.api.social.CommunityVO} 
	*/
	"update": function(vo) {}, 
	/**
	* Desabilita a edição de post para todas as comunidades, incluindo no papel de usuario
	* @memberOf fluigAPI
	*/
	"disablePostEditionAllCommunities": function() {}
};
CommunityService.prototype = {
	/**
	* Cria uma nova comunidade
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.CommunityVO} vo 
	* @returns {com.fluig.sdk.api.social.CommunityVO} 
	*/
	"create": function(vo) {}, 
	/**
	* Adiciona um usuário em uma comunidade
	* @memberOf fluigAPI
	* @param {long} communityId 
	* @param {String} alias 
	*/
	"addUser": function(communityId, alias) {}, 
	/**
	* Adiciona uma lista de usuários na comunidade
	* @memberOf fluigAPI
	* @param {String} communityAlias 
	* @param {List} users 
	*/
	"addUsers": function(communityAlias, users) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.CommunityVO} vo 
	* @returns {com.fluig.sdk.api.social.CommunityVO} 
	*/
	"update": function(vo) {}, 
	/**
	* Desabilita a edição de post para todas as comunidades, incluindo no papel de usuario
	* @memberOf fluigAPI
	*/
	"disablePostEditionAllCommunities": function() {}
};
com.fluig.sdk.service.GlobalParameterService.prototype = {
	/**
	* Retorna o tamanho configurado, do máximo de upload pelo fluig Connect
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getMaxUploadSizeForConnect": function() {}, 
	/**
	* Seta o tamanho máximo de upload via fluig Connect
	* @memberOf fluigAPI
	* @param {int} size 
	*/
	"setMaxUploadsizeForConnect": function(size) {}
};
GlobalParameterService.prototype = {
	/**
	* Retorna o tamanho configurado, do máximo de upload pelo fluig Connect
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getMaxUploadSizeForConnect": function() {}, 
	/**
	* Seta o tamanho máximo de upload via fluig Connect
	* @memberOf fluigAPI
	* @param {int} size 
	*/
	"setMaxUploadsizeForConnect": function(size) {}
};
com.fluig.sdk.service.FavoritesService.prototype = {
	/**
	* Busca os documentos favoritos
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentVO&gt;} 
	*/
	"findFavoritesDocuments": function(colleagueId) {}, 
	/**
	* Busca os processos favoritos
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessDefinitionVersionVO&gt;} 
	*/
	"findFavoritesProcess": function(colleagueId) {}
};
FavoritesService.prototype = {
	/**
	* Busca os documentos favoritos
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentVO&gt;} 
	*/
	"findFavoritesDocuments": function(colleagueId) {}, 
	/**
	* Busca os processos favoritos
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessDefinitionVersionVO&gt;} 
	*/
	"findFavoritesProcess": function(colleagueId) {}
};
com.fluig.sdk.service.TasksService.prototype = {
	/**
	* Busca os documentos para aprovação
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentVO&gt;} 
	*/
	"findDocumentsToApprove": function(colleagueId) {}, 
	/**
	* Busca os Documentos em aprovação
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentVO&gt;} 
	*/
	"findMyDocuments": function(colleagueId) {}, 
	/**
	* Busca todos os Documentos em aprovação por usuário
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentVO&gt;} 
	*/
	"findApprovalDocumentsByUser": function(colleagueId) {}, 
	/**
	* Solicitações Pendentes
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.workflow.WorkflowVO&gt;} 
	*/
	"findWorkflowTasks": function(colleagueId) {}, 
	/**
	* Solicitações Atrasadas
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.workflow.WorkflowVO&gt;} 
	*/
	"findExpiredWorkflowTasks": function(colleagueId) {}, 
	/**
	* Minhas solicitações abertas
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.workflow.WorkflowVO&gt;} 
	*/
	"findMyRequests": function(colleagueId) {}, 
	/**
	* Tarefas em consenso
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.workflow.WorkflowVO&gt;} 
	*/
	"findTasksInAgreement": function(colleagueId) {}, 
	/**
	* Procura por documentos em consenso
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentTaskVO&gt;} 
	*/
	"findDocsInAgreement": function(colleagueId) {}, 
	/**
	* Procura documentos em checkout
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentTaskVO&gt;} 
	*/
	"findDocsInCheckout": function(colleagueId) {}, 
	/**
	* Count all open tasks that matches with kind and status
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @param {com.fluig.sdk.api.task.TaskKindEnum} kind 
	* @returns {int} 
	*/
	"getCountOpenTasksByKind": function(colleagueId, kind) {}, 
	/**
	* Count all open tasks that matches with kind and status
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @param {com.fluig.sdk.api.task.TaskKindEnum} kind 
	* @param {com.fluig.sdk.api.task.TaskStatusEnum} status 
	* @param {List} processes 
	* @returns {int} 
	*/
	"getCountOpenTasksByKind": function(colleagueId, kind, status, processes) {}, 
	/**
	* Count all my requests for the specified user
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @param {List} processes 
	* @returns {int} 
	*/
	"getCountMyActiveRequests": function(colleagueId, processes) {}, 
	/**
	* Gets all groups and roles which contains tasks in pool
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @param {List} processes 
	* @returns {Map&lt;String,long&gt;} 
	*/
	"getOpenWorkflowTasksInPool": function(colleagueId, processes) {}, 
	/**
	* Find and count all pending documents
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {int} 
	*/
	"getCountMyDocuments": function(colleagueId) {}, 
	/**
	* Gets and mount the entire VO with related groups or roles inside the object
	* @memberOf fluigAPI
	* @param {Map} openInPool 
	* @returns {List&lt;com.fluig.sdk.api.task.ResumedTasksVO&gt;} 
	*/
	"getResumedTasksForPool": function(openInPool) {}, 
	/**
	* Transfer tasks from one user to another
	* @memberOf fluigAPI
	* @param {Map} transferOptions 
	* @returns {String} 
	*/
	"transferTasks": function(transferOptions) {}, 
	/**
	* Return users pendent to approve a document
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentApproverVO&gt;} 
	*/
	"getPendentApprovals": function(documentId) {}
};
TasksService.prototype = {
	/**
	* Busca os documentos para aprovação
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentVO&gt;} 
	*/
	"findDocumentsToApprove": function(colleagueId) {}, 
	/**
	* Busca os Documentos em aprovação
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentVO&gt;} 
	*/
	"findMyDocuments": function(colleagueId) {}, 
	/**
	* Busca todos os Documentos em aprovação por usuário
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentVO&gt;} 
	*/
	"findApprovalDocumentsByUser": function(colleagueId) {}, 
	/**
	* Solicitações Pendentes
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.workflow.WorkflowVO&gt;} 
	*/
	"findWorkflowTasks": function(colleagueId) {}, 
	/**
	* Solicitações Atrasadas
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.workflow.WorkflowVO&gt;} 
	*/
	"findExpiredWorkflowTasks": function(colleagueId) {}, 
	/**
	* Minhas solicitações abertas
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.workflow.WorkflowVO&gt;} 
	*/
	"findMyRequests": function(colleagueId) {}, 
	/**
	* Tarefas em consenso
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.workflow.WorkflowVO&gt;} 
	*/
	"findTasksInAgreement": function(colleagueId) {}, 
	/**
	* Procura por documentos em consenso
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentTaskVO&gt;} 
	*/
	"findDocsInAgreement": function(colleagueId) {}, 
	/**
	* Procura documentos em checkout
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentTaskVO&gt;} 
	*/
	"findDocsInCheckout": function(colleagueId) {}, 
	/**
	* Count all open tasks that matches with kind and status
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @param {com.fluig.sdk.api.task.TaskKindEnum} kind 
	* @returns {int} 
	*/
	"getCountOpenTasksByKind": function(colleagueId, kind) {}, 
	/**
	* Count all open tasks that matches with kind and status
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @param {com.fluig.sdk.api.task.TaskKindEnum} kind 
	* @param {com.fluig.sdk.api.task.TaskStatusEnum} status 
	* @param {List} processes 
	* @returns {int} 
	*/
	"getCountOpenTasksByKind": function(colleagueId, kind, status, processes) {}, 
	/**
	* Count all my requests for the specified user
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @param {List} processes 
	* @returns {int} 
	*/
	"getCountMyActiveRequests": function(colleagueId, processes) {}, 
	/**
	* Gets all groups and roles which contains tasks in pool
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @param {List} processes 
	* @returns {Map&lt;String,long&gt;} 
	*/
	"getOpenWorkflowTasksInPool": function(colleagueId, processes) {}, 
	/**
	* Find and count all pending documents
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	* @returns {int} 
	*/
	"getCountMyDocuments": function(colleagueId) {}, 
	/**
	* Gets and mount the entire VO with related groups or roles inside the object
	* @memberOf fluigAPI
	* @param {Map} openInPool 
	* @returns {List&lt;com.fluig.sdk.api.task.ResumedTasksVO&gt;} 
	*/
	"getResumedTasksForPool": function(openInPool) {}, 
	/**
	* Transfer tasks from one user to another
	* @memberOf fluigAPI
	* @param {Map} transferOptions 
	* @returns {String} 
	*/
	"transferTasks": function(transferOptions) {}, 
	/**
	* Return users pendent to approve a document
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentApproverVO&gt;} 
	*/
	"getPendentApprovals": function(documentId) {}
};
com.fluig.sdk.service.CollaborationSDKService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.ecm.CollaborationAppVO&gt;} 
	*/
	"listApps": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} appKey 
	* @returns {com.fluig.sdk.api.ecm.CollaborationAppVO} 
	*/
	"getApp": function(appKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} appKey 
	* @param {com.fluig.sdk.api.ecm.CollaborationVO} collaborateVO 
	* @returns {String} 
	*/
	"startCollaboration": function(appKey, collaborateVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} appKey 
	* @param {com.fluig.sdk.api.ecm.CollaborationVO} collaborationVO 
	* @returns {Map&lt;String,&gt;} 
	*/
	"uploadFlow": function(appKey, collaborationVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} appKey 
	* @param {com.fluig.sdk.api.ecm.CollaborationVO} collaborateVO 
	* @returns {String} 
	*/
	"startGuestCollaboration": function(appKey, collaborateVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} appKey 
	* @param {String} guestCode 
	* @param {com.fluig.sdk.api.ecm.CollaborationVO} collaborateVO 
	* @returns {Map&lt;String,&gt;} 
	*/
	"startEditingByGuest": function(appKey, guestCode, collaborateVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.ecm.CollaborationAppVO} vo 
	* @returns {com.fluig.sdk.api.ecm.CollaborationAppVO} 
	*/
	"updateApp": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} collaborationId 
	* @param {List} guests 
	*/
	"addGuests": function(collaborationId, guests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @param {int} documentVersion 
	* @returns {Map&lt;String,&gt;} 
	*/
	"getCollaborationStatus": function(documentId, documentVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} appKey 
	* @returns {String} 
	*/
	"checkConnect": function(appKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} collaborationId 
	* @param {String} pattern 
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.user.UserVO&gt;} 
	*/
	"listCollaborators": function(collaborationId, pattern, limit, offset) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} collaborationId 
	* @returns {com.fluig.sdk.api.ecm.CollaborationVO} 
	*/
	"findCollaborationById": function(collaborationId) {}
};
CollaborationSDKService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.ecm.CollaborationAppVO&gt;} 
	*/
	"listApps": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} appKey 
	* @returns {com.fluig.sdk.api.ecm.CollaborationAppVO} 
	*/
	"getApp": function(appKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} appKey 
	* @param {com.fluig.sdk.api.ecm.CollaborationVO} collaborateVO 
	* @returns {String} 
	*/
	"startCollaboration": function(appKey, collaborateVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} appKey 
	* @param {com.fluig.sdk.api.ecm.CollaborationVO} collaborationVO 
	* @returns {Map&lt;String,&gt;} 
	*/
	"uploadFlow": function(appKey, collaborationVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} appKey 
	* @param {com.fluig.sdk.api.ecm.CollaborationVO} collaborateVO 
	* @returns {String} 
	*/
	"startGuestCollaboration": function(appKey, collaborateVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} appKey 
	* @param {String} guestCode 
	* @param {com.fluig.sdk.api.ecm.CollaborationVO} collaborateVO 
	* @returns {Map&lt;String,&gt;} 
	*/
	"startEditingByGuest": function(appKey, guestCode, collaborateVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.ecm.CollaborationAppVO} vo 
	* @returns {com.fluig.sdk.api.ecm.CollaborationAppVO} 
	*/
	"updateApp": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} collaborationId 
	* @param {List} guests 
	*/
	"addGuests": function(collaborationId, guests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} documentId 
	* @param {int} documentVersion 
	* @returns {Map&lt;String,&gt;} 
	*/
	"getCollaborationStatus": function(documentId, documentVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} appKey 
	* @returns {String} 
	*/
	"checkConnect": function(appKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} collaborationId 
	* @param {String} pattern 
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.user.UserVO&gt;} 
	*/
	"listCollaborators": function(collaborationId, pattern, limit, offset) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} collaborationId 
	* @returns {com.fluig.sdk.api.ecm.CollaborationVO} 
	*/
	"findCollaborationById": function(collaborationId) {}
};
com.fluig.sdk.service.IdentityService.prototype = {
	/**
	* Retorna o uma nova sessão do identity
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.identity.UserAuthTokenSessionVO} 
	*/
	"createSession": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"updateSession": function() {}
};
IdentityService.prototype = {
	/**
	* Retorna o uma nova sessão do identity
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.identity.UserAuthTokenSessionVO} 
	*/
	"createSession": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"updateSession": function() {}
};
com.fluig.sdk.service.AlertService.prototype = {
	/**
	* Get the number of notification in the tenant
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantTotalOfNotification": function() {}, 
	/**
	* Retorna todas as notificações do usuário logado ordenadas pela data de criação
	* @memberOf fluigAPI
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.api.alert.AlertVO&gt;} 
	*/
	"listAllAlerts": function(limit, offset) {}, 
	/**
	* Busca os alertas com nota, do usuário logado ordenado pela data de criação
	* @memberOf fluigAPI
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.api.alert.AlertVO&gt;} 
	*/
	"listAlertsWithNote": function(limit, offset) {}, 
	/**
	* Busca os alertas com ação vinculada, do usuário logado ordenado pela data de criação
	* @memberOf fluigAPI
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.api.alert.AlertVO&gt;} 
	*/
	"listAlertsWithAction": function(limit, offset) {}, 
	/**
	* Retorna todas as notificações de um usuário por um único módulo
	* @memberOf fluigAPI
	* @param {String} module 
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.api.alert.AlertVO&gt;} 
	*/
	"listAllAlertsByModule": function(module, limit, offset) {}, 
	/**
	* Método que deve ser invocado por todos os módulos do sistema para enviar alertas
	* @memberOf fluigAPI
	* @param {String} eventKey 
	* @param {String} loginSender 
	* @param {String} loginReceiver 
	* @param  object 
	* @param  place 
	* @param {List} actions 
	* @param {Map} metadata 
	*/
	"sendNotification": function(eventKey, loginSender, loginReceiver, object, place, actions, metadata) {}, 
	/**
	* Método que remove os alertas informados de um usuario tambem dado, esse método também é responsável por remover os senders, places e objects relacionado aos alertas
	* @memberOf fluigAPI
	* @param {String} loginSender 
	* @param {List} alertsId 
	*/
	"removeAlerts": function(loginSender, alertsId) {}, 
	/**
	* Método marca os alertas informados de um usuario tambem dado como lidos
	* @memberOf fluigAPI
	* @param {String} loginReceiver 
	* @param {List} alertsId 
	*/
	"markAlertAsRead": function(loginReceiver, alertsId) {}, 
	/**
	* Método marca todos os alertas de um usuario como lidos
	* @memberOf fluigAPI
	* @param {String} loginReceiver 
	*/
	"markAllAlertsAsRead": function(loginReceiver) {}, 
	/**
	* Método que conta os alertas não lidos de um usuário
	* @memberOf fluigAPI
	* @param {long} receiverId 
	* @returns {long} 
	*/
	"countUnreadAlerts": function(receiverId) {}, 
	/**
	* Método que conta os alertas de um modulo não lidos de um usuário
	* @memberOf fluigAPI
	* @param {String} module 
	* @param {long} receiverId 
	* @returns {long} 
	*/
	"countUnreadAlertsByModule": function(module, receiverId) {}, 
	/**
	* Salva a configuração de um usuário para receber ou não alertas de um dado evento através de um dado aplicativo
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.alert.AlertConfigVO} alertConfig 
	*/
	"saveConfiguration": function(alertConfig) {}
};
AlertService.prototype = {
	/**
	* Get the number of notification in the tenant
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantTotalOfNotification": function() {}, 
	/**
	* Retorna todas as notificações do usuário logado ordenadas pela data de criação
	* @memberOf fluigAPI
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.api.alert.AlertVO&gt;} 
	*/
	"listAllAlerts": function(limit, offset) {}, 
	/**
	* Busca os alertas com nota, do usuário logado ordenado pela data de criação
	* @memberOf fluigAPI
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.api.alert.AlertVO&gt;} 
	*/
	"listAlertsWithNote": function(limit, offset) {}, 
	/**
	* Busca os alertas com ação vinculada, do usuário logado ordenado pela data de criação
	* @memberOf fluigAPI
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.api.alert.AlertVO&gt;} 
	*/
	"listAlertsWithAction": function(limit, offset) {}, 
	/**
	* Retorna todas as notificações de um usuário por um único módulo
	* @memberOf fluigAPI
	* @param {String} module 
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.api.alert.AlertVO&gt;} 
	*/
	"listAllAlertsByModule": function(module, limit, offset) {}, 
	/**
	* Método que deve ser invocado por todos os módulos do sistema para enviar alertas
	* @memberOf fluigAPI
	* @param {String} eventKey 
	* @param {String} loginSender 
	* @param {String} loginReceiver 
	* @param  object 
	* @param  place 
	* @param {List} actions 
	* @param {Map} metadata 
	*/
	"sendNotification": function(eventKey, loginSender, loginReceiver, object, place, actions, metadata) {}, 
	/**
	* Método que remove os alertas informados de um usuario tambem dado, esse método também é responsável por remover os senders, places e objects relacionado aos alertas
	* @memberOf fluigAPI
	* @param {String} loginSender 
	* @param {List} alertsId 
	*/
	"removeAlerts": function(loginSender, alertsId) {}, 
	/**
	* Método marca os alertas informados de um usuario tambem dado como lidos
	* @memberOf fluigAPI
	* @param {String} loginReceiver 
	* @param {List} alertsId 
	*/
	"markAlertAsRead": function(loginReceiver, alertsId) {}, 
	/**
	* Método marca todos os alertas de um usuario como lidos
	* @memberOf fluigAPI
	* @param {String} loginReceiver 
	*/
	"markAllAlertsAsRead": function(loginReceiver) {}, 
	/**
	* Método que conta os alertas não lidos de um usuário
	* @memberOf fluigAPI
	* @param {long} receiverId 
	* @returns {long} 
	*/
	"countUnreadAlerts": function(receiverId) {}, 
	/**
	* Método que conta os alertas de um modulo não lidos de um usuário
	* @memberOf fluigAPI
	* @param {String} module 
	* @param {long} receiverId 
	* @returns {long} 
	*/
	"countUnreadAlertsByModule": function(module, receiverId) {}, 
	/**
	* Salva a configuração de um usuário para receber ou não alertas de um dado evento através de um dado aplicativo
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.alert.AlertConfigVO} alertConfig 
	*/
	"saveConfiguration": function(alertConfig) {}
};
com.fluig.sdk.service.AuthorizeClientSdkService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.authorizeclient.AuthorizeClientSdkServiceVO} vo 
	* @returns {com.fluig.sdk.api.authorizeclient.AuthorizeClientSdkServiceVO} 
	*/
	"invoke": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} data 
	* @returns {com.fluig.sdk.api.authorizeclient.AuthorizeClientSdkServiceVO} 
	*/
	"invoke": function(data) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.oauth.OAuthSdkVO} vo 
	* @returns {com.fluig.sdk.api.oauth.OAuthSdkVO} 
	*/
	"create": function(vo) {}
};
AuthorizeClientSdkService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.authorizeclient.AuthorizeClientSdkServiceVO} vo 
	* @returns {com.fluig.sdk.api.authorizeclient.AuthorizeClientSdkServiceVO} 
	*/
	"invoke": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} data 
	* @returns {com.fluig.sdk.api.authorizeclient.AuthorizeClientSdkServiceVO} 
	*/
	"invoke": function(data) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.oauth.OAuthSdkVO} vo 
	* @returns {com.fluig.sdk.api.oauth.OAuthSdkVO} 
	*/
	"create": function(vo) {}
};
com.fluig.sdk.service.TagsCloudService.prototype = {
	/**
	* Pesquisa por TAGS mais populares baseado em um conjunto de parâmetros
	* @memberOf fluigAPI
	* @param {String} query 
	* @param {String} filterQuery 
	* @param {List} communitiesAlias 
	* @param {int} limit 
	* @param {String} login 
	* @returns {Map&lt;String,long&gt;} 
	*/
	"getTags": function(query, filterQuery, communitiesAlias, limit, login) {}
};
TagsCloudService.prototype = {
	/**
	* Pesquisa por TAGS mais populares baseado em um conjunto de parâmetros
	* @memberOf fluigAPI
	* @param {String} query 
	* @param {String} filterQuery 
	* @param {List} communitiesAlias 
	* @param {int} limit 
	* @param {String} login 
	* @returns {Map&lt;String,long&gt;} 
	*/
	"getTags": function(query, filterQuery, communitiesAlias, limit, login) {}
};
com.fluig.sdk.service.CommentService.prototype = {
	/**
	* Edit a single comment
	* @memberOf fluigAPI
	* @param {long} commentId 
	* @param {String} text 
	*/
	"editComment": function(commentId, text) {}, 
	/**
	* Find a single comment
	* @memberOf fluigAPI
	* @param {long} sociableId 
	* @returns {com.fluig.sdk.api.social.CommentVO} 
	*/
	"findComment": function(sociableId) {}
};
CommentService.prototype = {
	/**
	* Edit a single comment
	* @memberOf fluigAPI
	* @param {long} commentId 
	* @param {String} text 
	*/
	"editComment": function(commentId, text) {}, 
	/**
	* Find a single comment
	* @memberOf fluigAPI
	* @param {long} sociableId 
	* @returns {com.fluig.sdk.api.social.CommentVO} 
	*/
	"findComment": function(sociableId) {}
};
com.fluig.sdk.service.SearchService.prototype = {
	/**
	* Retorna a pesquisa padrão, com os tipos de documentos encontrados em forma de lista
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.search.DefaultSearchRequest} request 
	* @returns {com.fluig.sdk.api.search.DefaultSearchResponse} 
	*/
	"search": function(request) {}, 
	/**
	* Retorna lista de influenciadores para um assunto(#tag)
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.search.DefaultSearchRequest} search 
	* @returns {com.fluig.sdk.api.search.DefaultSearchResponse} 
	*/
	"findInfluencers": function(search) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} search 
	* @returns {com.fluig.sdk.api.search.DefaultSearchResponse} 
	*/
	"findInfluencers": function(search) {}, 
	/**
	* Retorna uma lista de resultados agrupadas
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.search.DefaultSearchRequest} request 
	* @returns {List&lt;Map,String,&gt;} 
	*/
	"groupedSearch": function(request) {}, 
	/**
	* Retorna uma lista de resultados agrupadas por tipo
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.search.DefaultSearchRequest} request 
	* @returns {List&lt;Map,String,&gt;} 
	*/
	"groupedSearchByType": function(request) {}
};
SearchService.prototype = {
	/**
	* Retorna a pesquisa padrão, com os tipos de documentos encontrados em forma de lista
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.search.DefaultSearchRequest} request 
	* @returns {com.fluig.sdk.api.search.DefaultSearchResponse} 
	*/
	"search": function(request) {}, 
	/**
	* Retorna lista de influenciadores para um assunto(#tag)
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.search.DefaultSearchRequest} search 
	* @returns {com.fluig.sdk.api.search.DefaultSearchResponse} 
	*/
	"findInfluencers": function(search) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} search 
	* @returns {com.fluig.sdk.api.search.DefaultSearchResponse} 
	*/
	"findInfluencers": function(search) {}, 
	/**
	* Retorna uma lista de resultados agrupadas
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.search.DefaultSearchRequest} request 
	* @returns {List&lt;Map,String,&gt;} 
	*/
	"groupedSearch": function(request) {}, 
	/**
	* Retorna uma lista de resultados agrupadas por tipo
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.search.DefaultSearchRequest} request 
	* @returns {List&lt;Map,String,&gt;} 
	*/
	"groupedSearchByType": function(request) {}
};
com.fluig.sdk.service.SocialSDKService.prototype = {
	/**
	* Find social user by id
	* @memberOf fluigAPI
	* @param {long} userId 
	* @returns {com.fluig.sdk.api.social.SocialVO} 
	*/
	"findSocialUser": function(userId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} alias 
	* @returns {com.fluig.sdk.api.social.SocialVO} 
	*/
	"findSocialVOByAlias": function(alias) {}
};
SocialSDKService.prototype = {
	/**
	* Find social user by id
	* @memberOf fluigAPI
	* @param {long} userId 
	* @returns {com.fluig.sdk.api.social.SocialVO} 
	*/
	"findSocialUser": function(userId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} alias 
	* @returns {com.fluig.sdk.api.social.SocialVO} 
	*/
	"findSocialVOByAlias": function(alias) {}
};
com.fluig.sdk.service.WidgetService.prototype = {
	/**
	* Remove as permissões gerais de uma widget
	* @memberOf fluigAPI
	* @param {String} widgetCode 
	*/
	"revokeWidgetPermission": function(widgetCode) {}, 
	/**
	* Adiciona as permissões padrão de um widget
	* @memberOf fluigAPI
	* @param {String} widgetCode 
	*/
	"grantWidgetDefaultPermission": function(widgetCode) {}, 
	/**
	* Busca pelas permissões em banco de uma determinada widget
	* @memberOf fluigAPI
	* @param {String} widgetCode 
	* @returns {Map&lt;String,&gt;} 
	*/
	"findWidgetPermissionList": function(widgetCode) {}, 
	/**
	* Lista as permissões de todas as widgets
	* @memberOf fluigAPI
	* @returns {List&lt;&gt;} 
	*/
	"listAllWidgetsPermission": function() {}, 
	/**
	* Busca códigos de recursos que não devem ser listados
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"searchForbiddenResourceCodes": function() {}
};
WidgetService.prototype = {
	/**
	* Remove as permissões gerais de uma widget
	* @memberOf fluigAPI
	* @param {String} widgetCode 
	*/
	"revokeWidgetPermission": function(widgetCode) {}, 
	/**
	* Adiciona as permissões padrão de um widget
	* @memberOf fluigAPI
	* @param {String} widgetCode 
	*/
	"grantWidgetDefaultPermission": function(widgetCode) {}, 
	/**
	* Busca pelas permissões em banco de uma determinada widget
	* @memberOf fluigAPI
	* @param {String} widgetCode 
	* @returns {Map&lt;String,&gt;} 
	*/
	"findWidgetPermissionList": function(widgetCode) {}, 
	/**
	* Lista as permissões de todas as widgets
	* @memberOf fluigAPI
	* @returns {List&lt;&gt;} 
	*/
	"listAllWidgetsPermission": function() {}, 
	/**
	* Busca códigos de recursos que não devem ser listados
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"searchForbiddenResourceCodes": function() {}
};
com.fluig.sdk.service.ContentService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ContentVO} contentVO 
	* @returns {com.fluig.sdk.api.lms.ContentVO} 
	*/
	"create": function(contentVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ContentVO} contentVO 
	* @returns {com.fluig.sdk.api.lms.ContentVO} 
	*/
	"edit": function(contentVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} contentId 
	*/
	"delete": function(contentId) {}
};
ContentService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ContentVO} contentVO 
	* @returns {com.fluig.sdk.api.lms.ContentVO} 
	*/
	"create": function(contentVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ContentVO} contentVO 
	* @returns {com.fluig.sdk.api.lms.ContentVO} 
	*/
	"edit": function(contentVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} contentId 
	*/
	"delete": function(contentId) {}
};
com.fluig.sdk.service.AssessmentApplicationService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} email 
	* @param {long} assessmentScheduleId 
	* @returns {com.fluig.sdk.api.lms.AssessmentApplicationFinishedVO} 
	*/
	"getFinishedApplication": function(email, assessmentScheduleId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"updateAllAssessmentToStatisticModel": function() {}
};
AssessmentApplicationService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} email 
	* @param {long} assessmentScheduleId 
	* @returns {com.fluig.sdk.api.lms.AssessmentApplicationFinishedVO} 
	*/
	"getFinishedApplication": function(email, assessmentScheduleId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"updateAllAssessmentToStatisticModel": function() {}
};
com.fluig.sdk.service.AssessmentScheduleService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.AssessmentScheduleVO} assessmentScheduleVO 
	* @returns {long} 
	*/
	"create": function(assessmentScheduleVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.AssessmentScheduleEmailVO} emailVO 
	* @returns {long} 
	*/
	"createForEmails": function(emailVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} assessmentScheduleId 
	*/
	"cancel": function(assessmentScheduleId) {}
};
AssessmentScheduleService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.AssessmentScheduleVO} assessmentScheduleVO 
	* @returns {long} 
	*/
	"create": function(assessmentScheduleVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.AssessmentScheduleEmailVO} emailVO 
	* @returns {long} 
	*/
	"createForEmails": function(emailVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} assessmentScheduleId 
	*/
	"cancel": function(assessmentScheduleId) {}
};
com.fluig.sdk.service.DisciplineService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.DisciplineVO} disciplineVO 
	* @returns {com.fluig.sdk.api.lms.DisciplineVO} 
	*/
	"create": function(disciplineVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.DisciplineVO} disciplineVO 
	* @returns {com.fluig.sdk.api.lms.DisciplineVO} 
	*/
	"edit": function(disciplineVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} disciplineId 
	*/
	"delete": function(disciplineId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} disciplineId 
	* @param {long} folderId 
	*/
	"move": function(disciplineId, folderId) {}
};
DisciplineService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.DisciplineVO} disciplineVO 
	* @returns {com.fluig.sdk.api.lms.DisciplineVO} 
	*/
	"create": function(disciplineVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.DisciplineVO} disciplineVO 
	* @returns {com.fluig.sdk.api.lms.DisciplineVO} 
	*/
	"edit": function(disciplineVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} disciplineId 
	*/
	"delete": function(disciplineId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} disciplineId 
	* @param {long} folderId 
	*/
	"move": function(disciplineId, folderId) {}
};
com.fluig.sdk.service.EnrollmentService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} enrollmentId 
	*/
	"cancel": function(enrollmentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} enrollmentId 
	*/
	"block": function(enrollmentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} enrollmentId 
	*/
	"unblock": function(enrollmentId) {}
};
EnrollmentService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} enrollmentId 
	*/
	"cancel": function(enrollmentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} enrollmentId 
	*/
	"block": function(enrollmentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} enrollmentId 
	*/
	"unblock": function(enrollmentId) {}
};
com.fluig.sdk.service.EnrollmentRequestService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.EnrollmentRequestVO} enrollmentRequestVO 
	* @returns {com.fluig.sdk.api.lms.EnrollmentRequestVO} 
	*/
	"create": function(enrollmentRequestVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} enrollmentRequestId 
	*/
	"cancel": function(enrollmentRequestId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} enrollmentRequestId 
	* @returns {com.fluig.sdk.api.lms.EnrollmentRequestVO} 
	*/
	"approve": function(enrollmentRequestId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ReproveRequestVO} reproveRequestVO 
	*/
	"reprove": function(reproveRequestVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.MultipleEnrollmentRequestVO} requestVO 
	* @returns {com.fluig.sdk.api.lms.EnrolledUsersResponseVO} 
	*/
	"createGroupRequest": function(requestVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.EnrollmentHistoryVO} enrollmentHistoryVO 
	* @returns {com.fluig.sdk.api.lms.EnrollmentHistoryVO} 
	*/
	"createEnrollmentHistory": function(enrollmentHistoryVO) {}
};
EnrollmentRequestService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.EnrollmentRequestVO} enrollmentRequestVO 
	* @returns {com.fluig.sdk.api.lms.EnrollmentRequestVO} 
	*/
	"create": function(enrollmentRequestVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} enrollmentRequestId 
	*/
	"cancel": function(enrollmentRequestId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} enrollmentRequestId 
	* @returns {com.fluig.sdk.api.lms.EnrollmentRequestVO} 
	*/
	"approve": function(enrollmentRequestId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ReproveRequestVO} reproveRequestVO 
	*/
	"reprove": function(reproveRequestVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.MultipleEnrollmentRequestVO} requestVO 
	* @returns {com.fluig.sdk.api.lms.EnrolledUsersResponseVO} 
	*/
	"createGroupRequest": function(requestVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.EnrollmentHistoryVO} enrollmentHistoryVO 
	* @returns {com.fluig.sdk.api.lms.EnrollmentHistoryVO} 
	*/
	"createEnrollmentHistory": function(enrollmentHistoryVO) {}
};
com.fluig.sdk.service.FolderDisciplineService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.FolderDisciplineVO} folderDisciplineVO 
	* @returns {com.fluig.sdk.api.lms.FolderDisciplineVO} 
	*/
	"create": function(folderDisciplineVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.FolderDisciplineVO} folderDisciplineVO 
	* @returns {com.fluig.sdk.api.lms.FolderDisciplineVO} 
	*/
	"edit": function(folderDisciplineVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} folderDisciplineId 
	*/
	"delete": function(folderDisciplineId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} folderDisciplineId 
	* @param {long} destinationId 
	*/
	"move": function(folderDisciplineId, destinationId) {}
};
FolderDisciplineService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.FolderDisciplineVO} folderDisciplineVO 
	* @returns {com.fluig.sdk.api.lms.FolderDisciplineVO} 
	*/
	"create": function(folderDisciplineVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.FolderDisciplineVO} folderDisciplineVO 
	* @returns {com.fluig.sdk.api.lms.FolderDisciplineVO} 
	*/
	"edit": function(folderDisciplineVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} folderDisciplineId 
	*/
	"delete": function(folderDisciplineId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} folderDisciplineId 
	* @param {long} destinationId 
	*/
	"move": function(folderDisciplineId, destinationId) {}
};
com.fluig.sdk.service.NormalClassService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.NormalClassVO} normalClassVO 
	* @returns {com.fluig.sdk.api.lms.NormalClassVO} 
	*/
	"create": function(normalClassVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.NormalClassVO} normalClassVO 
	* @returns {com.fluig.sdk.api.lms.NormalClassVO} 
	*/
	"edit": function(normalClassVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} normalClassId 
	*/
	"delete": function(normalClassId) {}
};
NormalClassService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.NormalClassVO} normalClassVO 
	* @returns {com.fluig.sdk.api.lms.NormalClassVO} 
	*/
	"create": function(normalClassVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.NormalClassVO} normalClassVO 
	* @returns {com.fluig.sdk.api.lms.NormalClassVO} 
	*/
	"edit": function(normalClassVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} normalClassId 
	*/
	"delete": function(normalClassId) {}
};
com.fluig.sdk.service.TrackService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.TrackVO} trackVO 
	* @returns {com.fluig.sdk.api.lms.TrackVO} 
	*/
	"create": function(trackVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.TrackVO} trackVO 
	* @returns {com.fluig.sdk.api.lms.TrackVO} 
	*/
	"edit": function(trackVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} trackId 
	*/
	"delete": function(trackId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} trackId 
	* @param {long} destinationId 
	*/
	"move": function(trackId, destinationId) {}
};
TrackService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.TrackVO} trackVO 
	* @returns {com.fluig.sdk.api.lms.TrackVO} 
	*/
	"create": function(trackVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.TrackVO} trackVO 
	* @returns {com.fluig.sdk.api.lms.TrackVO} 
	*/
	"edit": function(trackVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} trackId 
	*/
	"delete": function(trackId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} trackId 
	* @param {long} destinationId 
	*/
	"move": function(trackId, destinationId) {}
};
com.fluig.sdk.service.TrainingService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} trainingId 
	*/
	"delete": function(trainingId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} trainingId 
	* @param {long} destinationId 
	*/
	"move": function(trainingId, destinationId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.TrainingVO} trainingVO 
	* @returns {com.fluig.sdk.api.lms.TrainingVO} 
	*/
	"create": function(trainingVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.TrainingVO} trainingVO 
	* @returns {com.fluig.sdk.api.lms.TrainingVO} 
	*/
	"edit": function(trainingVO) {}
};
TrainingService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} trainingId 
	*/
	"delete": function(trainingId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} trainingId 
	* @param {long} destinationId 
	*/
	"move": function(trainingId, destinationId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.TrainingVO} trainingVO 
	* @returns {com.fluig.sdk.api.lms.TrainingVO} 
	*/
	"create": function(trainingVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.TrainingVO} trainingVO 
	* @returns {com.fluig.sdk.api.lms.TrainingVO} 
	*/
	"edit": function(trainingVO) {}
};
com.fluig.sdk.service.SkillService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.SkillVO} skillVO 
	* @returns {com.fluig.sdk.api.lms.SkillVO} 
	*/
	"create": function(skillVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.SkillVO} skillVO 
	* @returns {com.fluig.sdk.api.lms.SkillVO} 
	*/
	"edit": function(skillVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} skillId 
	*/
	"delete": function(skillId) {}
};
SkillService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.SkillVO} skillVO 
	* @returns {com.fluig.sdk.api.lms.SkillVO} 
	*/
	"create": function(skillVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.SkillVO} skillVO 
	* @returns {com.fluig.sdk.api.lms.SkillVO} 
	*/
	"edit": function(skillVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} skillId 
	*/
	"delete": function(skillId) {}
};
com.fluig.sdk.service.FolderService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.FolderVO} folderVO 
	* @returns {com.fluig.sdk.api.lms.FolderVO} 
	*/
	"create": function(folderVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.FolderVO} folderVO 
	* @returns {com.fluig.sdk.api.lms.FolderVO} 
	*/
	"edit": function(folderVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} folderId 
	*/
	"delete": function(folderId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} folderId 
	* @param {long} destinationId 
	*/
	"move": function(folderId, destinationId) {}
};
FolderService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.FolderVO} folderVO 
	* @returns {com.fluig.sdk.api.lms.FolderVO} 
	*/
	"create": function(folderVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.FolderVO} folderVO 
	* @returns {com.fluig.sdk.api.lms.FolderVO} 
	*/
	"edit": function(folderVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} folderId 
	*/
	"delete": function(folderId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} folderId 
	* @param {long} destinationId 
	*/
	"move": function(folderId, destinationId) {}
};
com.fluig.sdk.service.ObjectiveQuestionService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ObjectiveQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.ObjectiveQuestionVO} 
	*/
	"create": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ObjectiveQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.ObjectiveQuestionVO} 
	*/
	"edit": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	*/
	"delete": function(questionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} versionId 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(versionId, releaseNotes) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	* @param {long} topicId 
	*/
	"move": function(questionId, topicId) {}
};
ObjectiveQuestionService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ObjectiveQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.ObjectiveQuestionVO} 
	*/
	"create": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ObjectiveQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.ObjectiveQuestionVO} 
	*/
	"edit": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	*/
	"delete": function(questionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} versionId 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(versionId, releaseNotes) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	* @param {long} topicId 
	*/
	"move": function(questionId, topicId) {}
};
com.fluig.sdk.service.BlockService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.BlockVO} blockVO 
	* @returns {com.fluig.sdk.api.lms.BlockVO} 
	*/
	"create": function(blockVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.BlockVO} blockVO 
	* @returns {com.fluig.sdk.api.lms.BlockVO} 
	*/
	"edit": function(blockVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} blockId 
	*/
	"delete": function(blockId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {String} releaseNotes 
	*/
	"release": function(id, releaseNotes) {}
};
BlockService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.BlockVO} blockVO 
	* @returns {com.fluig.sdk.api.lms.BlockVO} 
	*/
	"create": function(blockVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.BlockVO} blockVO 
	* @returns {com.fluig.sdk.api.lms.BlockVO} 
	*/
	"edit": function(blockVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} blockId 
	*/
	"delete": function(blockId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {String} releaseNotes 
	*/
	"release": function(id, releaseNotes) {}
};
com.fluig.sdk.service.AssessmentTopicService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.AssessmentTopicVO} assessmentTopicVO 
	* @returns {com.fluig.sdk.api.lms.AssessmentTopicVO} 
	*/
	"create": function(assessmentTopicVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.AssessmentTopicVO} assessmentTopicVO 
	* @returns {com.fluig.sdk.api.lms.AssessmentTopicVO} 
	*/
	"edit": function(assessmentTopicVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} assessmentTopicId 
	*/
	"delete": function(assessmentTopicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} assessmentTopicId 
	* @param {long} destinationId 
	*/
	"move": function(assessmentTopicId, destinationId) {}
};
AssessmentTopicService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.AssessmentTopicVO} assessmentTopicVO 
	* @returns {com.fluig.sdk.api.lms.AssessmentTopicVO} 
	*/
	"create": function(assessmentTopicVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.AssessmentTopicVO} assessmentTopicVO 
	* @returns {com.fluig.sdk.api.lms.AssessmentTopicVO} 
	*/
	"edit": function(assessmentTopicVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} assessmentTopicId 
	*/
	"delete": function(assessmentTopicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} assessmentTopicId 
	* @param {long} destinationId 
	*/
	"move": function(assessmentTopicId, destinationId) {}
};
com.fluig.sdk.service.EssayQuestionService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.EssayQuestionVO} essayQuestionVO 
	* @returns {com.fluig.sdk.api.lms.EssayQuestionVO} 
	*/
	"create": function(essayQuestionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.EssayQuestionVO} essayQuestionVO 
	* @returns {com.fluig.sdk.api.lms.EssayQuestionVO} 
	*/
	"edit": function(essayQuestionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	*/
	"delete": function(questionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} essayQuestionId 
	* @param {long} destinationId 
	*/
	"move": function(essayQuestionId, destinationId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} versionId 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(versionId, releaseNotes) {}
};
EssayQuestionService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.EssayQuestionVO} essayQuestionVO 
	* @returns {com.fluig.sdk.api.lms.EssayQuestionVO} 
	*/
	"create": function(essayQuestionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.EssayQuestionVO} essayQuestionVO 
	* @returns {com.fluig.sdk.api.lms.EssayQuestionVO} 
	*/
	"edit": function(essayQuestionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	*/
	"delete": function(questionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} essayQuestionId 
	* @param {long} destinationId 
	*/
	"move": function(essayQuestionId, destinationId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} versionId 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(versionId, releaseNotes) {}
};
com.fluig.sdk.service.OrdinationQuestionService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.OrdinationQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.OrdinationQuestionVO} 
	*/
	"create": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.OrdinationQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.OrdinationQuestionVO} 
	*/
	"edit": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	*/
	"delete": function(questionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} versionId 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(versionId, releaseNotes) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	* @param {long} topicId 
	*/
	"move": function(questionId, topicId) {}
};
OrdinationQuestionService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.OrdinationQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.OrdinationQuestionVO} 
	*/
	"create": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.OrdinationQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.OrdinationQuestionVO} 
	*/
	"edit": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	*/
	"delete": function(questionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} versionId 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(versionId, releaseNotes) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	* @param {long} topicId 
	*/
	"move": function(questionId, topicId) {}
};
com.fluig.sdk.service.LacunaQuestionService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.LacunaQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.LacunaQuestionVO} 
	*/
	"create": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.LacunaQuestionVO} vo 
	* @returns {com.fluig.sdk.api.lms.LacunaQuestionVO} 
	*/
	"edit": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	*/
	"delete": function(questionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(id, releaseNotes) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	* @param {long} topicId 
	*/
	"move": function(questionId, topicId) {}
};
LacunaQuestionService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.LacunaQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.LacunaQuestionVO} 
	*/
	"create": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.LacunaQuestionVO} vo 
	* @returns {com.fluig.sdk.api.lms.LacunaQuestionVO} 
	*/
	"edit": function(vo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	*/
	"delete": function(questionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(id, releaseNotes) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	* @param {long} topicId 
	*/
	"move": function(questionId, topicId) {}
};
com.fluig.sdk.service.MultipleQuestionService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.MultipleQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.MultipleQuestionVO} 
	*/
	"create": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.MultipleQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.MultipleQuestionVO} 
	*/
	"edit": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	*/
	"delete": function(questionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} versionId 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(versionId, releaseNotes) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	* @param {long} topicId 
	*/
	"move": function(questionId, topicId) {}
};
MultipleQuestionService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.MultipleQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.MultipleQuestionVO} 
	*/
	"create": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.MultipleQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.MultipleQuestionVO} 
	*/
	"edit": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	*/
	"delete": function(questionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} versionId 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(versionId, releaseNotes) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	* @param {long} topicId 
	*/
	"move": function(questionId, topicId) {}
};
com.fluig.sdk.service.CorrelationQuestionService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.CorrelationQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.CorrelationQuestionVO} 
	*/
	"create": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.CorrelationQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.CorrelationQuestionVO} 
	*/
	"edit": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	*/
	"delete": function(questionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} versionId 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(versionId, releaseNotes) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	* @param {long} topicId 
	*/
	"move": function(questionId, topicId) {}
};
CorrelationQuestionService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.CorrelationQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.CorrelationQuestionVO} 
	*/
	"create": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.CorrelationQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.CorrelationQuestionVO} 
	*/
	"edit": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	*/
	"delete": function(questionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} versionId 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(versionId, releaseNotes) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	* @param {long} topicId 
	*/
	"move": function(questionId, topicId) {}
};
com.fluig.sdk.service.ScaleQuestionService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ScaleQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.ScaleQuestionVO} 
	*/
	"create": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ScaleQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.ScaleQuestionVO} 
	*/
	"edit": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	*/
	"delete": function(questionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} versionId 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(versionId, releaseNotes) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	* @param {long} topicId 
	*/
	"move": function(questionId, topicId) {}
};
ScaleQuestionService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ScaleQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.ScaleQuestionVO} 
	*/
	"create": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ScaleQuestionVO} questionVO 
	* @returns {com.fluig.sdk.api.lms.ScaleQuestionVO} 
	*/
	"edit": function(questionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	*/
	"delete": function(questionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} versionId 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(versionId, releaseNotes) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} questionId 
	* @param {long} topicId 
	*/
	"move": function(questionId, topicId) {}
};
com.fluig.sdk.service.AssessmentService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.AssessmentVO} assessmentVO 
	* @returns {com.fluig.sdk.api.lms.AssessmentVO} 
	*/
	"create": function(assessmentVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.AssessmentVO} assessmentVO 
	* @returns {com.fluig.sdk.api.lms.AssessmentVO} 
	*/
	"edit": function(assessmentVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} assessmentId 
	*/
	"delete": function(assessmentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(id, releaseNotes) {}
};
AssessmentService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.AssessmentVO} assessmentVO 
	* @returns {com.fluig.sdk.api.lms.AssessmentVO} 
	*/
	"create": function(assessmentVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.AssessmentVO} assessmentVO 
	* @returns {com.fluig.sdk.api.lms.AssessmentVO} 
	*/
	"edit": function(assessmentVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} assessmentId 
	*/
	"delete": function(assessmentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	* @param {String} releaseNotes 
	* @returns {long} 
	*/
	"release": function(id, releaseNotes) {}
};
com.fluig.sdk.service.FilterAPIService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} onlyMyFilters 
	* @param {boolean} findPublicFilters 
	* @param {String} pattern 
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.filter.FilterResultVO&gt;} 
	*/
	"getProcessFilters": function(onlyMyFilters, findPublicFilters, pattern, limit, offset) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} filterId 
	* @returns {com.fluig.sdk.filter.FilterResultVO} 
	*/
	"findById": function(filterId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} filterId 
	* @param {boolean} isPublic 
	* @returns {com.fluig.sdk.filter.FilterResultVO} 
	*/
	"updatePublicProcessFilter": function(filterId, isPublic) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} filtersId 
	*/
	"removeFilters": function(filtersId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.filter.FilterVO} filterVO 
	* @returns {com.fluig.sdk.filter.FilterResultVO} 
	*/
	"createFilter": function(filterVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.filter.FilterVO} filterVO 
	* @returns {com.fluig.sdk.filter.FilterResultVO} 
	*/
	"updateFilter": function(filterVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} filterId 
	* @param {String} pattern 
	* @param {int} limit 
	* @param {int} offset 
	* @param {String} orderBy 
	* @returns {List&lt;com.fluig.sdk.filter.FilterGroupResultVO&gt;} 
	*/
	"findFiltersGroupByFilterId": function(filterId, pattern, limit, offset, orderBy) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.filter.FilterGroupVO} filterGroupVO 
	* @returns {List&lt;com.fluig.sdk.filter.FilterGroupResultVO&gt;} 
	*/
	"saveFiltersGroup": function(filterGroupVO) {}
};
FilterAPIService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} onlyMyFilters 
	* @param {boolean} findPublicFilters 
	* @param {String} pattern 
	* @param {int} limit 
	* @param {int} offset 
	* @returns {List&lt;com.fluig.sdk.filter.FilterResultVO&gt;} 
	*/
	"getProcessFilters": function(onlyMyFilters, findPublicFilters, pattern, limit, offset) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} filterId 
	* @returns {com.fluig.sdk.filter.FilterResultVO} 
	*/
	"findById": function(filterId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} filterId 
	* @param {boolean} isPublic 
	* @returns {com.fluig.sdk.filter.FilterResultVO} 
	*/
	"updatePublicProcessFilter": function(filterId, isPublic) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} filtersId 
	*/
	"removeFilters": function(filtersId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.filter.FilterVO} filterVO 
	* @returns {com.fluig.sdk.filter.FilterResultVO} 
	*/
	"createFilter": function(filterVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.filter.FilterVO} filterVO 
	* @returns {com.fluig.sdk.filter.FilterResultVO} 
	*/
	"updateFilter": function(filterVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} filterId 
	* @param {String} pattern 
	* @param {int} limit 
	* @param {int} offset 
	* @param {String} orderBy 
	* @returns {List&lt;com.fluig.sdk.filter.FilterGroupResultVO&gt;} 
	*/
	"findFiltersGroupByFilterId": function(filterId, pattern, limit, offset, orderBy) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.filter.FilterGroupVO} filterGroupVO 
	* @returns {List&lt;com.fluig.sdk.filter.FilterGroupResultVO&gt;} 
	*/
	"saveFiltersGroup": function(filterGroupVO) {}
};
com.fluig.sdk.service.LinkService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.LinkVO} linkId 
	* @returns {com.fluig.sdk.api.lms.LinkVO} 
	*/
	"create": function(linkId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.LinkVO} linkId 
	* @returns {com.fluig.sdk.api.lms.LinkVO} 
	*/
	"edit": function(linkId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} linkId 
	*/
	"delete": function(linkId) {}
};
LinkService.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.LinkVO} linkId 
	* @returns {com.fluig.sdk.api.lms.LinkVO} 
	*/
	"create": function(linkId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.LinkVO} linkId 
	* @returns {com.fluig.sdk.api.lms.LinkVO} 
	*/
	"edit": function(linkId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} linkId 
	*/
	"delete": function(linkId) {}
};
com.fluig.sdk.service.LMSTaskService.prototype = {
	/**
	* Returns the number of tasks of a given user
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"countUserTasks": function() {}, 
	/**
	* Returns the task list of a given user
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.LMSTaskVO&gt;} 
	*/
	"getUserTasks": function() {}, 
	/**
	* Returns the organized task list of a given user. The task list is grouped and sorted by task deadline
	* @memberOf fluigAPI
	* @returns {Map&lt;String,List,com.fluig.sdk.api.lms.LMSTaskVO&gt;} 
	*/
	"getOrganizedUserTasks": function() {}
};
LMSTaskService.prototype = {
	/**
	* Returns the number of tasks of a given user
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"countUserTasks": function() {}, 
	/**
	* Returns the task list of a given user
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.LMSTaskVO&gt;} 
	*/
	"getUserTasks": function() {}, 
	/**
	* Returns the organized task list of a given user. The task list is grouped and sorted by task deadline
	* @memberOf fluigAPI
	* @returns {Map&lt;String,List,com.fluig.sdk.api.lms.LMSTaskVO&gt;} 
	*/
	"getOrganizedUserTasks": function() {}
};
com.fluig.sdk.api.permission.PermissionAssetVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTypeCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} typeCode 
	*/
	"setTypeCode": function(typeCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPageCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	*/
	"setPageCode": function(pageCode) {}
};
PermissionAssetVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTypeCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} typeCode 
	*/
	"setTypeCode": function(typeCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPageCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	*/
	"setPageCode": function(pageCode) {}
};
com.fluig.sdk.api.permission.PermissionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} permission 
	*/
	"setPermission": function(permission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPermissionDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} permissionDescription 
	*/
	"setPermissionDescription": function(permissionDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIsSelected": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} isSelected 
	*/
	"setIsSelected": function(isSelected) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCategory": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} category 
	*/
	"setCategory": function(category) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCategoryCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} categoryCode 
	*/
	"setCategoryCode": function(categoryCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
PermissionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} permission 
	*/
	"setPermission": function(permission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPermissionDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} permissionDescription 
	*/
	"setPermissionDescription": function(permissionDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIsSelected": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} isSelected 
	*/
	"setIsSelected": function(isSelected) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCategory": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} category 
	*/
	"setCategory": function(category) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCategoryCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} categoryCode 
	*/
	"setCategoryCode": function(categoryCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.tenant.TenantVO.prototype = {
	/**
	* Recupera valor do id
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* Atribui valor para id
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* Recupera valor do code
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* Atribui valor para code
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* Recupera valor do federalId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFederalId": function() {}, 
	/**
	* Atribui valor para federalId
	* @memberOf fluigAPI
	* @param {String} federalId 
	*/
	"setFederalId": function(federalId) {}, 
	/**
	* Recupera valor do idpId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getIdpId": function() {}, 
	/**
	* Atribui valor para idpId
	* @memberOf fluigAPI
	* @param {String} idpId 
	*/
	"setIdpId": function(idpId) {}, 
	/**
	* Recupera valor do description
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* Atribui valor para description
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* Recupera valor do organizationUrl
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getOrganizationUrl": function() {}, 
	/**
	* Atribui valor para organizationUrl
	* @memberOf fluigAPI
	* @param {String} organizationUrl 
	*/
	"setOrganizationUrl": function(organizationUrl) {}, 
	/**
	* Recupera valor do volumeDir
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVolumeDir": function() {}, 
	/**
	* Atribui valor para volumeDir
	* @memberOf fluigAPI
	* @param {String} volumeDir 
	*/
	"setVolumeDir": function(volumeDir) {}, 
	/**
	* Recupera valor do idpLogOff
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIdpLogOff": function() {}, 
	/**
	* Atribui valor para idpLogOff
	* @memberOf fluigAPI
	* @param {boolean} idpLogOff 
	*/
	"setIdpLogOff": function(idpLogOff) {}, 
	/**
	* Recupera valor do thumbnailEnabled
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getThumbnailEnabled": function() {}, 
	/**
	* Atribui valor para thumbnailEnabled
	* @memberOf fluigAPI
	* @param {boolean} thumbnailEnabled 
	*/
	"setThumbnailEnabled": function(thumbnailEnabled) {}, 
	/**
	* Recupera valor do removeVolume
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getRemoveVolume": function() {}, 
	/**
	* Atribui valor para removeVolume
	* @memberOf fluigAPI
	* @param {boolean} removeVolume 
	*/
	"setRemoveVolume": function(removeVolume) {}, 
	/**
	* Recupera valor do data
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getData": function() {}, 
	/**
	* Atribui valor para data
	* @memberOf fluigAPI
	* @param {Map} data 
	*/
	"setData": function(data) {}, 
	/**
	* Recupera valor do adminUser
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.tenant.AdminUserVO} 
	*/
	"getAdminUser": function() {}, 
	/**
	* Atribui valor para adminUser
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.tenant.AdminUserVO} adminUser 
	*/
	"setAdminUser": function(adminUser) {}, 
	/**
	* Recupera o valor para tenantActive
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getTenantActive": function() {}, 
	/**
	* Atribui valor para tenantActive
	* @memberOf fluigAPI
	* @param {boolean} tenantActive 
	*/
	"setTenantActive": function(tenantActive) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
TenantVO.prototype = {
	/**
	* Recupera valor do id
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* Atribui valor para id
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* Recupera valor do code
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* Atribui valor para code
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* Recupera valor do federalId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFederalId": function() {}, 
	/**
	* Atribui valor para federalId
	* @memberOf fluigAPI
	* @param {String} federalId 
	*/
	"setFederalId": function(federalId) {}, 
	/**
	* Recupera valor do idpId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getIdpId": function() {}, 
	/**
	* Atribui valor para idpId
	* @memberOf fluigAPI
	* @param {String} idpId 
	*/
	"setIdpId": function(idpId) {}, 
	/**
	* Recupera valor do description
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* Atribui valor para description
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* Recupera valor do organizationUrl
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getOrganizationUrl": function() {}, 
	/**
	* Atribui valor para organizationUrl
	* @memberOf fluigAPI
	* @param {String} organizationUrl 
	*/
	"setOrganizationUrl": function(organizationUrl) {}, 
	/**
	* Recupera valor do volumeDir
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVolumeDir": function() {}, 
	/**
	* Atribui valor para volumeDir
	* @memberOf fluigAPI
	* @param {String} volumeDir 
	*/
	"setVolumeDir": function(volumeDir) {}, 
	/**
	* Recupera valor do idpLogOff
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIdpLogOff": function() {}, 
	/**
	* Atribui valor para idpLogOff
	* @memberOf fluigAPI
	* @param {boolean} idpLogOff 
	*/
	"setIdpLogOff": function(idpLogOff) {}, 
	/**
	* Recupera valor do thumbnailEnabled
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getThumbnailEnabled": function() {}, 
	/**
	* Atribui valor para thumbnailEnabled
	* @memberOf fluigAPI
	* @param {boolean} thumbnailEnabled 
	*/
	"setThumbnailEnabled": function(thumbnailEnabled) {}, 
	/**
	* Recupera valor do removeVolume
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getRemoveVolume": function() {}, 
	/**
	* Atribui valor para removeVolume
	* @memberOf fluigAPI
	* @param {boolean} removeVolume 
	*/
	"setRemoveVolume": function(removeVolume) {}, 
	/**
	* Recupera valor do data
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getData": function() {}, 
	/**
	* Atribui valor para data
	* @memberOf fluigAPI
	* @param {Map} data 
	*/
	"setData": function(data) {}, 
	/**
	* Recupera valor do adminUser
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.tenant.AdminUserVO} 
	*/
	"getAdminUser": function() {}, 
	/**
	* Atribui valor para adminUser
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.tenant.AdminUserVO} adminUser 
	*/
	"setAdminUser": function(adminUser) {}, 
	/**
	* Recupera o valor para tenantActive
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getTenantActive": function() {}, 
	/**
	* Atribui valor para tenantActive
	* @memberOf fluigAPI
	* @param {boolean} tenantActive 
	*/
	"setTenantActive": function(tenantActive) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.group.GroupVO.prototype = {
	/**
	* Recupera valor do id
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* Atribui valor para id
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* Recupera valor do code
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* Atribui valor para code
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* Recupera valor do description
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* Atribui valor para description
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* Recupera valor do isInternal
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIsInternal": function() {}, 
	/**
	* Atribui valor para isInternal
	* @memberOf fluigAPI
	* @param {boolean} isInternal 
	*/
	"setIsInternal": function(isInternal) {}, 
	/**
	* Recupera valor do groupType
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getGroupType": function() {}, 
	/**
	* Atribui valor para groupType
	* @memberOf fluigAPI
	* @param {String} groupType 
	*/
	"setGroupType": function(groupType) {}, 
	/**
	* Recupera valor do extData
	* @memberOf fluigAPI
	*/
	"getExtData": function() {}, 
	/**
	* Atribui valor para extData
	* @memberOf fluigAPI
	* @param  extData 
	*/
	"setExtData": function(extData) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
GroupVO.prototype = {
	/**
	* Recupera valor do id
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* Atribui valor para id
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* Recupera valor do code
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* Atribui valor para code
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* Recupera valor do description
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* Atribui valor para description
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* Recupera valor do isInternal
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIsInternal": function() {}, 
	/**
	* Atribui valor para isInternal
	* @memberOf fluigAPI
	* @param {boolean} isInternal 
	*/
	"setIsInternal": function(isInternal) {}, 
	/**
	* Recupera valor do groupType
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getGroupType": function() {}, 
	/**
	* Atribui valor para groupType
	* @memberOf fluigAPI
	* @param {String} groupType 
	*/
	"setGroupType": function(groupType) {}, 
	/**
	* Recupera valor do extData
	* @memberOf fluigAPI
	*/
	"getExtData": function() {}, 
	/**
	* Atribui valor para extData
	* @memberOf fluigAPI
	* @param  extData 
	*/
	"setExtData": function(extData) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.tenant.AdminUserVO.prototype = {
	/**
	* Recupera valor do login
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLogin": function() {}, 
	/**
	* Atribui valor para login
	* @memberOf fluigAPI
	* @param {String} login 
	*/
	"setLogin": function(login) {}, 
	/**
	* Recupera valor do code
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* Atribui valor para code
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* Recupera valor do email
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEmail": function() {}, 
	/**
	* Atribui valor para email
	* @memberOf fluigAPI
	* @param {String} email 
	*/
	"setEmail": function(email) {}, 
	/**
	* Recupera valor do password
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPassword": function() {}, 
	/**
	* Atribui valor para password
	* @memberOf fluigAPI
	* @param {String} password 
	*/
	"setPassword": function(password) {}, 
	/**
	* Recupera valor do firstName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFirstName": function() {}, 
	/**
	* Atribui valor para firstName
	* @memberOf fluigAPI
	* @param {String} firstName 
	*/
	"setFirstName": function(firstName) {}, 
	/**
	* Recupera valor do lastName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLastName": function() {}, 
	/**
	* Atribui valor para lastName
	* @memberOf fluigAPI
	* @param {String} lastName 
	*/
	"setLastName": function(lastName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
AdminUserVO.prototype = {
	/**
	* Recupera valor do login
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLogin": function() {}, 
	/**
	* Atribui valor para login
	* @memberOf fluigAPI
	* @param {String} login 
	*/
	"setLogin": function(login) {}, 
	/**
	* Recupera valor do code
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* Atribui valor para code
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* Recupera valor do email
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEmail": function() {}, 
	/**
	* Atribui valor para email
	* @memberOf fluigAPI
	* @param {String} email 
	*/
	"setEmail": function(email) {}, 
	/**
	* Recupera valor do password
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPassword": function() {}, 
	/**
	* Atribui valor para password
	* @memberOf fluigAPI
	* @param {String} password 
	*/
	"setPassword": function(password) {}, 
	/**
	* Recupera valor do firstName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFirstName": function() {}, 
	/**
	* Atribui valor para firstName
	* @memberOf fluigAPI
	* @param {String} firstName 
	*/
	"setFirstName": function(firstName) {}, 
	/**
	* Recupera valor do lastName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLastName": function() {}, 
	/**
	* Atribui valor para lastName
	* @memberOf fluigAPI
	* @param {String} lastName 
	*/
	"setLastName": function(lastName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.local.LocalVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTimezone": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} timezone 
	*/
	"setTimezone": function(timezone) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getLatitude": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  latitude 
	*/
	"setLatitude": function(latitude) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getLongitude": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  longitude 
	*/
	"setLongitude": function(longitude) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getRadius": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  radius 
	*/
	"setRadius": function(radius) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isDefaultLocale": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} defaultLocale 
	*/
	"setDefaultLocale": function(defaultLocale) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.local.LocalUserVO&gt;} 
	*/
	"getLocalUsers": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} localUsers 
	*/
	"setLocalUsers": function(localUsers) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getExpandables": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} expandables 
	*/
	"setExpandables": function(expandables) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.holiday.HolidayVO&gt;} 
	*/
	"getHolidays": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} holidays 
	*/
	"setHolidays": function(holidays) {}
};
LocalVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTimezone": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} timezone 
	*/
	"setTimezone": function(timezone) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getLatitude": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  latitude 
	*/
	"setLatitude": function(latitude) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getLongitude": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  longitude 
	*/
	"setLongitude": function(longitude) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getRadius": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  radius 
	*/
	"setRadius": function(radius) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isDefaultLocale": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} defaultLocale 
	*/
	"setDefaultLocale": function(defaultLocale) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.local.LocalUserVO&gt;} 
	*/
	"getLocalUsers": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} localUsers 
	*/
	"setLocalUsers": function(localUsers) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getExpandables": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} expandables 
	*/
	"setExpandables": function(expandables) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.holiday.HolidayVO&gt;} 
	*/
	"getHolidays": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} holidays 
	*/
	"setHolidays": function(holidays) {}
};
com.fluig.sdk.api.local.LocalUserVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} userCode 
	*/
	"setUserCode": function(userCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getLocalId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} localId 
	*/
	"setLocalId": function(localId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} userName 
	*/
	"setUserName": function(userName) {}
};
LocalUserVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} userCode 
	*/
	"setUserCode": function(userCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getLocalId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} localId 
	*/
	"setLocalId": function(localId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} userName 
	*/
	"setUserName": function(userName) {}
};
com.fluig.sdk.api.holiday.HolidayVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} date 
	*/
	"setDate": function(date) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isRecurrent": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} recurrent 
	*/
	"setRecurrent": function(recurrent) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.local.LocalVO&gt;} 
	*/
	"getLocals": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} locals 
	*/
	"setLocals": function(locals) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getExpandables": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} expandables 
	*/
	"setExpandables": function(expandables) {}
};
HolidayVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} date 
	*/
	"setDate": function(date) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isRecurrent": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} recurrent 
	*/
	"setRecurrent": function(recurrent) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.local.LocalVO&gt;} 
	*/
	"getLocals": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} locals 
	*/
	"setLocals": function(locals) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getExpandables": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} expandables 
	*/
	"setExpandables": function(expandables) {}
};
com.fluig.sdk.user.UserVO.prototype = {
	/**
	* Recupera valor do id
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* Atribui valor para id
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* Recupera valor do login
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLogin": function() {}, 
	/**
	* Atribui valor para login
	* @memberOf fluigAPI
	* @param {String} login 
	*/
	"setLogin": function(login) {}, 
	/**
	* Recupera valor do email
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEmail": function() {}, 
	/**
	* Atribui valor para email
	* @memberOf fluigAPI
	* @param {String} email 
	*/
	"setEmail": function(email) {}, 
	/**
	* Recupera valor do code
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* Atribui valor para code
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* Recupera valor do firstName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFirstName": function() {}, 
	/**
	* Atribui valor para firstName
	* @memberOf fluigAPI
	* @param {String} firstName 
	*/
	"setFirstName": function(firstName) {}, 
	/**
	* Recupera valor do lastName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLastName": function() {}, 
	/**
	* Atribui valor para lastName
	* @memberOf fluigAPI
	* @param {String} lastName 
	*/
	"setLastName": function(lastName) {}, 
	/**
	* Recupera valor do fullName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFullName": function() {}, 
	/**
	* Atribui valor para fullName
	* @memberOf fluigAPI
	* @param {String} fullName 
	*/
	"setFullName": function(fullName) {}, 
	/**
	* Recupera valor do password
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPassword": function() {}, 
	/**
	* Atribui valor para password
	* @memberOf fluigAPI
	* @param {String} password 
	*/
	"setPassword": function(password) {}, 
	/**
	* Recupera valor do extData
	* @memberOf fluigAPI
	* @param {String} key 
	*/
	"getExtraData": function(key) {}, 
	/**
	* Adicionar chave e valor no mapa
	* @memberOf fluigAPI
	* @param {String} key 
	*/
	"addExtData": function(key) {}, 
	/**
	* Retorna objeto no mapa
	* @memberOf fluigAPI
	* @param {String} key 
	*/
	"getValueExtData": function(key) {}, 
	/**
	* Atribui valor para extData
	* @memberOf fluigAPI
	* @param {String} key 
	*/
	"setExtraData": function(key) {}, 
	/**
	* Recupera mapa de extraData
	* @memberOf fluigAPI
	*/
	"getExtData": function() {}, 
	/**
	* Atribui valor ao map
	* @memberOf fluigAPI
	* @param  extData 
	*/
	"setExtData": function(extData) {}, 
	/**
	* Retorna tokenAccess
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTokenAccess": function() {}, 
	/**
	* Atribui valor ao tokenAccess
	* @memberOf fluigAPI
	* @param {String} token 
	*/
	"setTokenAccess": function(token) {}, 
	/**
	* Retorna token secret
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTokenSecret": function() {}, 
	/**
	* Atribui valor ao token secret
	* @memberOf fluigAPI
	* @param {String} tokenSecret 
	*/
	"setTokenSecret": function(tokenSecret) {}, 
	/**
	* Atribui valor ao timezone
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTimezone": function() {}, 
	/**
	* Retorna o timezone
	* @memberOf fluigAPI
	* @param {String} timezone 
	*/
	"setTimezone": function(timezone) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getRoles": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} roles 
	*/
	"setRoles": function(roles) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getGroups": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} groups 
	*/
	"setGroups": function(groups) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}, 
	/**
	* Return user status
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIsActive": function() {}, 
	/**
	* Set user status
	* @memberOf fluigAPI
	* @param {boolean} isActive 
	*/
	"setIsActive": function(isActive) {}
};
UserVO.prototype = {
	/**
	* Recupera valor do id
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* Atribui valor para id
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* Recupera valor do login
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLogin": function() {}, 
	/**
	* Atribui valor para login
	* @memberOf fluigAPI
	* @param {String} login 
	*/
	"setLogin": function(login) {}, 
	/**
	* Recupera valor do email
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEmail": function() {}, 
	/**
	* Atribui valor para email
	* @memberOf fluigAPI
	* @param {String} email 
	*/
	"setEmail": function(email) {}, 
	/**
	* Recupera valor do code
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* Atribui valor para code
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* Recupera valor do firstName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFirstName": function() {}, 
	/**
	* Atribui valor para firstName
	* @memberOf fluigAPI
	* @param {String} firstName 
	*/
	"setFirstName": function(firstName) {}, 
	/**
	* Recupera valor do lastName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLastName": function() {}, 
	/**
	* Atribui valor para lastName
	* @memberOf fluigAPI
	* @param {String} lastName 
	*/
	"setLastName": function(lastName) {}, 
	/**
	* Recupera valor do fullName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFullName": function() {}, 
	/**
	* Atribui valor para fullName
	* @memberOf fluigAPI
	* @param {String} fullName 
	*/
	"setFullName": function(fullName) {}, 
	/**
	* Recupera valor do password
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPassword": function() {}, 
	/**
	* Atribui valor para password
	* @memberOf fluigAPI
	* @param {String} password 
	*/
	"setPassword": function(password) {}, 
	/**
	* Recupera valor do extData
	* @memberOf fluigAPI
	* @param {String} key 
	*/
	"getExtraData": function(key) {}, 
	/**
	* Adicionar chave e valor no mapa
	* @memberOf fluigAPI
	* @param {String} key 
	*/
	"addExtData": function(key) {}, 
	/**
	* Retorna objeto no mapa
	* @memberOf fluigAPI
	* @param {String} key 
	*/
	"getValueExtData": function(key) {}, 
	/**
	* Atribui valor para extData
	* @memberOf fluigAPI
	* @param {String} key 
	*/
	"setExtraData": function(key) {}, 
	/**
	* Recupera mapa de extraData
	* @memberOf fluigAPI
	*/
	"getExtData": function() {}, 
	/**
	* Atribui valor ao map
	* @memberOf fluigAPI
	* @param  extData 
	*/
	"setExtData": function(extData) {}, 
	/**
	* Retorna tokenAccess
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTokenAccess": function() {}, 
	/**
	* Atribui valor ao tokenAccess
	* @memberOf fluigAPI
	* @param {String} token 
	*/
	"setTokenAccess": function(token) {}, 
	/**
	* Retorna token secret
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTokenSecret": function() {}, 
	/**
	* Atribui valor ao token secret
	* @memberOf fluigAPI
	* @param {String} tokenSecret 
	*/
	"setTokenSecret": function(tokenSecret) {}, 
	/**
	* Atribui valor ao timezone
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTimezone": function() {}, 
	/**
	* Retorna o timezone
	* @memberOf fluigAPI
	* @param {String} timezone 
	*/
	"setTimezone": function(timezone) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getRoles": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} roles 
	*/
	"setRoles": function(roles) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getGroups": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} groups 
	*/
	"setGroups": function(groups) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}, 
	/**
	* Return user status
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIsActive": function() {}, 
	/**
	* Set user status
	* @memberOf fluigAPI
	* @param {boolean} isActive 
	*/
	"setIsActive": function(isActive) {}
};
com.fluig.sdk.user.UserPasswordVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLogin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} login 
	*/
	"setLogin": function(login) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCurrentPassword": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} currentPassword 
	*/
	"setCurrentPassword": function(currentPassword) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getNewPassword": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} newPassword 
	*/
	"setNewPassword": function(newPassword) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getConfirmNewPassword": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} confirmNewPassword 
	*/
	"setConfirmNewPassword": function(confirmNewPassword) {}
};
UserPasswordVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLogin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} login 
	*/
	"setLogin": function(login) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCurrentPassword": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} currentPassword 
	*/
	"setCurrentPassword": function(currentPassword) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getNewPassword": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} newPassword 
	*/
	"setNewPassword": function(newPassword) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getConfirmNewPassword": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} confirmNewPassword 
	*/
	"setConfirmNewPassword": function(confirmNewPassword) {}
};
com.fluig.sdk.user.ColleagueVO.prototype = {
	/**
	* Recupera valor do login
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLogin": function() {}, 
	/**
	* Atribui valor para login
	* @memberOf fluigAPI
	* @param {String} login 
	*/
	"setLogin": function(login) {}, 
	/**
	* Recupera valor do email
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEmail": function() {}, 
	/**
	* Atribui valor para email
	* @memberOf fluigAPI
	* @param {String} email 
	*/
	"setEmail": function(email) {}, 
	/**
	* Recupera valor do code
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* Atribui valor para code
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* Recupera valor do firstName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFirstName": function() {}, 
	/**
	* Atribui valor para firstName
	* @memberOf fluigAPI
	* @param {String} firstName 
	*/
	"setFirstName": function(firstName) {}, 
	/**
	* Recupera valor do lastName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLastName": function() {}, 
	/**
	* Atribui valor para lastName
	* @memberOf fluigAPI
	* @param {String} lastName 
	*/
	"setLastName": function(lastName) {}, 
	/**
	* Recupera valor do fullName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFullName": function() {}, 
	/**
	* Atribui valor para fullName
	* @memberOf fluigAPI
	* @param {String} fullName 
	*/
	"setFullName": function(fullName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
ColleagueVO.prototype = {
	/**
	* Recupera valor do login
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLogin": function() {}, 
	/**
	* Atribui valor para login
	* @memberOf fluigAPI
	* @param {String} login 
	*/
	"setLogin": function(login) {}, 
	/**
	* Recupera valor do email
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEmail": function() {}, 
	/**
	* Atribui valor para email
	* @memberOf fluigAPI
	* @param {String} email 
	*/
	"setEmail": function(email) {}, 
	/**
	* Recupera valor do code
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* Atribui valor para code
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* Recupera valor do firstName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFirstName": function() {}, 
	/**
	* Atribui valor para firstName
	* @memberOf fluigAPI
	* @param {String} firstName 
	*/
	"setFirstName": function(firstName) {}, 
	/**
	* Recupera valor do lastName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLastName": function() {}, 
	/**
	* Atribui valor para lastName
	* @memberOf fluigAPI
	* @param {String} lastName 
	*/
	"setLastName": function(lastName) {}, 
	/**
	* Recupera valor do fullName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFullName": function() {}, 
	/**
	* Atribui valor para fullName
	* @memberOf fluigAPI
	* @param {String} fullName 
	*/
	"setFullName": function(fullName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.document.DocumentVO.prototype = {
	/**
	* Recupera os dados extras
	* @memberOf fluigAPI
	*/
	"getExtData": function() {}, 
	/**
	* Atribui valores para os dados extras
	* @memberOf fluigAPI
	* @param {String} key 
	*/
	"setExtraData": function(key) {}, 
	/**
	* Recupera os dados extras
	* @memberOf fluigAPI
	* @param {String} key 
	*/
	"getExtraData": function(key) {}, 
	/**
	* Recupera id do tenant
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* Atribui valor para id do tenant
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* Recupera valor do document Id
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* Atribui valor para id do documento
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* Recupera valor da versão
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* Atribui valor para versão
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* Recupera valor do id do tipo de documento
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentTypeId": function() {}, 
	/**
	* Atribui valor para id do tipo de documento
	* @memberOf fluigAPI
	* @param {String} documentTypeId 
	*/
	"setDocumentTypeId": function(documentTypeId) {}, 
	/**
	* Recupera id da linguagem
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLanguageId": function() {}, 
	/**
	* Atribui valor para id da linguagem
	* @memberOf fluigAPI
	* @param {String} languageId 
	*/
	"setLanguageId": function(languageId) {}, 
	/**
	* Recupera id do icone
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getIconId": function() {}, 
	/**
	* Atribui valor para id do icone
	* @memberOf fluigAPI
	* @param {int} iconId 
	*/
	"setIconId": function(iconId) {}, 
	/**
	* Recupera valor do id do topico
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTopicId": function() {}, 
	/**
	* Atribui valor para id do topico
	* @memberOf fluigAPI
	* @param {int} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* Recupera id do colega
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* Atribui valor para id do colega
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* Recupera descrição do documento
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentDescription": function() {}, 
	/**
	* Atribui valor para descrição do documento
	* @memberOf fluigAPI
	* @param {String} documentDescription 
	*/
	"setDocumentDescription": function(documentDescription) {}, 
	/**
	* Recupera arquivo fisico
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPhisicalFile": function() {}, 
	/**
	* Atribui valor para arquivo fisico
	* @memberOf fluigAPI
	* @param {String} phisicalFile 
	*/
	"setPhisicalFile": function(phisicalFile) {}, 
	/**
	* Recupera valor de palavra chave
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getKeyWord": function() {}, 
	/**
	* Atribui valor para palavra chave
	* @memberOf fluigAPI
	* @param {String} keyWord 
	*/
	"setKeyWord": function(keyWord) {}, 
	/**
	* Recupera valor para data de criação
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCreateDate": function() {}, 
	/**
	* Atribui valor para data de criação
	* @memberOf fluigAPI
	* @param {Date} createDate 
	*/
	"setCreateDate": function(createDate) {}, 
	/**
	* Recupera valor da data de aprovação
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getApprovedDate": function() {}, 
	/**
	* Atribui valor para data de aprovação
	* @memberOf fluigAPI
	* @param {Date} approvedDate 
	*/
	"setApprovedDate": function(approvedDate) {}, 
	/**
	* Recupera valor da última data de moficação
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getLastModifiedDate": function() {}, 
	/**
	* Atribui valor para última data de modificação
	* @memberOf fluigAPI
	* @param {Date} lastModifiedDate 
	*/
	"setLastModifiedDate": function(lastModifiedDate) {}, 
	/**
	* Recupera valor do tipo de documento
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentType": function() {}, 
	/**
	* Atribui valor para tipo de documento
	* @memberOf fluigAPI
	* @param {String} documentType 
	*/
	"setDocumentType": function(documentType) {}, 
	/**
	* Recupera data de expiração
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getExpirationDate": function() {}, 
	/**
	* Atribui valor para data de expiração
	* @memberOf fluigAPI
	* @param {Date} expirationDate 
	*/
	"setExpirationDate": function(expirationDate) {}, 
	/**
	* Recupera número de acessso
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getAccessCount": function() {}, 
	/**
	* Atribui valor para número de acessos
	* @memberOf fluigAPI
	* @param {int} accessCount 
	*/
	"setAccessCount": function(accessCount) {}, 
	/**
	* Recupera id de atualização
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getAtualizationId": function() {}, 
	/**
	* Atribui valor para id de atualização
	* @memberOf fluigAPI
	* @param {int} atualizationId 
	*/
	"setAtualizationId": function(atualizationId) {}, 
	/**
	* Recupera id do pai do documento
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getParentDocumentId": function() {}, 
	/**
	* Atribui valor para id do documento pai
	* @memberOf fluigAPI
	* @param {int} parentDocumentId 
	*/
	"setParentDocumentId": function(parentDocumentId) {}, 
	/**
	* Recupera visualização
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVisualization": function() {}, 
	/**
	* Atribui valor para visualização
	* @memberOf fluigAPI
	* @param {String} visualization 
	*/
	"setVisualization": function(visualization) {}, 
	/**
	* Recuprea arquivos relacionados
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRelatedFiles": function() {}, 
	/**
	* Atribui valor para arquivos relacionados
	* @memberOf fluigAPI
	* @param {String} relatedFiles 
	*/
	"setRelatedFiles": function(relatedFiles) {}, 
	/**
	* Recupera versão ativa
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getActiveVersion": function() {}, 
	/**
	* Atribui valor para versão ativa
	* @memberOf fluigAPI
	* @param {boolean} activeVersion 
	*/
	"setActiveVersion": function(activeVersion) {}, 
	/**
	* Recupera descrição da versão
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVersionDescription": function() {}, 
	/**
	* Atribui valor para descrição da versão
	* @memberOf fluigAPI
	* @param {String} versionDescription 
	*/
	"setVersionDescription": function(versionDescription) {}, 
	/**
	* Recupera condição aprovalAndOr
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getApprovalAndOr": function() {}, 
	/**
	* Atribui valor para approvalAndOr
	* @memberOf fluigAPI
	* @param {boolean} approvalAndOr 
	*/
	"setApprovalAndOr": function(approvalAndOr) {}, 
	/**
	* Recupera id documento externo
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getExternalDocumentId": function() {}, 
	/**
	* Atribui valor para id documento externo
	* @memberOf fluigAPI
	* @param {String} externalDocumentId 
	*/
	"setExternalDocumentId": function(externalDocumentId) {}, 
	/**
	* Recupera valor, se download é habilitado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDownloadEnabled": function() {}, 
	/**
	* Atribui valor, se download é habilitado
	* @memberOf fluigAPI
	* @param {boolean} downloadEnabled 
	*/
	"setDownloadEnabled": function(downloadEnabled) {}, 
	/**
	* Recupera valor, se documento está aprovado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getApproved": function() {}, 
	/**
	* Atribui valor, se documento está aprovado
	* @memberOf fluigAPI
	* @param {boolean} approved 
	*/
	"setApproved": function(approved) {}, 
	/**
	* Recupera data de inicio de validação
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getValidationStartDate": function() {}, 
	/**
	* Atribui valor para data de início de validação
	* @memberOf fluigAPI
	* @param {Date} validationStartDate 
	*/
	"setValidationStartDate": function(validationStartDate) {}, 
	/**
	* Recupera id do publicador
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPublisherId": function() {}, 
	/**
	* Atribui valor para id do publicador
	* @memberOf fluigAPI
	* @param {String} publisherId 
	*/
	"setPublisherId": function(publisherId) {}, 
	/**
	* Recupera descrição do card
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCardDescription": function() {}, 
	/**
	* Atribui valor  para descrição do card
	* @memberOf fluigAPI
	* @param {String} cardDescription 
	*/
	"setCardDescription": function(cardDescription) {}, 
	/**
	* Recupera valor, se documento permite mult card por usuário
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAllowMuiltiCardsPerUser": function() {}, 
	/**
	* Atribui valor para allowMuiltiCardsPerUser
	* @memberOf fluigAPI
	* @param {boolean} allowMuiltiCardsPerUser 
	*/
	"setAllowMuiltiCardsPerUser": function(allowMuiltiCardsPerUser) {}, 
	/**
	* Recupera número de propriedade do documento
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentPropertyNumber": function() {}, 
	/**
	* Atribui valor para número de propriedade do documento
	* @memberOf fluigAPI
	* @param {int} documentPropertyNumber 
	*/
	"setDocumentPropertyNumber": function(documentPropertyNumber) {}, 
	/**
	* Recupera versão do documento
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentPropertyVersion": function() {}, 
	/**
	* Atribui versão de documento
	* @memberOf fluigAPI
	* @param {int} documentPropertyVersion 
	*/
	"setDocumentPropertyVersion": function(documentPropertyVersion) {}, 
	/**
	* Recupera valor, se documento é privado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getPrivateDocument": function() {}, 
	/**
	* Atribui valor, se documento é privado
	* @memberOf fluigAPI
	* @param {boolean} privateDocument 
	*/
	"setPrivateDocument": function(privateDocument) {}, 
	/**
	* Recupera valor id privado do colega
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPrivateColleagueId": function() {}, 
	/**
	* Atribui valor id privado do colega
	* @memberOf fluigAPI
	* @param {String} privateColleagueId 
	*/
	"setPrivateColleagueId": function(privateColleagueId) {}, 
	/**
	* Recupera valor, se documento é indexado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIndexed": function() {}, 
	/**
	* Atribui valor, se documento é indexado
	* @memberOf fluigAPI
	* @param {boolean} indexed 
	*/
	"setIndexed": function(indexed) {}, 
	/**
	* Recupera prioridade
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getPriority": function() {}, 
	/**
	* Atribui valor prioridade
	* @memberOf fluigAPI
	* @param {int} priority 
	*/
	"setPriority": function(priority) {}, 
	/**
	* Recupera valor, se documento é traduzido
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getTranslated": function() {}, 
	/**
	* Atribui valor, se documento é traduzido
	* @memberOf fluigAPI
	* @param {boolean} translated 
	*/
	"setTranslated": function(translated) {}, 
	/**
	* Recupera valor, se usuário será notificado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getUserNotify": function() {}, 
	/**
	* Atribui valor se usuário será notificado
	* @memberOf fluigAPI
	* @param {boolean} userNotify 
	*/
	"setUserNotify": function(userNotify) {}, 
	/**
	* Recupera valor, se documento expira
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getExpires": function() {}, 
	/**
	* Atribui valor, se documento expira
	* @memberOf fluigAPI
	* @param {boolean} expires 
	*/
	"setExpires": function(expires) {}, 
	/**
	* Recupera id do volume
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVolumeId": function() {}, 
	/**
	* Atribui valor ao id do volume
	* @memberOf fluigAPI
	* @param {String} volumeId 
	*/
	"setVolumeId": function(volumeId) {}, 
	/**
	* Recupera updateIsoProperties
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getUpdateIsoProperties": function() {}, 
	/**
	* Atribui valor para updateIsoProperties
	* @memberOf fluigAPI
	* @param {boolean} updateIsoProperties 
	*/
	"setUpdateIsoProperties": function(updateIsoProperties) {}, 
	/**
	* Recupera última data de modificação
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLastModifiedTime": function() {}, 
	/**
	* Atribui valor a última data de modificação
	* @memberOf fluigAPI
	* @param {String} lastModifiedTime 
	*/
	"setLastModifiedTime": function(lastModifiedTime) {}, 
	/**
	* Recupera valor, se documento foi deletado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDeleted": function() {}, 
	/**
	* Atribui valor, se documento foi deletado
	* @memberOf fluigAPI
	* @param {boolean} deleted 
	*/
	"setDeleted": function(deleted) {}, 
	/**
	* Recupera valor, se documento é imultavel
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getImutable": function() {}, 
	/**
	* Atribui valor, se documento é imutavel
	* @memberOf fluigAPI
	* @param {boolean} imutable 
	*/
	"setImutable": function(imutable) {}, 
	/**
	* Recupera valor, se documento  pode ser visualizado internamente
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInternalVisualizer": function() {}, 
	/**
	* Atribui valor, se documento pode ser visualizado internamente
	* @memberOf fluigAPI
	* @param {boolean} internalVisualizer 
	*/
	"setInternalVisualizer": function(internalVisualizer) {}, 
	/**
	* Recupera valor do crc
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCrc": function() {}, 
	/**
	* Atribui valor para crc
	* @memberOf fluigAPI
	* @param {long} crc 
	*/
	"setCrc": function(crc) {}, 
	/**
	* Recupera valor do UUID
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUUID": function() {}, 
	/**
	* Atribui valor para UUID
	* @memberOf fluigAPI
	* @param {String} uUID 
	*/
	"setUUID": function(uUID) {}, 
	/**
	* Recupera valor do tamanho do arquivo fisico
	* @memberOf fluigAPI
	*/
	"getPhisicalFileSize": function() {}, 
	/**
	* Atribui valor para o tamanho do arquivo fisico
	* @memberOf fluigAPI
	* @param  phisicalFileSize 
	*/
	"setPhisicalFileSize": function(phisicalFileSize) {}, 
	/**
	* Recupera o tipo de permissão
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getPermissionType": function() {}, 
	/**
	* Atribui valor para tipo de permissão
	* @memberOf fluigAPI
	* @param {int} permissionType 
	*/
	"setPermissionType": function(permissionType) {}, 
	/**
	* Recupera tipo de restrição
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getRestrictionType": function() {}, 
	/**
	* Atribui valor para tipo de  restrição
	* @memberOf fluigAPI
	* @param {int} restrictionType 
	*/
	"setRestrictionType": function(restrictionType) {}, 
	/**
	* Recupera valor do código do site
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSiteCode": function() {}, 
	/**
	* Atribui valor para código de site
	* @memberOf fluigAPI
	* @param {String} siteCode 
	*/
	"setSiteCode": function(siteCode) {}, 
	/**
	* Recupera valor de draft
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDraft": function() {}, 
	/**
	* Atribui valor para draft
	* @memberOf fluigAPI
	* @param {boolean} draft 
	*/
	"setDraft": function(draft) {}, 
	/**
	* Recupera valor, se documento está em checkout
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getOnCheckout": function() {}, 
	/**
	* Atribui valor, se documento está em checkout
	* @memberOf fluigAPI
	* @param {boolean} onCheckout 
	*/
	"setOnCheckout": function(onCheckout) {}, 
	/**
	* Recupera valor do path do icon
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getIconPath": function() {}, 
	/**
	* Atribui valor do iconPath do arquivo
	* @memberOf fluigAPI
	* @param {String} iconPath 
	*/
	"setIconPath": function(iconPath) {}, 
	/**
	* Recupera a ação que serão realizada em relaão a versão documento
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVersionAction": function() {}, 
	/**
	* Atribue a ação que serão realizada em relaão a versão documento
	* @memberOf fluigAPI
	* @param {String} versionAction 
	*/
	"setVersionAction": function(versionAction) {}, 
	/**
	* Recupera o identificador do upload
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUploadId": function() {}, 
	/**
	* Atribue o identificador do uplaod
	* @memberOf fluigAPI
	* @param {String} uploadId 
	*/
	"setUploadId": function(uploadId) {}, 
	/**
	* Recupera o valor do comentário nas informações extras
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAdditionalComments": function() {}, 
	/**
	* Atribui o valor do comentário nas informações extras
	* @memberOf fluigAPI
	* @param {String} comments 
	*/
	"setAdditionalComments": function(comments) {}, 
	/**
	* Retorna se o documento herda as propriedades do parent
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInheritSecurity": function() {}, 
	/**
	* Atribui se herda as propriedades de segurança do parent
	* @memberOf fluigAPI
	* @param {boolean} inheritSecurity 
	*/
	"setInheritSecurity": function(inheritSecurity) {}
};
DocumentVO.prototype = {
	/**
	* Recupera os dados extras
	* @memberOf fluigAPI
	*/
	"getExtData": function() {}, 
	/**
	* Atribui valores para os dados extras
	* @memberOf fluigAPI
	* @param {String} key 
	*/
	"setExtraData": function(key) {}, 
	/**
	* Recupera os dados extras
	* @memberOf fluigAPI
	* @param {String} key 
	*/
	"getExtraData": function(key) {}, 
	/**
	* Recupera id do tenant
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* Atribui valor para id do tenant
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* Recupera valor do document Id
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* Atribui valor para id do documento
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* Recupera valor da versão
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* Atribui valor para versão
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* Recupera valor do id do tipo de documento
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentTypeId": function() {}, 
	/**
	* Atribui valor para id do tipo de documento
	* @memberOf fluigAPI
	* @param {String} documentTypeId 
	*/
	"setDocumentTypeId": function(documentTypeId) {}, 
	/**
	* Recupera id da linguagem
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLanguageId": function() {}, 
	/**
	* Atribui valor para id da linguagem
	* @memberOf fluigAPI
	* @param {String} languageId 
	*/
	"setLanguageId": function(languageId) {}, 
	/**
	* Recupera id do icone
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getIconId": function() {}, 
	/**
	* Atribui valor para id do icone
	* @memberOf fluigAPI
	* @param {int} iconId 
	*/
	"setIconId": function(iconId) {}, 
	/**
	* Recupera valor do id do topico
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTopicId": function() {}, 
	/**
	* Atribui valor para id do topico
	* @memberOf fluigAPI
	* @param {int} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* Recupera id do colega
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* Atribui valor para id do colega
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* Recupera descrição do documento
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentDescription": function() {}, 
	/**
	* Atribui valor para descrição do documento
	* @memberOf fluigAPI
	* @param {String} documentDescription 
	*/
	"setDocumentDescription": function(documentDescription) {}, 
	/**
	* Recupera arquivo fisico
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPhisicalFile": function() {}, 
	/**
	* Atribui valor para arquivo fisico
	* @memberOf fluigAPI
	* @param {String} phisicalFile 
	*/
	"setPhisicalFile": function(phisicalFile) {}, 
	/**
	* Recupera valor de palavra chave
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getKeyWord": function() {}, 
	/**
	* Atribui valor para palavra chave
	* @memberOf fluigAPI
	* @param {String} keyWord 
	*/
	"setKeyWord": function(keyWord) {}, 
	/**
	* Recupera valor para data de criação
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCreateDate": function() {}, 
	/**
	* Atribui valor para data de criação
	* @memberOf fluigAPI
	* @param {Date} createDate 
	*/
	"setCreateDate": function(createDate) {}, 
	/**
	* Recupera valor da data de aprovação
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getApprovedDate": function() {}, 
	/**
	* Atribui valor para data de aprovação
	* @memberOf fluigAPI
	* @param {Date} approvedDate 
	*/
	"setApprovedDate": function(approvedDate) {}, 
	/**
	* Recupera valor da última data de moficação
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getLastModifiedDate": function() {}, 
	/**
	* Atribui valor para última data de modificação
	* @memberOf fluigAPI
	* @param {Date} lastModifiedDate 
	*/
	"setLastModifiedDate": function(lastModifiedDate) {}, 
	/**
	* Recupera valor do tipo de documento
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentType": function() {}, 
	/**
	* Atribui valor para tipo de documento
	* @memberOf fluigAPI
	* @param {String} documentType 
	*/
	"setDocumentType": function(documentType) {}, 
	/**
	* Recupera data de expiração
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getExpirationDate": function() {}, 
	/**
	* Atribui valor para data de expiração
	* @memberOf fluigAPI
	* @param {Date} expirationDate 
	*/
	"setExpirationDate": function(expirationDate) {}, 
	/**
	* Recupera número de acessso
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getAccessCount": function() {}, 
	/**
	* Atribui valor para número de acessos
	* @memberOf fluigAPI
	* @param {int} accessCount 
	*/
	"setAccessCount": function(accessCount) {}, 
	/**
	* Recupera id de atualização
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getAtualizationId": function() {}, 
	/**
	* Atribui valor para id de atualização
	* @memberOf fluigAPI
	* @param {int} atualizationId 
	*/
	"setAtualizationId": function(atualizationId) {}, 
	/**
	* Recupera id do pai do documento
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getParentDocumentId": function() {}, 
	/**
	* Atribui valor para id do documento pai
	* @memberOf fluigAPI
	* @param {int} parentDocumentId 
	*/
	"setParentDocumentId": function(parentDocumentId) {}, 
	/**
	* Recupera visualização
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVisualization": function() {}, 
	/**
	* Atribui valor para visualização
	* @memberOf fluigAPI
	* @param {String} visualization 
	*/
	"setVisualization": function(visualization) {}, 
	/**
	* Recuprea arquivos relacionados
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRelatedFiles": function() {}, 
	/**
	* Atribui valor para arquivos relacionados
	* @memberOf fluigAPI
	* @param {String} relatedFiles 
	*/
	"setRelatedFiles": function(relatedFiles) {}, 
	/**
	* Recupera versão ativa
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getActiveVersion": function() {}, 
	/**
	* Atribui valor para versão ativa
	* @memberOf fluigAPI
	* @param {boolean} activeVersion 
	*/
	"setActiveVersion": function(activeVersion) {}, 
	/**
	* Recupera descrição da versão
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVersionDescription": function() {}, 
	/**
	* Atribui valor para descrição da versão
	* @memberOf fluigAPI
	* @param {String} versionDescription 
	*/
	"setVersionDescription": function(versionDescription) {}, 
	/**
	* Recupera condição aprovalAndOr
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getApprovalAndOr": function() {}, 
	/**
	* Atribui valor para approvalAndOr
	* @memberOf fluigAPI
	* @param {boolean} approvalAndOr 
	*/
	"setApprovalAndOr": function(approvalAndOr) {}, 
	/**
	* Recupera id documento externo
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getExternalDocumentId": function() {}, 
	/**
	* Atribui valor para id documento externo
	* @memberOf fluigAPI
	* @param {String} externalDocumentId 
	*/
	"setExternalDocumentId": function(externalDocumentId) {}, 
	/**
	* Recupera valor, se download é habilitado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDownloadEnabled": function() {}, 
	/**
	* Atribui valor, se download é habilitado
	* @memberOf fluigAPI
	* @param {boolean} downloadEnabled 
	*/
	"setDownloadEnabled": function(downloadEnabled) {}, 
	/**
	* Recupera valor, se documento está aprovado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getApproved": function() {}, 
	/**
	* Atribui valor, se documento está aprovado
	* @memberOf fluigAPI
	* @param {boolean} approved 
	*/
	"setApproved": function(approved) {}, 
	/**
	* Recupera data de inicio de validação
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getValidationStartDate": function() {}, 
	/**
	* Atribui valor para data de início de validação
	* @memberOf fluigAPI
	* @param {Date} validationStartDate 
	*/
	"setValidationStartDate": function(validationStartDate) {}, 
	/**
	* Recupera id do publicador
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPublisherId": function() {}, 
	/**
	* Atribui valor para id do publicador
	* @memberOf fluigAPI
	* @param {String} publisherId 
	*/
	"setPublisherId": function(publisherId) {}, 
	/**
	* Recupera descrição do card
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCardDescription": function() {}, 
	/**
	* Atribui valor  para descrição do card
	* @memberOf fluigAPI
	* @param {String} cardDescription 
	*/
	"setCardDescription": function(cardDescription) {}, 
	/**
	* Recupera valor, se documento permite mult card por usuário
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAllowMuiltiCardsPerUser": function() {}, 
	/**
	* Atribui valor para allowMuiltiCardsPerUser
	* @memberOf fluigAPI
	* @param {boolean} allowMuiltiCardsPerUser 
	*/
	"setAllowMuiltiCardsPerUser": function(allowMuiltiCardsPerUser) {}, 
	/**
	* Recupera número de propriedade do documento
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentPropertyNumber": function() {}, 
	/**
	* Atribui valor para número de propriedade do documento
	* @memberOf fluigAPI
	* @param {int} documentPropertyNumber 
	*/
	"setDocumentPropertyNumber": function(documentPropertyNumber) {}, 
	/**
	* Recupera versão do documento
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentPropertyVersion": function() {}, 
	/**
	* Atribui versão de documento
	* @memberOf fluigAPI
	* @param {int} documentPropertyVersion 
	*/
	"setDocumentPropertyVersion": function(documentPropertyVersion) {}, 
	/**
	* Recupera valor, se documento é privado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getPrivateDocument": function() {}, 
	/**
	* Atribui valor, se documento é privado
	* @memberOf fluigAPI
	* @param {boolean} privateDocument 
	*/
	"setPrivateDocument": function(privateDocument) {}, 
	/**
	* Recupera valor id privado do colega
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPrivateColleagueId": function() {}, 
	/**
	* Atribui valor id privado do colega
	* @memberOf fluigAPI
	* @param {String} privateColleagueId 
	*/
	"setPrivateColleagueId": function(privateColleagueId) {}, 
	/**
	* Recupera valor, se documento é indexado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIndexed": function() {}, 
	/**
	* Atribui valor, se documento é indexado
	* @memberOf fluigAPI
	* @param {boolean} indexed 
	*/
	"setIndexed": function(indexed) {}, 
	/**
	* Recupera prioridade
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getPriority": function() {}, 
	/**
	* Atribui valor prioridade
	* @memberOf fluigAPI
	* @param {int} priority 
	*/
	"setPriority": function(priority) {}, 
	/**
	* Recupera valor, se documento é traduzido
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getTranslated": function() {}, 
	/**
	* Atribui valor, se documento é traduzido
	* @memberOf fluigAPI
	* @param {boolean} translated 
	*/
	"setTranslated": function(translated) {}, 
	/**
	* Recupera valor, se usuário será notificado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getUserNotify": function() {}, 
	/**
	* Atribui valor se usuário será notificado
	* @memberOf fluigAPI
	* @param {boolean} userNotify 
	*/
	"setUserNotify": function(userNotify) {}, 
	/**
	* Recupera valor, se documento expira
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getExpires": function() {}, 
	/**
	* Atribui valor, se documento expira
	* @memberOf fluigAPI
	* @param {boolean} expires 
	*/
	"setExpires": function(expires) {}, 
	/**
	* Recupera id do volume
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVolumeId": function() {}, 
	/**
	* Atribui valor ao id do volume
	* @memberOf fluigAPI
	* @param {String} volumeId 
	*/
	"setVolumeId": function(volumeId) {}, 
	/**
	* Recupera updateIsoProperties
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getUpdateIsoProperties": function() {}, 
	/**
	* Atribui valor para updateIsoProperties
	* @memberOf fluigAPI
	* @param {boolean} updateIsoProperties 
	*/
	"setUpdateIsoProperties": function(updateIsoProperties) {}, 
	/**
	* Recupera última data de modificação
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLastModifiedTime": function() {}, 
	/**
	* Atribui valor a última data de modificação
	* @memberOf fluigAPI
	* @param {String} lastModifiedTime 
	*/
	"setLastModifiedTime": function(lastModifiedTime) {}, 
	/**
	* Recupera valor, se documento foi deletado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDeleted": function() {}, 
	/**
	* Atribui valor, se documento foi deletado
	* @memberOf fluigAPI
	* @param {boolean} deleted 
	*/
	"setDeleted": function(deleted) {}, 
	/**
	* Recupera valor, se documento é imultavel
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getImutable": function() {}, 
	/**
	* Atribui valor, se documento é imutavel
	* @memberOf fluigAPI
	* @param {boolean} imutable 
	*/
	"setImutable": function(imutable) {}, 
	/**
	* Recupera valor, se documento  pode ser visualizado internamente
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInternalVisualizer": function() {}, 
	/**
	* Atribui valor, se documento pode ser visualizado internamente
	* @memberOf fluigAPI
	* @param {boolean} internalVisualizer 
	*/
	"setInternalVisualizer": function(internalVisualizer) {}, 
	/**
	* Recupera valor do crc
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCrc": function() {}, 
	/**
	* Atribui valor para crc
	* @memberOf fluigAPI
	* @param {long} crc 
	*/
	"setCrc": function(crc) {}, 
	/**
	* Recupera valor do UUID
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUUID": function() {}, 
	/**
	* Atribui valor para UUID
	* @memberOf fluigAPI
	* @param {String} uUID 
	*/
	"setUUID": function(uUID) {}, 
	/**
	* Recupera valor do tamanho do arquivo fisico
	* @memberOf fluigAPI
	*/
	"getPhisicalFileSize": function() {}, 
	/**
	* Atribui valor para o tamanho do arquivo fisico
	* @memberOf fluigAPI
	* @param  phisicalFileSize 
	*/
	"setPhisicalFileSize": function(phisicalFileSize) {}, 
	/**
	* Recupera o tipo de permissão
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getPermissionType": function() {}, 
	/**
	* Atribui valor para tipo de permissão
	* @memberOf fluigAPI
	* @param {int} permissionType 
	*/
	"setPermissionType": function(permissionType) {}, 
	/**
	* Recupera tipo de restrição
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getRestrictionType": function() {}, 
	/**
	* Atribui valor para tipo de  restrição
	* @memberOf fluigAPI
	* @param {int} restrictionType 
	*/
	"setRestrictionType": function(restrictionType) {}, 
	/**
	* Recupera valor do código do site
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSiteCode": function() {}, 
	/**
	* Atribui valor para código de site
	* @memberOf fluigAPI
	* @param {String} siteCode 
	*/
	"setSiteCode": function(siteCode) {}, 
	/**
	* Recupera valor de draft
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDraft": function() {}, 
	/**
	* Atribui valor para draft
	* @memberOf fluigAPI
	* @param {boolean} draft 
	*/
	"setDraft": function(draft) {}, 
	/**
	* Recupera valor, se documento está em checkout
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getOnCheckout": function() {}, 
	/**
	* Atribui valor, se documento está em checkout
	* @memberOf fluigAPI
	* @param {boolean} onCheckout 
	*/
	"setOnCheckout": function(onCheckout) {}, 
	/**
	* Recupera valor do path do icon
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getIconPath": function() {}, 
	/**
	* Atribui valor do iconPath do arquivo
	* @memberOf fluigAPI
	* @param {String} iconPath 
	*/
	"setIconPath": function(iconPath) {}, 
	/**
	* Recupera a ação que serão realizada em relaão a versão documento
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVersionAction": function() {}, 
	/**
	* Atribue a ação que serão realizada em relaão a versão documento
	* @memberOf fluigAPI
	* @param {String} versionAction 
	*/
	"setVersionAction": function(versionAction) {}, 
	/**
	* Recupera o identificador do upload
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUploadId": function() {}, 
	/**
	* Atribue o identificador do uplaod
	* @memberOf fluigAPI
	* @param {String} uploadId 
	*/
	"setUploadId": function(uploadId) {}, 
	/**
	* Recupera o valor do comentário nas informações extras
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAdditionalComments": function() {}, 
	/**
	* Atribui o valor do comentário nas informações extras
	* @memberOf fluigAPI
	* @param {String} comments 
	*/
	"setAdditionalComments": function(comments) {}, 
	/**
	* Retorna se o documento herda as propriedades do parent
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInheritSecurity": function() {}, 
	/**
	* Atribui se herda as propriedades de segurança do parent
	* @memberOf fluigAPI
	* @param {boolean} inheritSecurity 
	*/
	"setInheritSecurity": function(inheritSecurity) {}
};
com.fluig.sdk.api.document.AllocatedDocumentVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSourceDocument": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSourceVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDestinationDocument": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCheckoutDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} checkoutDate 
	*/
	"setCheckoutDate": function(checkoutDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCheckoutTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} checkoutTime 
	*/
	"setCheckoutTime": function(checkoutTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCheckinDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} checkinDate 
	*/
	"setCheckinDate": function(checkinDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCheckinTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} checkinTime 
	*/
	"setCheckinTime": function(checkinTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getComment": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} comment 
	*/
	"setComment": function(comment) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getActive": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} active 
	*/
	"setActive": function(active) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getCheckoutAllowed": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} checkoutAllowed 
	*/
	"setCheckoutAllowed": function(checkoutAllowed) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueName 
	*/
	"setColleagueName": function(colleagueName) {}
};
AllocatedDocumentVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSourceDocument": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSourceVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDestinationDocument": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCheckoutDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} checkoutDate 
	*/
	"setCheckoutDate": function(checkoutDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCheckoutTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} checkoutTime 
	*/
	"setCheckoutTime": function(checkoutTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCheckinDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} checkinDate 
	*/
	"setCheckinDate": function(checkinDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCheckinTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} checkinTime 
	*/
	"setCheckinTime": function(checkinTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getComment": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} comment 
	*/
	"setComment": function(comment) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getActive": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} active 
	*/
	"setActive": function(active) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getCheckoutAllowed": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} checkoutAllowed 
	*/
	"setCheckoutAllowed": function(checkoutAllowed) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueName 
	*/
	"setColleagueName": function(colleagueName) {}
};
com.fluig.sdk.api.document.DocumentPermissionVO.prototype = {
	/**
	* Recupera valor do securityLevel
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSecurityLevel": function() {}, 
	/**
	* Atribui valor para securityLevel
	* @memberOf fluigAPI
	* @param {int} securityLevel 
	*/
	"setSecurityLevel": function(securityLevel) {}, 
	/**
	* Recupera valor do securityVersion
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getSecurityVersion": function() {}, 
	/**
	* Atribui valor para securityVersion
	* @memberOf fluigAPI
	* @param {boolean} securityVersion 
	*/
	"setSecurityVersion": function(securityVersion) {}, 
	/**
	* Recupera valor do inheritSecurity
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInheritSecurity": function() {}, 
	/**
	* Atribui valor para inheritSecurity
	* @memberOf fluigAPI
	* @param {boolean} inheritSecurity 
	*/
	"setInheritSecurity": function(inheritSecurity) {}, 
	/**
	* Recupera valor do downloadEnabled
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDownloadEnabled": function() {}, 
	/**
	* Atribui valor para downloadEnabled
	* @memberOf fluigAPI
	* @param {boolean} downloadEnabled 
	*/
	"setDownloadEnabled": function(downloadEnabled) {}, 
	/**
	* Recupera valor do showContent
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowContent": function() {}, 
	/**
	* Atribui valor para showContent
	* @memberOf fluigAPI
	* @param {boolean} showContent 
	*/
	"setShowContent": function(showContent) {}, 
	/**
	* Recupera valor do attributionDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAttributionDescription": function() {}, 
	/**
	* Atribui valor para attributionDescription
	* @memberOf fluigAPI
	* @param {String} attributionDescription 
	*/
	"setAttributionDescription": function(attributionDescription) {}, 
	/**
	* Recupera valor do attributionType
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getAttributionType": function() {}, 
	/**
	* Atribui valor para attributionType
	* @memberOf fluigAPI
	* @param {int} attributionType 
	*/
	"setAttributionType": function(attributionType) {}, 
	/**
	* Recupera valor do attributionValue
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAttributionValue": function() {}, 
	/**
	* Atribui valor para attributionValue
	* @memberOf fluigAPI
	* @param {String} attributionValue 
	*/
	"setAttributionValue": function(attributionValue) {}
};
DocumentPermissionVO.prototype = {
	/**
	* Recupera valor do securityLevel
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSecurityLevel": function() {}, 
	/**
	* Atribui valor para securityLevel
	* @memberOf fluigAPI
	* @param {int} securityLevel 
	*/
	"setSecurityLevel": function(securityLevel) {}, 
	/**
	* Recupera valor do securityVersion
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getSecurityVersion": function() {}, 
	/**
	* Atribui valor para securityVersion
	* @memberOf fluigAPI
	* @param {boolean} securityVersion 
	*/
	"setSecurityVersion": function(securityVersion) {}, 
	/**
	* Recupera valor do inheritSecurity
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInheritSecurity": function() {}, 
	/**
	* Atribui valor para inheritSecurity
	* @memberOf fluigAPI
	* @param {boolean} inheritSecurity 
	*/
	"setInheritSecurity": function(inheritSecurity) {}, 
	/**
	* Recupera valor do downloadEnabled
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDownloadEnabled": function() {}, 
	/**
	* Atribui valor para downloadEnabled
	* @memberOf fluigAPI
	* @param {boolean} downloadEnabled 
	*/
	"setDownloadEnabled": function(downloadEnabled) {}, 
	/**
	* Recupera valor do showContent
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowContent": function() {}, 
	/**
	* Atribui valor para showContent
	* @memberOf fluigAPI
	* @param {boolean} showContent 
	*/
	"setShowContent": function(showContent) {}, 
	/**
	* Recupera valor do attributionDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAttributionDescription": function() {}, 
	/**
	* Atribui valor para attributionDescription
	* @memberOf fluigAPI
	* @param {String} attributionDescription 
	*/
	"setAttributionDescription": function(attributionDescription) {}, 
	/**
	* Recupera valor do attributionType
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getAttributionType": function() {}, 
	/**
	* Atribui valor para attributionType
	* @memberOf fluigAPI
	* @param {int} attributionType 
	*/
	"setAttributionType": function(attributionType) {}, 
	/**
	* Recupera valor do attributionValue
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAttributionValue": function() {}, 
	/**
	* Atribui valor para attributionValue
	* @memberOf fluigAPI
	* @param {String} attributionValue 
	*/
	"setAttributionValue": function(attributionValue) {}
};
com.fluig.sdk.api.document.DocumentApproverVO.prototype = {
	/**
	* Recupera valor do approverType
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getApproverType": function() {}, 
	/**
	* Atribui valor para approverType
	* @memberOf fluigAPI
	* @param {int} approverType 
	*/
	"setApproverType": function(approverType) {}, 
	/**
	* Recupera valor do colleagueId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* Atribui valor para colleagueId
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* Recupera valor do levelId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getLevelId": function() {}, 
	/**
	* Atribui valor para levelId
	* @memberOf fluigAPI
	* @param {int} levelId 
	*/
	"setLevelId": function(levelId) {}, 
	/**
	* Recupera valor do approvalMode
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getApprovalMode": function() {}, 
	/**
	* Atribui valor para approvalMode
	* @memberOf fluigAPI
	* @param {int} approvalMode 
	*/
	"setApprovalMode": function(approvalMode) {}, 
	/**
	* Recupera valor do digitalSignature
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDigitalSignature": function() {}, 
	/**
	* Atribui valor para digitalSignature
	* @memberOf fluigAPI
	* @param {boolean} digitalSignature 
	*/
	"setDigitalSignature": function(digitalSignature) {}, 
	/**
	* Recupera valor do levelDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLevelDescription": function() {}, 
	/**
	* Atribui valor para levelDescription
	* @memberOf fluigAPI
	* @param {String} levelDescription 
	*/
	"setLevelDescription": function(levelDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAlias": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} alias 
	*/
	"setAlias": function(alias) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFullName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} fullName 
	*/
	"setFullName": function(fullName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEmail": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} email 
	*/
	"setEmail": function(email) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getApprovalStatus": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} approvalStatus 
	*/
	"setApprovalStatus": function(approvalStatus) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getApprovalObservation": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} approvalObservation 
	*/
	"setApprovalObservation": function(approvalObservation) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}
};
DocumentApproverVO.prototype = {
	/**
	* Recupera valor do approverType
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getApproverType": function() {}, 
	/**
	* Atribui valor para approverType
	* @memberOf fluigAPI
	* @param {int} approverType 
	*/
	"setApproverType": function(approverType) {}, 
	/**
	* Recupera valor do colleagueId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* Atribui valor para colleagueId
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* Recupera valor do levelId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getLevelId": function() {}, 
	/**
	* Atribui valor para levelId
	* @memberOf fluigAPI
	* @param {int} levelId 
	*/
	"setLevelId": function(levelId) {}, 
	/**
	* Recupera valor do approvalMode
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getApprovalMode": function() {}, 
	/**
	* Atribui valor para approvalMode
	* @memberOf fluigAPI
	* @param {int} approvalMode 
	*/
	"setApprovalMode": function(approvalMode) {}, 
	/**
	* Recupera valor do digitalSignature
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDigitalSignature": function() {}, 
	/**
	* Atribui valor para digitalSignature
	* @memberOf fluigAPI
	* @param {boolean} digitalSignature 
	*/
	"setDigitalSignature": function(digitalSignature) {}, 
	/**
	* Recupera valor do levelDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLevelDescription": function() {}, 
	/**
	* Atribui valor para levelDescription
	* @memberOf fluigAPI
	* @param {String} levelDescription 
	*/
	"setLevelDescription": function(levelDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAlias": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} alias 
	*/
	"setAlias": function(alias) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFullName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} fullName 
	*/
	"setFullName": function(fullName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEmail": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} email 
	*/
	"setEmail": function(email) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getApprovalStatus": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} approvalStatus 
	*/
	"setApprovalStatus": function(approvalStatus) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getApprovalObservation": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} approvalObservation 
	*/
	"setApprovalObservation": function(approvalObservation) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}
};
com.fluig.sdk.api.document.DocumentSecurityVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentSecurityConfigVO&gt;} 
	*/
	"getDocumentSecurityConfigVOs": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} documentSecurityConfigVOs 
	*/
	"setDocumentSecurityConfigVOs": function(documentSecurityConfigVOs) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentPermissionVO&gt;} 
	*/
	"getDocumentPermissionVO": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} documentPermissionVO 
	*/
	"setDocumentPermissionVO": function(documentPermissionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentApproverVO&gt;} 
	*/
	"getDocumentApproverVO": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} documentApproverVO 
	*/
	"setDocumentApproverVO": function(documentApproverVO) {}
};
DocumentSecurityVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentSecurityConfigVO&gt;} 
	*/
	"getDocumentSecurityConfigVOs": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} documentSecurityConfigVOs 
	*/
	"setDocumentSecurityConfigVOs": function(documentSecurityConfigVOs) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentPermissionVO&gt;} 
	*/
	"getDocumentPermissionVO": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} documentPermissionVO 
	*/
	"setDocumentPermissionVO": function(documentPermissionVO) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentApproverVO&gt;} 
	*/
	"getDocumentApproverVO": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} documentApproverVO 
	*/
	"setDocumentApproverVO": function(documentApproverVO) {}
};
com.fluig.sdk.api.document.DocumentApprovementHistoryVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} documentVersion 
	*/
	"setDocumentVersion": function(documentVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getIterationSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} iterationSequence 
	*/
	"setIterationSequence": function(iterationSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getLevelId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} levelId 
	*/
	"setLevelId": function(levelId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} movementSequence 
	*/
	"setMovementSequence": function(movementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getApprovementDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} approvementDate 
	*/
	"setApprovementDate": function(approvementDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getStatus": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} status 
	*/
	"setStatus": function(status) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObservation": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} observation 
	*/
	"setObservation": function(observation) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isSigned": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} signed 
	*/
	"setSigned": function(signed) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueName 
	*/
	"setColleagueName": function(colleagueName) {}
};
DocumentApprovementHistoryVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} documentVersion 
	*/
	"setDocumentVersion": function(documentVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getIterationSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} iterationSequence 
	*/
	"setIterationSequence": function(iterationSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getLevelId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} levelId 
	*/
	"setLevelId": function(levelId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} movementSequence 
	*/
	"setMovementSequence": function(movementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getApprovementDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} approvementDate 
	*/
	"setApprovementDate": function(approvementDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getStatus": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} status 
	*/
	"setStatus": function(status) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObservation": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} observation 
	*/
	"setObservation": function(observation) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isSigned": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} signed 
	*/
	"setSigned": function(signed) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueName 
	*/
	"setColleagueName": function(colleagueName) {}
};
com.fluig.sdk.api.document.FolderVO.prototype = {
	/**
	* Recupera valor do tenantId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* Atribui valor para tenantId
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* Recupera valor do documentoId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* Atribui valor para documentId
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* Recupera valor da versão
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* Atribui valor para versão
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* Recupera valor do iconId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getIconId": function() {}, 
	/**
	* Atribui valor para iconId
	* @memberOf fluigAPI
	* @param {int} iconId 
	*/
	"setIconId": function(iconId) {}, 
	/**
	* Recupera valor do colleagueId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* Atribui valor para colleagueId
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* Recupera valor de descrição do documento
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentDescription": function() {}, 
	/**
	* Atribui valor para descrição do documento
	* @memberOf fluigAPI
	* @param {String} documentDescription 
	*/
	"setDocumentDescription": function(documentDescription) {}, 
	/**
	* Recupera valor da palavra chave
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getKeyWord": function() {}, 
	/**
	* Configura valor da palavra chave
	* @memberOf fluigAPI
	* @param {String} keyWord 
	*/
	"setKeyWord": function(keyWord) {}, 
	/**
	* Recupera valor da data de criação
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCreateDate": function() {}, 
	/**
	* Atribui valor a data de criação
	* @memberOf fluigAPI
	* @param {Date} createDate 
	*/
	"setCreateDate": function(createDate) {}, 
	/**
	* Recupera valor do id da pasta pai
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getParentFolderId": function() {}, 
	/**
	* Atribui valor para id da pasta pai
	* @memberOf fluigAPI
	* @param {int} parentFolderId 
	*/
	"setParentFolderId": function(parentFolderId) {}, 
	/**
	* Recupera id do publicador
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPublisherId": function() {}, 
	/**
	* Atribui valor para id do publicador
	* @memberOf fluigAPI
	* @param {String} publisherId 
	*/
	"setPublisherId": function(publisherId) {}, 
	/**
	* Recupera id do volume
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVolumeId": function() {}, 
	/**
	* Atribui valor do id do volume
	* @memberOf fluigAPI
	* @param {String} volumeId 
	*/
	"setVolumeId": function(volumeId) {}, 
	/**
	* Recupera tipo de permissão
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getPermissionType": function() {}, 
	/**
	* Atribui valor ao tipo de permissão
	* @memberOf fluigAPI
	* @param {int} permissionType 
	*/
	"setPermissionType": function(permissionType) {}, 
	/**
	* Recupera tipo de restrição
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getRestrictionType": function() {}, 
	/**
	* Atribui valor para tipo de restrição
	* @memberOf fluigAPI
	* @param {int} restrictionType 
	*/
	"setRestrictionType": function(restrictionType) {}, 
	/**
	* Recupera segurança herdada
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInheritSecurity": function() {}, 
	/**
	* Atribui valor para segurança herdada
	* @memberOf fluigAPI
	* @param {boolean} inheritSecurity 
	*/
	"setInheritSecurity": function(inheritSecurity) {}, 
	/**
	* Recupera lista de permissões
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentPermissionVO&gt;} 
	*/
	"getPermissions": function() {}, 
	/**
	* Atribui valor para lista de permissões
	* @memberOf fluigAPI
	* @param {List} permissions 
	*/
	"setPermissions": function(permissions) {}, 
	/**
	* Recupera lista de restrições de documentos
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentRestrictionVO&gt;} 
	*/
	"getRestrictions": function() {}, 
	/**
	* Atribui valor para lista de restrições de documentos
	* @memberOf fluigAPI
	* @param {List} restrictions 
	*/
	"setRestrictions": function(restrictions) {}, 
	/**
	* Recupera lista de publicadores aprovadores
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentApproverVO&gt;} 
	*/
	"getPublisherApprovers": function() {}, 
	/**
	* Atribui valor para publicadores aprovadores
	* @memberOf fluigAPI
	* @param {List} publisherApprovers 
	*/
	"setPublisherApprovers": function(publisherApprovers) {}, 
	/**
	* Recupera comentário adicional
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAdditionalComments": function() {}, 
	/**
	* Atribui valor para comentário adicional
	* @memberOf fluigAPI
	* @param {String} additionalComments 
	*/
	"setAdditionalComments": function(additionalComments) {}, 
	/**
	* Recupera valor da descrição da versão
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVersionDescription": function() {}, 
	/**
	* Atribui valor para descrição da versão
	* @memberOf fluigAPI
	* @param {String} versionDescription 
	*/
	"setVersionDescription": function(versionDescription) {}, 
	/**
	* Informa se a pasta pode expirar
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getExpires": function() {}, 
	/**
	* Atribui valor para informar se a pasta pode expirar
	* @memberOf fluigAPI
	* @param {boolean} expires 
	*/
	"setExpires": function(expires) {}, 
	/**
	* Recupera id do topico
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTopicId": function() {}, 
	/**
	* Atribui valor para topicId
	* @memberOf fluigAPI
	* @param {int} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* Recupera valor de approvalAndOr
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getApprovalAndOr": function() {}, 
	/**
	* Atribui valor para approvalAndOr
	* @memberOf fluigAPI
	* @param {boolean} approvalAndOr 
	*/
	"setApprovalAndOr": function(approvalAndOr) {}, 
	/**
	* Recupera informação se download da pasta está disponível
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDownloadEnabled": function() {}, 
	/**
	* Atribui valor para informação se  download de pasta está disponível
	* @memberOf fluigAPI
	* @param {boolean} downloadEnabled 
	*/
	"setDownloadEnabled": function(downloadEnabled) {}, 
	/**
	* Recupera informação se update de iso properties é permitido
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getUpdateIsoProperties": function() {}, 
	/**
	* Atribui permitir atualização de iso properties
	* @memberOf fluigAPI
	* @param {boolean} updateIsoProperties 
	*/
	"setUpdateIsoProperties": function(updateIsoProperties) {}, 
	/**
	* Recupera id do tipo de documento
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentTypeId": function() {}, 
	/**
	* Atribui valor para documentTypeId
	* @memberOf fluigAPI
	* @param {String} documentTypeId 
	*/
	"setDocumentTypeId": function(documentTypeId) {}, 
	/**
	* Recupera boolean se usuário será notificado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getNotifyUser": function() {}, 
	/**
	* Atribui boolean se usuário será notificado
	* @memberOf fluigAPI
	* @param {boolean} notifyUser 
	*/
	"setNotifyUser": function(notifyUser) {}, 
	/**
	* Recupera boolean se pasta é imutavel
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getImutable": function() {}, 
	/**
	* Atribui boolean se pasta será imutavel
	* @memberOf fluigAPI
	* @param {boolean} imutable 
	*/
	"setImutable": function(imutable) {}, 
	/**
	* Recupera valor de visualizador interno
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInternalVisualizer": function() {}, 
	/**
	* Atribui boolean se pasta possui visualizador interno
	* @memberOf fluigAPI
	* @param {boolean} internalVisualizer 
	*/
	"setInternalVisualizer": function(internalVisualizer) {}, 
	/**
	* Recupera boolean se documento é privado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getPrivateDocument": function() {}, 
	/**
	* Atribui boolean se documento é privado
	* @memberOf fluigAPI
	* @param {boolean} privateDocument 
	*/
	"setPrivateDocument": function(privateDocument) {}, 
	/**
	* Recupera os tipos de documento
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getDocumentTypes": function() {}, 
	/**
	* Atribui tipo de documentos
	* @memberOf fluigAPI
	* @param {List} documentTypes 
	*/
	"setDocumentTypes": function(documentTypes) {}, 
	/**
	* Recupera os filtros
	* @memberOf fluigAPI
	* @returns {Map&lt;String,&gt;} 
	*/
	"getFilters": function() {}, 
	/**
	* Atribui filtros
	* @memberOf fluigAPI
	* @param {Map} filters 
	*/
	"setFilters": function(filters) {}
};
FolderVO.prototype = {
	/**
	* Recupera valor do tenantId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* Atribui valor para tenantId
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* Recupera valor do documentoId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* Atribui valor para documentId
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* Recupera valor da versão
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* Atribui valor para versão
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* Recupera valor do iconId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getIconId": function() {}, 
	/**
	* Atribui valor para iconId
	* @memberOf fluigAPI
	* @param {int} iconId 
	*/
	"setIconId": function(iconId) {}, 
	/**
	* Recupera valor do colleagueId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* Atribui valor para colleagueId
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* Recupera valor de descrição do documento
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentDescription": function() {}, 
	/**
	* Atribui valor para descrição do documento
	* @memberOf fluigAPI
	* @param {String} documentDescription 
	*/
	"setDocumentDescription": function(documentDescription) {}, 
	/**
	* Recupera valor da palavra chave
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getKeyWord": function() {}, 
	/**
	* Configura valor da palavra chave
	* @memberOf fluigAPI
	* @param {String} keyWord 
	*/
	"setKeyWord": function(keyWord) {}, 
	/**
	* Recupera valor da data de criação
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCreateDate": function() {}, 
	/**
	* Atribui valor a data de criação
	* @memberOf fluigAPI
	* @param {Date} createDate 
	*/
	"setCreateDate": function(createDate) {}, 
	/**
	* Recupera valor do id da pasta pai
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getParentFolderId": function() {}, 
	/**
	* Atribui valor para id da pasta pai
	* @memberOf fluigAPI
	* @param {int} parentFolderId 
	*/
	"setParentFolderId": function(parentFolderId) {}, 
	/**
	* Recupera id do publicador
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPublisherId": function() {}, 
	/**
	* Atribui valor para id do publicador
	* @memberOf fluigAPI
	* @param {String} publisherId 
	*/
	"setPublisherId": function(publisherId) {}, 
	/**
	* Recupera id do volume
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVolumeId": function() {}, 
	/**
	* Atribui valor do id do volume
	* @memberOf fluigAPI
	* @param {String} volumeId 
	*/
	"setVolumeId": function(volumeId) {}, 
	/**
	* Recupera tipo de permissão
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getPermissionType": function() {}, 
	/**
	* Atribui valor ao tipo de permissão
	* @memberOf fluigAPI
	* @param {int} permissionType 
	*/
	"setPermissionType": function(permissionType) {}, 
	/**
	* Recupera tipo de restrição
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getRestrictionType": function() {}, 
	/**
	* Atribui valor para tipo de restrição
	* @memberOf fluigAPI
	* @param {int} restrictionType 
	*/
	"setRestrictionType": function(restrictionType) {}, 
	/**
	* Recupera segurança herdada
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInheritSecurity": function() {}, 
	/**
	* Atribui valor para segurança herdada
	* @memberOf fluigAPI
	* @param {boolean} inheritSecurity 
	*/
	"setInheritSecurity": function(inheritSecurity) {}, 
	/**
	* Recupera lista de permissões
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentPermissionVO&gt;} 
	*/
	"getPermissions": function() {}, 
	/**
	* Atribui valor para lista de permissões
	* @memberOf fluigAPI
	* @param {List} permissions 
	*/
	"setPermissions": function(permissions) {}, 
	/**
	* Recupera lista de restrições de documentos
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentRestrictionVO&gt;} 
	*/
	"getRestrictions": function() {}, 
	/**
	* Atribui valor para lista de restrições de documentos
	* @memberOf fluigAPI
	* @param {List} restrictions 
	*/
	"setRestrictions": function(restrictions) {}, 
	/**
	* Recupera lista de publicadores aprovadores
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentApproverVO&gt;} 
	*/
	"getPublisherApprovers": function() {}, 
	/**
	* Atribui valor para publicadores aprovadores
	* @memberOf fluigAPI
	* @param {List} publisherApprovers 
	*/
	"setPublisherApprovers": function(publisherApprovers) {}, 
	/**
	* Recupera comentário adicional
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAdditionalComments": function() {}, 
	/**
	* Atribui valor para comentário adicional
	* @memberOf fluigAPI
	* @param {String} additionalComments 
	*/
	"setAdditionalComments": function(additionalComments) {}, 
	/**
	* Recupera valor da descrição da versão
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVersionDescription": function() {}, 
	/**
	* Atribui valor para descrição da versão
	* @memberOf fluigAPI
	* @param {String} versionDescription 
	*/
	"setVersionDescription": function(versionDescription) {}, 
	/**
	* Informa se a pasta pode expirar
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getExpires": function() {}, 
	/**
	* Atribui valor para informar se a pasta pode expirar
	* @memberOf fluigAPI
	* @param {boolean} expires 
	*/
	"setExpires": function(expires) {}, 
	/**
	* Recupera id do topico
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTopicId": function() {}, 
	/**
	* Atribui valor para topicId
	* @memberOf fluigAPI
	* @param {int} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* Recupera valor de approvalAndOr
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getApprovalAndOr": function() {}, 
	/**
	* Atribui valor para approvalAndOr
	* @memberOf fluigAPI
	* @param {boolean} approvalAndOr 
	*/
	"setApprovalAndOr": function(approvalAndOr) {}, 
	/**
	* Recupera informação se download da pasta está disponível
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDownloadEnabled": function() {}, 
	/**
	* Atribui valor para informação se  download de pasta está disponível
	* @memberOf fluigAPI
	* @param {boolean} downloadEnabled 
	*/
	"setDownloadEnabled": function(downloadEnabled) {}, 
	/**
	* Recupera informação se update de iso properties é permitido
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getUpdateIsoProperties": function() {}, 
	/**
	* Atribui permitir atualização de iso properties
	* @memberOf fluigAPI
	* @param {boolean} updateIsoProperties 
	*/
	"setUpdateIsoProperties": function(updateIsoProperties) {}, 
	/**
	* Recupera id do tipo de documento
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentTypeId": function() {}, 
	/**
	* Atribui valor para documentTypeId
	* @memberOf fluigAPI
	* @param {String} documentTypeId 
	*/
	"setDocumentTypeId": function(documentTypeId) {}, 
	/**
	* Recupera boolean se usuário será notificado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getNotifyUser": function() {}, 
	/**
	* Atribui boolean se usuário será notificado
	* @memberOf fluigAPI
	* @param {boolean} notifyUser 
	*/
	"setNotifyUser": function(notifyUser) {}, 
	/**
	* Recupera boolean se pasta é imutavel
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getImutable": function() {}, 
	/**
	* Atribui boolean se pasta será imutavel
	* @memberOf fluigAPI
	* @param {boolean} imutable 
	*/
	"setImutable": function(imutable) {}, 
	/**
	* Recupera valor de visualizador interno
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInternalVisualizer": function() {}, 
	/**
	* Atribui boolean se pasta possui visualizador interno
	* @memberOf fluigAPI
	* @param {boolean} internalVisualizer 
	*/
	"setInternalVisualizer": function(internalVisualizer) {}, 
	/**
	* Recupera boolean se documento é privado
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getPrivateDocument": function() {}, 
	/**
	* Atribui boolean se documento é privado
	* @memberOf fluigAPI
	* @param {boolean} privateDocument 
	*/
	"setPrivateDocument": function(privateDocument) {}, 
	/**
	* Recupera os tipos de documento
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getDocumentTypes": function() {}, 
	/**
	* Atribui tipo de documentos
	* @memberOf fluigAPI
	* @param {List} documentTypes 
	*/
	"setDocumentTypes": function(documentTypes) {}, 
	/**
	* Recupera os filtros
	* @memberOf fluigAPI
	* @returns {Map&lt;String,&gt;} 
	*/
	"getFilters": function() {}, 
	/**
	* Atribui filtros
	* @memberOf fluigAPI
	* @param {Map} filters 
	*/
	"setFilters": function(filters) {}
};
com.fluig.sdk.api.workflow.ProcessDefinitionVO.prototype = {
	/**
	* Recupera valor do processId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* Atribui valor para processId
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* Recupera valor do processDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessDescription": function() {}, 
	/**
	* Atribui valor para processDescription
	* @memberOf fluigAPI
	* @param {String} processDescription 
	*/
	"setProcessDescription": function(processDescription) {}
};
ProcessDefinitionVO.prototype = {
	/**
	* Recupera valor do processId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* Atribui valor para processId
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* Recupera valor do processDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessDescription": function() {}, 
	/**
	* Atribui valor para processDescription
	* @memberOf fluigAPI
	* @param {String} processDescription 
	*/
	"setProcessDescription": function(processDescription) {}
};
com.fluig.sdk.api.workflow.ProcessVersionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getSelected": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} selected 
	*/
	"setSelected": function(selected) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessVersionVO&gt;} 
	*/
	"getChildren": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} children 
	*/
	"setChildren": function(children) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getFormId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} formId 
	*/
	"setFormId": function(formId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVersionDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} versionDescription 
	*/
	"setVersionDescription": function(versionDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getFavorite": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} favorite 
	*/
	"setFavorite": function(favorite) {}
};
ProcessVersionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getSelected": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} selected 
	*/
	"setSelected": function(selected) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessVersionVO&gt;} 
	*/
	"getChildren": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} children 
	*/
	"setChildren": function(children) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getFormId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} formId 
	*/
	"setFormId": function(formId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVersionDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} versionDescription 
	*/
	"setVersionDescription": function(versionDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getFavorite": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} favorite 
	*/
	"setFavorite": function(favorite) {}
};
com.fluig.sdk.api.workflow.ProcessInstanceInfoVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processVersion 
	*/
	"setProcessVersion": function(processVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getFormId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} formId 
	*/
	"setFormId": function(formId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getFormVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} formVersion 
	*/
	"setFormVersion": function(formVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getFormValues": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} formValues 
	*/
	"setFormValues": function(formValues) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessObservationVO&gt;} 
	*/
	"getTaskObservations": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessAttachmentVO&gt;} 
	*/
	"getAttachments": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} attachments 
	*/
	"setAttachments": function(attachments) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} taskObservations 
	*/
	"setTaskObservations": function(taskObservations) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessTaskInfoVO&gt;} 
	*/
	"getTasksInfo": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} tasksInfo 
	*/
	"setTasksInfo": function(tasksInfo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getStartDateProcess": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} startDateProcess 
	*/
	"setStartDateProcess": function(startDateProcess) {}
};
ProcessInstanceInfoVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processVersion 
	*/
	"setProcessVersion": function(processVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getFormId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} formId 
	*/
	"setFormId": function(formId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getFormVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} formVersion 
	*/
	"setFormVersion": function(formVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getFormValues": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} formValues 
	*/
	"setFormValues": function(formValues) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessObservationVO&gt;} 
	*/
	"getTaskObservations": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessAttachmentVO&gt;} 
	*/
	"getAttachments": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} attachments 
	*/
	"setAttachments": function(attachments) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} taskObservations 
	*/
	"setTaskObservations": function(taskObservations) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.ProcessTaskInfoVO&gt;} 
	*/
	"getTasksInfo": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} tasksInfo 
	*/
	"setTasksInfo": function(tasksInfo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getStartDateProcess": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} startDateProcess 
	*/
	"setStartDateProcess": function(startDateProcess) {}
};
com.fluig.sdk.api.workflow.ProcessObservationVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getObservationDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} observationDate 
	*/
	"setObservationDate": function(observationDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getStateSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} stateSequence 
	*/
	"setStateSequence": function(stateSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getThreadSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} threadSequence 
	*/
	"setThreadSequence": function(threadSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} movementSequence 
	*/
	"setMovementSequence": function(movementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObservation": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} observation 
	*/
	"setObservation": function(observation) {}
};
ProcessObservationVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getObservationDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} observationDate 
	*/
	"setObservationDate": function(observationDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getStateSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} stateSequence 
	*/
	"setStateSequence": function(stateSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getThreadSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} threadSequence 
	*/
	"setThreadSequence": function(threadSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} movementSequence 
	*/
	"setMovementSequence": function(movementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObservation": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} observation 
	*/
	"setObservation": function(observation) {}
};
com.fluig.sdk.api.workflow.ProcessTaskVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} movementSequence 
	*/
	"setMovementSequence": function(movementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTransferredSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} transferredSequence 
	*/
	"setTransferredSequence": function(transferredSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSelectedColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} selectedColleagueId 
	*/
	"setSelectedColleagueId": function(selectedColleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getComplement": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} complement 
	*/
	"setComplement": function(complement) {}
};
ProcessTaskVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} movementSequence 
	*/
	"setMovementSequence": function(movementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTransferredSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} transferredSequence 
	*/
	"setTransferredSequence": function(transferredSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSelectedColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} selectedColleagueId 
	*/
	"setSelectedColleagueId": function(selectedColleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getComplement": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} complement 
	*/
	"setComplement": function(complement) {}
};
com.fluig.sdk.api.workflow.AssumeProcessTaskResultVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.enums.AssumeProcessTaskStatus} 
	*/
	"getStatus": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.enums.AssumeProcessTaskStatus} status 
	*/
	"setStatus": function(status) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMessage": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} message 
	*/
	"setMessage": function(message) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} movementSequence 
	*/
	"setMovementSequence": function(movementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getErrorCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} errorCode 
	*/
	"setErrorCode": function(errorCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getComplement": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} complement 
	*/
	"setComplement": function(complement) {}
};
AssumeProcessTaskResultVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.enums.AssumeProcessTaskStatus} 
	*/
	"getStatus": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.enums.AssumeProcessTaskStatus} status 
	*/
	"setStatus": function(status) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMessage": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} message 
	*/
	"setMessage": function(message) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} movementSequence 
	*/
	"setMovementSequence": function(movementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getErrorCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} errorCode 
	*/
	"setErrorCode": function(errorCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getComplement": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} complement 
	*/
	"setComplement": function(complement) {}
};
com.fluig.sdk.api.workflow.AssumeProcessTaskVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} movementSequence 
	*/
	"setMovementSequence": function(movementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getReplacementId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} replacementId 
	*/
	"setReplacementId": function(replacementId) {}
};
AssumeProcessTaskVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} movementSequence 
	*/
	"setMovementSequence": function(movementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getReplacementId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} replacementId 
	*/
	"setReplacementId": function(replacementId) {}
};
com.fluig.sdk.api.workflow.AssumeProcessTasksResultVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getSuccessCount": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} successCount 
	*/
	"setSuccessCount": function(successCount) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFailCount": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} failCount 
	*/
	"setFailCount": function(failCount) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.AssumeProcessTaskResultVO&gt;} 
	*/
	"getAssumeProcessTaskResults": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} assumeProcessTaskResults 
	*/
	"setAssumeProcessTaskResults": function(assumeProcessTaskResults) {}
};
AssumeProcessTasksResultVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getSuccessCount": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} successCount 
	*/
	"setSuccessCount": function(successCount) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFailCount": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} failCount 
	*/
	"setFailCount": function(failCount) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.AssumeProcessTaskResultVO&gt;} 
	*/
	"getAssumeProcessTaskResults": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} assumeProcessTaskResults 
	*/
	"setAssumeProcessTaskResults": function(assumeProcessTaskResults) {}
};
com.fluig.sdk.api.workflow.AssumeProcessTasksVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.AssumeProcessTaskVO&gt;} 
	*/
	"getAssumeProcessTaskList": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} assumeProcessTaskList 
	*/
	"setAssumeProcessTaskList": function(assumeProcessTaskList) {}
};
AssumeProcessTasksVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.AssumeProcessTaskVO&gt;} 
	*/
	"getAssumeProcessTaskList": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} assumeProcessTaskList 
	*/
	"setAssumeProcessTaskList": function(assumeProcessTaskList) {}
};
com.fluig.sdk.api.workflow.CancelInstanceResultVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStatus": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} status 
	*/
	"setStatus": function(status) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMessage": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} message 
	*/
	"setMessage": function(message) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getErrorCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} errorCode 
	*/
	"setErrorCode": function(errorCode) {}
};
CancelInstanceResultVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStatus": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} status 
	*/
	"setStatus": function(status) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMessage": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} message 
	*/
	"setMessage": function(message) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getErrorCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} errorCode 
	*/
	"setErrorCode": function(errorCode) {}
};
com.fluig.sdk.api.workflow.CancelInstanceVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getReplacedId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} replacedId 
	*/
	"setReplacedId": function(replacedId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCancelText": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} cancelText 
	*/
	"setCancelText": function(cancelText) {}
};
CancelInstanceVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getReplacedId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} replacedId 
	*/
	"setReplacedId": function(replacedId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCancelText": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} cancelText 
	*/
	"setCancelText": function(cancelText) {}
};
com.fluig.sdk.api.workflow.CancelInstancesResultVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getSuccessCount": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} successCount 
	*/
	"setSuccessCount": function(successCount) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFailCount": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} failCount 
	*/
	"setFailCount": function(failCount) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.CancelInstanceResultVO&gt;} 
	*/
	"getCancelInstanceResults": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} cancelInstanceResults 
	*/
	"setCancelInstanceResults": function(cancelInstanceResults) {}
};
CancelInstancesResultVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getSuccessCount": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} successCount 
	*/
	"setSuccessCount": function(successCount) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFailCount": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} failCount 
	*/
	"setFailCount": function(failCount) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.CancelInstanceResultVO&gt;} 
	*/
	"getCancelInstanceResults": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} cancelInstanceResults 
	*/
	"setCancelInstanceResults": function(cancelInstanceResults) {}
};
com.fluig.sdk.api.workflow.CancelInstancesVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.CancelInstanceVO&gt;} 
	*/
	"getCancelInstanceList": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} cancelInstanceList 
	*/
	"setCancelInstanceList": function(cancelInstanceList) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCancelText": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} cancelText 
	*/
	"setCancelText": function(cancelText) {}
};
CancelInstancesVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.CancelInstanceVO&gt;} 
	*/
	"getCancelInstanceList": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} cancelInstanceList 
	*/
	"setCancelInstanceList": function(cancelInstanceList) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCancelText": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} cancelText 
	*/
	"setCancelText": function(cancelText) {}
};
com.fluig.sdk.api.workflow.ResumeRequestsSLAVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFinishedRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} finishedRequests 
	*/
	"setFinishedRequests": function(finishedRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFinishedExpiredRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} finishedExpiredRequests 
	*/
	"setFinishedExpiredRequests": function(finishedExpiredRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFinishedOnTimeRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} finishedOnTimeRequests 
	*/
	"setFinishedOnTimeRequests": function(finishedOnTimeRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFinishedWarningRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} finishedWarningRequests 
	*/
	"setFinishedWarningRequests": function(finishedWarningRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCanceledRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} canceledRequests 
	*/
	"setCanceledRequests": function(canceledRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCanceledExpiredRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} canceledExpiredRequests 
	*/
	"setCanceledExpiredRequests": function(canceledExpiredRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCanceledOnTimeRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} canceledOnTimeRequests 
	*/
	"setCanceledOnTimeRequests": function(canceledOnTimeRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCanceledWarningRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} canceledWarningRequests 
	*/
	"setCanceledWarningRequests": function(canceledWarningRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getOpenRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} openRequests 
	*/
	"setOpenRequests": function(openRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getOpenExpiredRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} openExpiredRequests 
	*/
	"setOpenExpiredRequests": function(openExpiredRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getOpenOnTimeRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} openOnTimeRequests 
	*/
	"setOpenOnTimeRequests": function(openOnTimeRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getOpenWarningRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} openWarningRequests 
	*/
	"setOpenWarningRequests": function(openWarningRequests) {}
};
ResumeRequestsSLAVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFinishedRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} finishedRequests 
	*/
	"setFinishedRequests": function(finishedRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFinishedExpiredRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} finishedExpiredRequests 
	*/
	"setFinishedExpiredRequests": function(finishedExpiredRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFinishedOnTimeRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} finishedOnTimeRequests 
	*/
	"setFinishedOnTimeRequests": function(finishedOnTimeRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFinishedWarningRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} finishedWarningRequests 
	*/
	"setFinishedWarningRequests": function(finishedWarningRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCanceledRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} canceledRequests 
	*/
	"setCanceledRequests": function(canceledRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCanceledExpiredRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} canceledExpiredRequests 
	*/
	"setCanceledExpiredRequests": function(canceledExpiredRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCanceledOnTimeRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} canceledOnTimeRequests 
	*/
	"setCanceledOnTimeRequests": function(canceledOnTimeRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCanceledWarningRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} canceledWarningRequests 
	*/
	"setCanceledWarningRequests": function(canceledWarningRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getOpenRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} openRequests 
	*/
	"setOpenRequests": function(openRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getOpenExpiredRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} openExpiredRequests 
	*/
	"setOpenExpiredRequests": function(openExpiredRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getOpenOnTimeRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} openOnTimeRequests 
	*/
	"setOpenOnTimeRequests": function(openOnTimeRequests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getOpenWarningRequests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} openWarningRequests 
	*/
	"setOpenWarningRequests": function(openWarningRequests) {}
};
com.fluig.sdk.api.workflow.RequestSLAVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getPercentageConcluded": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} percentageConcluded 
	*/
	"setPercentageConcluded": function(percentageConcluded) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDeadlineDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} deadlineDate 
	*/
	"setDeadlineDate": function(deadlineDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequesterCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requesterCode 
	*/
	"setRequesterCode": function(requesterCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequesterName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requesterName 
	*/
	"setRequesterName": function(requesterName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getRemainingTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} remainingTime 
	*/
	"setRemainingTime": function(remainingTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStatusSla": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} statusSla 
	*/
	"setStatusSla": function(statusSla) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processDescription 
	*/
	"setProcessDescription": function(processDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getStartDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} startDate 
	*/
	"setStartDate": function(startDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFullTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} fullTime 
	*/
	"setFullTime": function(fullTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"getRequesterLocal": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.local.LocalVO} requesterLocal 
	*/
	"setRequesterLocal": function(requesterLocal) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.RequestTaskSLAVO&gt;} 
	*/
	"getActualTasks": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} actualTasks 
	*/
	"setActualTasks": function(actualTasks) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getEndDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} endDate 
	*/
	"setEndDate": function(endDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processVersion 
	*/
	"setProcessVersion": function(processVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStatusRequest": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} statusRequest 
	*/
	"setStatusRequest": function(statusRequest) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} warningDate 
	*/
	"setWarningDate": function(warningDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getWarningDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getExpandables": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} expandables 
	*/
	"setExpandables": function(expandables) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getCardFields": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} cardFields 
	*/
	"setCardFields": function(cardFields) {}
};
RequestSLAVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getPercentageConcluded": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} percentageConcluded 
	*/
	"setPercentageConcluded": function(percentageConcluded) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDeadlineDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} deadlineDate 
	*/
	"setDeadlineDate": function(deadlineDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequesterCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requesterCode 
	*/
	"setRequesterCode": function(requesterCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequesterName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requesterName 
	*/
	"setRequesterName": function(requesterName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getRemainingTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} remainingTime 
	*/
	"setRemainingTime": function(remainingTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStatusSla": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} statusSla 
	*/
	"setStatusSla": function(statusSla) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processDescription 
	*/
	"setProcessDescription": function(processDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getStartDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} startDate 
	*/
	"setStartDate": function(startDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFullTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} fullTime 
	*/
	"setFullTime": function(fullTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"getRequesterLocal": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.local.LocalVO} requesterLocal 
	*/
	"setRequesterLocal": function(requesterLocal) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.RequestTaskSLAVO&gt;} 
	*/
	"getActualTasks": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} actualTasks 
	*/
	"setActualTasks": function(actualTasks) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getEndDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} endDate 
	*/
	"setEndDate": function(endDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processVersion 
	*/
	"setProcessVersion": function(processVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStatusRequest": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} statusRequest 
	*/
	"setStatusRequest": function(statusRequest) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} warningDate 
	*/
	"setWarningDate": function(warningDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getWarningDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getExpandables": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} expandables 
	*/
	"setExpandables": function(expandables) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getCardFields": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} cardFields 
	*/
	"setCardFields": function(cardFields) {}
};
com.fluig.sdk.api.workflow.ResumeProcessTaskVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTotal": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} total 
	*/
	"setTotal": function(total) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOnTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} onTime 
	*/
	"setOnTime": function(onTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWarning": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} warning 
	*/
	"setWarning": function(warning) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getExpired": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} expired 
	*/
	"setExpired": function(expired) {}
};
ResumeProcessTaskVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTotal": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} total 
	*/
	"setTotal": function(total) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOnTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} onTime 
	*/
	"setOnTime": function(onTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWarning": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} warning 
	*/
	"setWarning": function(warning) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getExpired": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} expired 
	*/
	"setExpired": function(expired) {}
};
com.fluig.sdk.api.workflow.RequestProcessTaskVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processDescription 
	*/
	"setProcessDescription": function(processDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequesterCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requesterCode 
	*/
	"setRequesterCode": function(requesterCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequesterName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requesterName 
	*/
	"setRequesterName": function(requesterName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getStatusTask": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} statusTask 
	*/
	"setStatusTask": function(statusTask) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getStartDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} startDate 
	*/
	"setStartDate": function(startDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processVersion 
	*/
	"setProcessVersion": function(processVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getWarningDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} warningDate 
	*/
	"setWarningDate": function(warningDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDeadlineDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} deadlineDate 
	*/
	"setDeadlineDate": function(deadlineDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getEndDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} endDate 
	*/
	"setEndDate": function(endDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getNomeEstado": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} nomeEstado 
	*/
	"setNomeEstado": function(nomeEstado) {}
};
RequestProcessTaskVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processDescription 
	*/
	"setProcessDescription": function(processDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequesterCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requesterCode 
	*/
	"setRequesterCode": function(requesterCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequesterName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requesterName 
	*/
	"setRequesterName": function(requesterName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getStatusTask": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} statusTask 
	*/
	"setStatusTask": function(statusTask) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getStartDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} startDate 
	*/
	"setStartDate": function(startDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processVersion 
	*/
	"setProcessVersion": function(processVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getWarningDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} warningDate 
	*/
	"setWarningDate": function(warningDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDeadlineDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} deadlineDate 
	*/
	"setDeadlineDate": function(deadlineDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getEndDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} endDate 
	*/
	"setEndDate": function(endDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getNomeEstado": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} nomeEstado 
	*/
	"setNomeEstado": function(nomeEstado) {}
};
com.fluig.sdk.api.workflow.CardItemVO.prototype = {
	/**
	* Recupera valor do documentId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* Atribui valor para documentId
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* Recupera valor do documentDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentDescription": function() {}, 
	/**
	* Atribui valor para documentDescription
	* @memberOf fluigAPI
	* @param {String} documentDescription 
	*/
	"setDocumentDescription": function(documentDescription) {}, 
	/**
	* Recupera valor do parentDocumentId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getParentDocumentId": function() {}, 
	/**
	* Atribui valor para parentDocumentId
	* @memberOf fluigAPI
	* @param {int} parentDocumentId 
	*/
	"setParentDocumentId": function(parentDocumentId) {}, 
	/**
	* Recupera valor do privateDocument
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getPrivateDocument": function() {}, 
	/**
	* Atribui valor para privateDocument
	* @memberOf fluigAPI
	* @param {boolean} privateDocument 
	*/
	"setPrivateDocument": function(privateDocument) {}, 
	/**
	* Recupera valor do tenantId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* Atribui valor para tenantId
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* Recupera valor do version
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* Atribui valor para version
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* Recupera valor do metaListId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMetaListId": function() {}, 
	/**
	* Atribui valor para metaListId
	* @memberOf fluigAPI
	* @param {int} metaListId 
	*/
	"setMetaListId": function(metaListId) {}, 
	/**
	* Recupera valor do inheritSecurity
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInheritSecurity": function() {}, 
	/**
	* Atribui valor para inheritSecurity
	* @memberOf fluigAPI
	* @param {boolean} inheritSecurity 
	*/
	"setInheritSecurity": function(inheritSecurity) {}, 
	/**
	* Recupera valor do permissionType
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getPermissionType": function() {}, 
	/**
	* Atribui valor para permissionType
	* @memberOf fluigAPI
	* @param {int} permissionType 
	*/
	"setPermissionType": function(permissionType) {}, 
	/**
	* Recupera valor do restrictionType
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getRestrictionType": function() {}, 
	/**
	* Atribui valor para restrictionType
	* @memberOf fluigAPI
	* @param {int} restrictionType 
	*/
	"setRestrictionType": function(restrictionType) {}, 
	/**
	* Recupera valor do userNotify
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getUserNotify": function() {}, 
	/**
	* Atribui valor para userNotify
	* @memberOf fluigAPI
	* @param {boolean} userNotify 
	*/
	"setUserNotify": function(userNotify) {}, 
	/**
	* Recupera valor do colleagueId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* Atribui valor para colleagueId
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* Recupera valor do additionalComments
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAdditionalComments": function() {}, 
	/**
	* Atribui valor para additionalComments
	* @memberOf fluigAPI
	* @param {String} additionalComments 
	*/
	"setAdditionalComments": function(additionalComments) {}, 
	/**
	* Recupera valor do keyWord
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getKeyWord": function() {}, 
	/**
	* Atribui valor para keyWord
	* @memberOf fluigAPI
	* @param {String} keyWord 
	*/
	"setKeyWord": function(keyWord) {}, 
	/**
	* Recupera valor do versionDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVersionDescription": function() {}, 
	/**
	* Atribui valor para versionDescription
	* @memberOf fluigAPI
	* @param {String} versionDescription 
	*/
	"setVersionDescription": function(versionDescription) {}, 
	/**
	* Recupera valor do versionOption
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVersionOption": function() {}, 
	/**
	* Atribui valor para versionOption
	* @memberOf fluigAPI
	* @param {String} versionOption 
	*/
	"setVersionOption": function(versionOption) {}, 
	/**
	* Recupera valor do expires
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getExpires": function() {}, 
	/**
	* Atribui valor para expires
	* @memberOf fluigAPI
	* @param {boolean} expires 
	*/
	"setExpires": function(expires) {}, 
	/**
	* Recupera valor do topicId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTopicId": function() {}, 
	/**
	* Atribui valor para topicId
	* @memberOf fluigAPI
	* @param {int} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* Recupera valor do iconId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getIconId": function() {}, 
	/**
	* Atribui valor para iconId
	* @memberOf fluigAPI
	* @param {int} iconId 
	*/
	"setIconId": function(iconId) {}, 
	/**
	* Recupera valor do imutable
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getImutable": function() {}, 
	/**
	* Atribui valor para imutable
	* @memberOf fluigAPI
	* @param {boolean} imutable 
	*/
	"setImutable": function(imutable) {}, 
	/**
	* Recupera valor do languageId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLanguageId": function() {}, 
	/**
	* Atribui valor para languageId
	* @memberOf fluigAPI
	* @param {String} languageId 
	*/
	"setLanguageId": function(languageId) {}, 
	/**
	* Recupera valor do internalVisualizer
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInternalVisualizer": function() {}, 
	/**
	* Atribui valor para internalVisualizer
	* @memberOf fluigAPI
	* @param {boolean} internalVisualizer 
	*/
	"setInternalVisualizer": function(internalVisualizer) {}, 
	/**
	* Recupera valor do downloadEnabled
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDownloadEnabled": function() {}, 
	/**
	* Atribui valor para downloadEnabled
	* @memberOf fluigAPI
	* @param {boolean} downloadEnabled 
	*/
	"setDownloadEnabled": function(downloadEnabled) {}, 
	/**
	* Recupera valor do updateIsoProperties
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getUpdateIsoProperties": function() {}, 
	/**
	* Atribui valor para updateIsoProperties
	* @memberOf fluigAPI
	* @param {boolean} updateIsoProperties 
	*/
	"setUpdateIsoProperties": function(updateIsoProperties) {}, 
	/**
	* Recupera valor do documentTypeId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentTypeId": function() {}, 
	/**
	* Atribui valor para documentTypeId
	* @memberOf fluigAPI
	* @param {String} documentTypeId 
	*/
	"setDocumentTypeId": function(documentTypeId) {}, 
	/**
	* Recupera valor do notificationDays
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNotificationDays": function() {}, 
	/**
	* Atribui valor para notificationDays
	* @memberOf fluigAPI
	* @param {int} notificationDays 
	*/
	"setNotificationDays": function(notificationDays) {}, 
	/**
	* Recupera valor do validationStartDate
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getValidationStartDate": function() {}, 
	/**
	* Atribui valor para validationStartDate
	* @memberOf fluigAPI
	* @param {Date} validationStartDate 
	*/
	"setValidationStartDate": function(validationStartDate) {}, 
	/**
	* Recupera valor do expirationDate
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getExpirationDate": function() {}, 
	/**
	* Atribui valor para expirationDate
	* @memberOf fluigAPI
	* @param {Date} expirationDate 
	*/
	"setExpirationDate": function(expirationDate) {}, 
	/**
	* Recupera valor do documentType
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentType": function() {}, 
	/**
	* Atribui valor para documentType
	* @memberOf fluigAPI
	* @param {String} documentType 
	*/
	"setDocumentType": function(documentType) {}, 
	/**
	* Recupera valor do permissions
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentPermissionVO&gt;} 
	*/
	"getPermissions": function() {}, 
	/**
	* Atribui valor para permissions
	* @memberOf fluigAPI
	* @param {List} permissions 
	*/
	"setPermissions": function(permissions) {}, 
	/**
	* Recupera valor do restrictions
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentRestrictionVO&gt;} 
	*/
	"getRestrictions": function() {}, 
	/**
	* Atribui valor para restrictions
	* @memberOf fluigAPI
	* @param {List} restrictions 
	*/
	"setRestrictions": function(restrictions) {}, 
	/**
	* Recupera valor do publisherApprovers
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentApproverVO&gt;} 
	*/
	"getPublisherApprovers": function() {}, 
	/**
	* Atribui valor para publisherApprovers
	* @memberOf fluigAPI
	* @param {List} publisherApprovers 
	*/
	"setPublisherApprovers": function(publisherApprovers) {}, 
	/**
	* Recupera valor do relatedDocuments
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.RelatedDocumentVO&gt;} 
	*/
	"getRelatedDocuments": function() {}, 
	/**
	* Atribui valor para relatedDocuments
	* @memberOf fluigAPI
	* @param {List} relatedDocuments 
	*/
	"setRelatedDocuments": function(relatedDocuments) {}, 
	/**
	* Recupera valor do attachments
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.AttachmentVO&gt;} 
	*/
	"getAttachments": function() {}, 
	/**
	* Atribui valor para attachments
	* @memberOf fluigAPI
	* @param {List} attachments 
	*/
	"setAttachments": function(attachments) {}, 
	/**
	* Recupera valor do formData
	* @memberOf fluigAPI
	* @returns {List&lt;Map,String,String&gt;} 
	*/
	"getFormData": function() {}, 
	/**
	* Atribui valor para formData
	* @memberOf fluigAPI
	* @param {List} formData 
	*/
	"setFormData": function(formData) {}
};
CardItemVO.prototype = {
	/**
	* Recupera valor do documentId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* Atribui valor para documentId
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* Recupera valor do documentDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentDescription": function() {}, 
	/**
	* Atribui valor para documentDescription
	* @memberOf fluigAPI
	* @param {String} documentDescription 
	*/
	"setDocumentDescription": function(documentDescription) {}, 
	/**
	* Recupera valor do parentDocumentId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getParentDocumentId": function() {}, 
	/**
	* Atribui valor para parentDocumentId
	* @memberOf fluigAPI
	* @param {int} parentDocumentId 
	*/
	"setParentDocumentId": function(parentDocumentId) {}, 
	/**
	* Recupera valor do privateDocument
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getPrivateDocument": function() {}, 
	/**
	* Atribui valor para privateDocument
	* @memberOf fluigAPI
	* @param {boolean} privateDocument 
	*/
	"setPrivateDocument": function(privateDocument) {}, 
	/**
	* Recupera valor do tenantId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* Atribui valor para tenantId
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* Recupera valor do version
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* Atribui valor para version
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* Recupera valor do metaListId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMetaListId": function() {}, 
	/**
	* Atribui valor para metaListId
	* @memberOf fluigAPI
	* @param {int} metaListId 
	*/
	"setMetaListId": function(metaListId) {}, 
	/**
	* Recupera valor do inheritSecurity
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInheritSecurity": function() {}, 
	/**
	* Atribui valor para inheritSecurity
	* @memberOf fluigAPI
	* @param {boolean} inheritSecurity 
	*/
	"setInheritSecurity": function(inheritSecurity) {}, 
	/**
	* Recupera valor do permissionType
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getPermissionType": function() {}, 
	/**
	* Atribui valor para permissionType
	* @memberOf fluigAPI
	* @param {int} permissionType 
	*/
	"setPermissionType": function(permissionType) {}, 
	/**
	* Recupera valor do restrictionType
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getRestrictionType": function() {}, 
	/**
	* Atribui valor para restrictionType
	* @memberOf fluigAPI
	* @param {int} restrictionType 
	*/
	"setRestrictionType": function(restrictionType) {}, 
	/**
	* Recupera valor do userNotify
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getUserNotify": function() {}, 
	/**
	* Atribui valor para userNotify
	* @memberOf fluigAPI
	* @param {boolean} userNotify 
	*/
	"setUserNotify": function(userNotify) {}, 
	/**
	* Recupera valor do colleagueId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* Atribui valor para colleagueId
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* Recupera valor do additionalComments
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAdditionalComments": function() {}, 
	/**
	* Atribui valor para additionalComments
	* @memberOf fluigAPI
	* @param {String} additionalComments 
	*/
	"setAdditionalComments": function(additionalComments) {}, 
	/**
	* Recupera valor do keyWord
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getKeyWord": function() {}, 
	/**
	* Atribui valor para keyWord
	* @memberOf fluigAPI
	* @param {String} keyWord 
	*/
	"setKeyWord": function(keyWord) {}, 
	/**
	* Recupera valor do versionDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVersionDescription": function() {}, 
	/**
	* Atribui valor para versionDescription
	* @memberOf fluigAPI
	* @param {String} versionDescription 
	*/
	"setVersionDescription": function(versionDescription) {}, 
	/**
	* Recupera valor do versionOption
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVersionOption": function() {}, 
	/**
	* Atribui valor para versionOption
	* @memberOf fluigAPI
	* @param {String} versionOption 
	*/
	"setVersionOption": function(versionOption) {}, 
	/**
	* Recupera valor do expires
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getExpires": function() {}, 
	/**
	* Atribui valor para expires
	* @memberOf fluigAPI
	* @param {boolean} expires 
	*/
	"setExpires": function(expires) {}, 
	/**
	* Recupera valor do topicId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTopicId": function() {}, 
	/**
	* Atribui valor para topicId
	* @memberOf fluigAPI
	* @param {int} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* Recupera valor do iconId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getIconId": function() {}, 
	/**
	* Atribui valor para iconId
	* @memberOf fluigAPI
	* @param {int} iconId 
	*/
	"setIconId": function(iconId) {}, 
	/**
	* Recupera valor do imutable
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getImutable": function() {}, 
	/**
	* Atribui valor para imutable
	* @memberOf fluigAPI
	* @param {boolean} imutable 
	*/
	"setImutable": function(imutable) {}, 
	/**
	* Recupera valor do languageId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLanguageId": function() {}, 
	/**
	* Atribui valor para languageId
	* @memberOf fluigAPI
	* @param {String} languageId 
	*/
	"setLanguageId": function(languageId) {}, 
	/**
	* Recupera valor do internalVisualizer
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInternalVisualizer": function() {}, 
	/**
	* Atribui valor para internalVisualizer
	* @memberOf fluigAPI
	* @param {boolean} internalVisualizer 
	*/
	"setInternalVisualizer": function(internalVisualizer) {}, 
	/**
	* Recupera valor do downloadEnabled
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDownloadEnabled": function() {}, 
	/**
	* Atribui valor para downloadEnabled
	* @memberOf fluigAPI
	* @param {boolean} downloadEnabled 
	*/
	"setDownloadEnabled": function(downloadEnabled) {}, 
	/**
	* Recupera valor do updateIsoProperties
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getUpdateIsoProperties": function() {}, 
	/**
	* Atribui valor para updateIsoProperties
	* @memberOf fluigAPI
	* @param {boolean} updateIsoProperties 
	*/
	"setUpdateIsoProperties": function(updateIsoProperties) {}, 
	/**
	* Recupera valor do documentTypeId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentTypeId": function() {}, 
	/**
	* Atribui valor para documentTypeId
	* @memberOf fluigAPI
	* @param {String} documentTypeId 
	*/
	"setDocumentTypeId": function(documentTypeId) {}, 
	/**
	* Recupera valor do notificationDays
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNotificationDays": function() {}, 
	/**
	* Atribui valor para notificationDays
	* @memberOf fluigAPI
	* @param {int} notificationDays 
	*/
	"setNotificationDays": function(notificationDays) {}, 
	/**
	* Recupera valor do validationStartDate
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getValidationStartDate": function() {}, 
	/**
	* Atribui valor para validationStartDate
	* @memberOf fluigAPI
	* @param {Date} validationStartDate 
	*/
	"setValidationStartDate": function(validationStartDate) {}, 
	/**
	* Recupera valor do expirationDate
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getExpirationDate": function() {}, 
	/**
	* Atribui valor para expirationDate
	* @memberOf fluigAPI
	* @param {Date} expirationDate 
	*/
	"setExpirationDate": function(expirationDate) {}, 
	/**
	* Recupera valor do documentType
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentType": function() {}, 
	/**
	* Atribui valor para documentType
	* @memberOf fluigAPI
	* @param {String} documentType 
	*/
	"setDocumentType": function(documentType) {}, 
	/**
	* Recupera valor do permissions
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentPermissionVO&gt;} 
	*/
	"getPermissions": function() {}, 
	/**
	* Atribui valor para permissions
	* @memberOf fluigAPI
	* @param {List} permissions 
	*/
	"setPermissions": function(permissions) {}, 
	/**
	* Recupera valor do restrictions
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentRestrictionVO&gt;} 
	*/
	"getRestrictions": function() {}, 
	/**
	* Atribui valor para restrictions
	* @memberOf fluigAPI
	* @param {List} restrictions 
	*/
	"setRestrictions": function(restrictions) {}, 
	/**
	* Recupera valor do publisherApprovers
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.DocumentApproverVO&gt;} 
	*/
	"getPublisherApprovers": function() {}, 
	/**
	* Atribui valor para publisherApprovers
	* @memberOf fluigAPI
	* @param {List} publisherApprovers 
	*/
	"setPublisherApprovers": function(publisherApprovers) {}, 
	/**
	* Recupera valor do relatedDocuments
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.document.RelatedDocumentVO&gt;} 
	*/
	"getRelatedDocuments": function() {}, 
	/**
	* Atribui valor para relatedDocuments
	* @memberOf fluigAPI
	* @param {List} relatedDocuments 
	*/
	"setRelatedDocuments": function(relatedDocuments) {}, 
	/**
	* Recupera valor do attachments
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.AttachmentVO&gt;} 
	*/
	"getAttachments": function() {}, 
	/**
	* Atribui valor para attachments
	* @memberOf fluigAPI
	* @param {List} attachments 
	*/
	"setAttachments": function(attachments) {}, 
	/**
	* Recupera valor do formData
	* @memberOf fluigAPI
	* @returns {List&lt;Map,String,String&gt;} 
	*/
	"getFormData": function() {}, 
	/**
	* Atribui valor para formData
	* @memberOf fluigAPI
	* @param {List} formData 
	*/
	"setFormData": function(formData) {}
};
com.fluig.sdk.api.workflow.CardIndexVO.prototype = {
	/**
	* Recupera valor do tenantId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* Atribui valor para tenantId
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* Recupera valor do documentId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* Atribui valor para documentId
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* Recupera valor do parentDocumentId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getParentDocumentId": function() {}, 
	/**
	* Atribui valor para parentDocumentId
	* @memberOf fluigAPI
	* @param {int} parentDocumentId 
	*/
	"setParentDocumentId": function(parentDocumentId) {}, 
	/**
	* Recupera valor do publisherId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPublisherId": function() {}, 
	/**
	* Atribui valor para publisherId
	* @memberOf fluigAPI
	* @param {String} publisherId 
	*/
	"setPublisherId": function(publisherId) {}, 
	/**
	* Recupera valor do documentDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentDescription": function() {}, 
	/**
	* Atribui valor para documentDescription
	* @memberOf fluigAPI
	* @param {String} documentDescription 
	*/
	"setDocumentDescription": function(documentDescription) {}, 
	/**
	* Recupera valor do cardDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCardDescription": function() {}, 
	/**
	* Atribui valor para cardDescription
	* @memberOf fluigAPI
	* @param {String} cardDescription 
	*/
	"setCardDescription": function(cardDescription) {}, 
	/**
	* Recupera valor do datasetName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDatasetName": function() {}, 
	/**
	* Atribui valor para datasetName
	* @memberOf fluigAPI
	* @param {String} datasetName 
	*/
	"setDatasetName": function(datasetName) {}, 
	/**
	* Recupera valor do persistenceType
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getPersistenceType": function() {}, 
	/**
	* Atribui valor para persistenceType
	* @memberOf fluigAPI
	* @param {int} persistenceType 
	*/
	"setPersistenceType": function(persistenceType) {}, 
	/**
	* Recupera valor do attachments
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.CardIndexAttachmentVO&gt;} 
	*/
	"getAttachments": function() {}, 
	/**
	* Atribui valor para attachments
	* @memberOf fluigAPI
	* @param {List} attachments 
	*/
	"setAttachments": function(attachments) {}
};
CardIndexVO.prototype = {
	/**
	* Recupera valor do tenantId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* Atribui valor para tenantId
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* Recupera valor do documentId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* Atribui valor para documentId
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* Recupera valor do parentDocumentId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getParentDocumentId": function() {}, 
	/**
	* Atribui valor para parentDocumentId
	* @memberOf fluigAPI
	* @param {int} parentDocumentId 
	*/
	"setParentDocumentId": function(parentDocumentId) {}, 
	/**
	* Recupera valor do publisherId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPublisherId": function() {}, 
	/**
	* Atribui valor para publisherId
	* @memberOf fluigAPI
	* @param {String} publisherId 
	*/
	"setPublisherId": function(publisherId) {}, 
	/**
	* Recupera valor do documentDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentDescription": function() {}, 
	/**
	* Atribui valor para documentDescription
	* @memberOf fluigAPI
	* @param {String} documentDescription 
	*/
	"setDocumentDescription": function(documentDescription) {}, 
	/**
	* Recupera valor do cardDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCardDescription": function() {}, 
	/**
	* Atribui valor para cardDescription
	* @memberOf fluigAPI
	* @param {String} cardDescription 
	*/
	"setCardDescription": function(cardDescription) {}, 
	/**
	* Recupera valor do datasetName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDatasetName": function() {}, 
	/**
	* Atribui valor para datasetName
	* @memberOf fluigAPI
	* @param {String} datasetName 
	*/
	"setDatasetName": function(datasetName) {}, 
	/**
	* Recupera valor do persistenceType
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getPersistenceType": function() {}, 
	/**
	* Atribui valor para persistenceType
	* @memberOf fluigAPI
	* @param {int} persistenceType 
	*/
	"setPersistenceType": function(persistenceType) {}, 
	/**
	* Recupera valor do attachments
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.workflow.CardIndexAttachmentVO&gt;} 
	*/
	"getAttachments": function() {}, 
	/**
	* Atribui valor para attachments
	* @memberOf fluigAPI
	* @param {List} attachments 
	*/
	"setAttachments": function(attachments) {}
};
com.fluig.sdk.api.job.JobVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getJobId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} jobId 
	*/
	"setJobId": function(jobId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getJobType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} jobType 
	*/
	"setJobType": function(jobType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOrdinalNumber": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} ordinalNumber 
	*/
	"setOrdinalNumber": function(ordinalNumber) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getExecutionHour": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getStartDateInMillis": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} startDateInMillis 
	*/
	"setStartDateInMillis": function(startDateInMillis) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} executionHour 
	*/
	"setExecutionHour": function(executionHour) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getExecutionMinute": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} executionMinute 
	*/
	"setExecutionMinute": function(executionMinute) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getData": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} data 
	*/
	"setData": function(data) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getLastExecution": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} lastExecution 
	*/
	"setLastExecution": function(lastExecution) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getNextExecution": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} nextExecution 
	*/
	"setNextExecution": function(nextExecution) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getStarted": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} started 
	*/
	"setStarted": function(started) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRecurrenceExpression": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} recurrenceExpression 
	*/
	"setRecurrenceExpression": function(recurrenceExpression) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getInterval": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} interval 
	*/
	"setInterval": function(interval) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTarget": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} target 
	*/
	"setTarget": function(target) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.job.JobVO.IntervalType} 
	*/
	"getIntervalType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.job.JobVO.IntervalType} intervalType 
	*/
	"setIntervalType": function(intervalType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  obj 
	* @returns {boolean} 
	*/
	"equals": function(obj) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getIntervalDescriptions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} intervalDescriptions 
	*/
	"setIntervalDescriptions": function(intervalDescriptions) {}
};
JobVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getJobId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} jobId 
	*/
	"setJobId": function(jobId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getJobType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} jobType 
	*/
	"setJobType": function(jobType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOrdinalNumber": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} ordinalNumber 
	*/
	"setOrdinalNumber": function(ordinalNumber) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getExecutionHour": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getStartDateInMillis": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} startDateInMillis 
	*/
	"setStartDateInMillis": function(startDateInMillis) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} executionHour 
	*/
	"setExecutionHour": function(executionHour) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getExecutionMinute": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} executionMinute 
	*/
	"setExecutionMinute": function(executionMinute) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getData": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} data 
	*/
	"setData": function(data) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getLastExecution": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} lastExecution 
	*/
	"setLastExecution": function(lastExecution) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getNextExecution": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} nextExecution 
	*/
	"setNextExecution": function(nextExecution) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getStarted": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} started 
	*/
	"setStarted": function(started) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRecurrenceExpression": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} recurrenceExpression 
	*/
	"setRecurrenceExpression": function(recurrenceExpression) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getInterval": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} interval 
	*/
	"setInterval": function(interval) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTarget": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} target 
	*/
	"setTarget": function(target) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.job.JobVO.IntervalType} 
	*/
	"getIntervalType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.job.JobVO.IntervalType} intervalType 
	*/
	"setIntervalType": function(intervalType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  obj 
	* @returns {boolean} 
	*/
	"equals": function(obj) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getIntervalDescriptions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} intervalDescriptions 
	*/
	"setIntervalDescriptions": function(intervalDescriptions) {}
};
com.fluig.sdk.page.PublicApiPageVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getPageId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} pageId 
	*/
	"setPageId": function(pageId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSearchLevel": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} searchLevel 
	*/
	"setSearchLevel": function(searchLevel) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPageCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	*/
	"setPageCode": function(pageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.page.PublicApiPageVO&gt;} 
	*/
	"getChildren": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} children 
	*/
	"setChildren": function(children) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getParentPageCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} parentPageCode 
	*/
	"setParentPageCode": function(parentPageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUri": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} uri 
	*/
	"setUri": function(uri) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFriendlyURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} friendlyURL 
	*/
	"setFriendlyURL": function(friendlyURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPageIcon": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageIcon 
	*/
	"setPageIcon": function(pageIcon) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getEnabledMobileApp": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} enabledMobileApp 
	*/
	"setEnabledMobileApp": function(enabledMobileApp) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getLastUpdate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} lastUpdate 
	*/
	"setLastUpdate": function(lastUpdate) {}
};
PublicApiPageVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getPageId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} pageId 
	*/
	"setPageId": function(pageId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSearchLevel": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} searchLevel 
	*/
	"setSearchLevel": function(searchLevel) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPageCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageCode 
	*/
	"setPageCode": function(pageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.page.PublicApiPageVO&gt;} 
	*/
	"getChildren": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} children 
	*/
	"setChildren": function(children) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getParentPageCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} parentPageCode 
	*/
	"setParentPageCode": function(parentPageCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUri": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} uri 
	*/
	"setUri": function(uri) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFriendlyURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} friendlyURL 
	*/
	"setFriendlyURL": function(friendlyURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPageIcon": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pageIcon 
	*/
	"setPageIcon": function(pageIcon) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getEnabledMobileApp": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} enabledMobileApp 
	*/
	"setEnabledMobileApp": function(enabledMobileApp) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getLastUpdate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} lastUpdate 
	*/
	"setLastUpdate": function(lastUpdate) {}
};
com.fluig.sdk.page.PageMobileApiVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	* @returns {com.fluig.sdk.page.PageMobileApiVO} 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	* @returns {com.fluig.sdk.page.PageMobileApiVO} 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isMobileEnabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} mobileEnabled 
	* @returns {com.fluig.sdk.page.PageMobileApiVO} 
	*/
	"setMobileEnabled": function(mobileEnabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.page.PageWidgetMobileApiVO&gt;} 
	*/
	"getWidgets": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} widgets 
	* @returns {com.fluig.sdk.page.PageMobileApiVO} 
	*/
	"setWidgets": function(widgets) {}
};
PageMobileApiVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	* @returns {com.fluig.sdk.page.PageMobileApiVO} 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	* @returns {com.fluig.sdk.page.PageMobileApiVO} 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isMobileEnabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} mobileEnabled 
	* @returns {com.fluig.sdk.page.PageMobileApiVO} 
	*/
	"setMobileEnabled": function(mobileEnabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.page.PageWidgetMobileApiVO&gt;} 
	*/
	"getWidgets": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} widgets 
	* @returns {com.fluig.sdk.page.PageMobileApiVO} 
	*/
	"setWidgets": function(widgets) {}
};
com.fluig.sdk.api.social.PostVO.prototype = {
	/**
	* Recupera valor do id
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* Atribui valor para id
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* Recupera valor do text
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getText": function() {}, 
	/**
	* Atribui valor para text
	* @memberOf fluigAPI
	* @param {String} text 
	*/
	"setText": function(text) {}, 
	/**
	* Recupera valor do visibility
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVisibility": function() {}, 
	/**
	* Atribui valor para visibility
	* @memberOf fluigAPI
	* @param {String} visibility 
	*/
	"setVisibility": function(visibility) {}, 
	/**
	* Recupera valor do alias
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAlias": function() {}, 
	/**
	* Atribui valor para alias
	* @memberOf fluigAPI
	* @param {String} alias 
	*/
	"setAlias": function(alias) {}, 
	/**
	* Recupera valor do customUsers
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getCustomUsers": function() {}, 
	/**
	* Atribui valor para customUsers
	* @memberOf fluigAPI
	* @param {List} customUsers 
	*/
	"setCustomUsers": function(customUsers) {}, 
	/**
	* Recupera valor do sociableObjectId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getSociableObjectId": function() {}, 
	/**
	* Atribui valor para sociableObjectId
	* @memberOf fluigAPI
	* @param {long} sociableObjectId 
	*/
	"setSociableObjectId": function(sociableObjectId) {}, 
	/**
	* Recupera o valor do
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.social.MediaVO} 
	*/
	"getMediaVO": function() {}, 
	/**
	* * Atribui valor para mediaVO
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.MediaVO} mediaVO 
	*/
	"setMediaVO": function(mediaVO) {}
};
PostVO.prototype = {
	/**
	* Recupera valor do id
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* Atribui valor para id
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* Recupera valor do text
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getText": function() {}, 
	/**
	* Atribui valor para text
	* @memberOf fluigAPI
	* @param {String} text 
	*/
	"setText": function(text) {}, 
	/**
	* Recupera valor do visibility
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVisibility": function() {}, 
	/**
	* Atribui valor para visibility
	* @memberOf fluigAPI
	* @param {String} visibility 
	*/
	"setVisibility": function(visibility) {}, 
	/**
	* Recupera valor do alias
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAlias": function() {}, 
	/**
	* Atribui valor para alias
	* @memberOf fluigAPI
	* @param {String} alias 
	*/
	"setAlias": function(alias) {}, 
	/**
	* Recupera valor do customUsers
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getCustomUsers": function() {}, 
	/**
	* Atribui valor para customUsers
	* @memberOf fluigAPI
	* @param {List} customUsers 
	*/
	"setCustomUsers": function(customUsers) {}, 
	/**
	* Recupera valor do sociableObjectId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getSociableObjectId": function() {}, 
	/**
	* Atribui valor para sociableObjectId
	* @memberOf fluigAPI
	* @param {long} sociableObjectId 
	*/
	"setSociableObjectId": function(sociableObjectId) {}, 
	/**
	* Recupera o valor do
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.social.MediaVO} 
	*/
	"getMediaVO": function() {}, 
	/**
	* * Atribui valor para mediaVO
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.MediaVO} mediaVO 
	*/
	"setMediaVO": function(mediaVO) {}
};
com.fluig.sdk.api.social.ArticleVO.prototype = {
	/**
	* Recupera o valor do field id
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* Setado o valor do field id
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* Recupera o valor do field categoryId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCategoryId": function() {}, 
	/**
	* Setado o valor do field categoryId
	* @memberOf fluigAPI
	* @param {long} categoryId 
	*/
	"setCategoryId": function(categoryId) {}, 
	/**
	* Recupera o valor do field alias
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAlias": function() {}, 
	/**
	* Setado o valor do field alias
	* @memberOf fluigAPI
	* @param {String} alias 
	*/
	"setAlias": function(alias) {}, 
	/**
	* Recupera o valor do field content
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getContent": function() {}, 
	/**
	* Setado o valor do field content
	* @memberOf fluigAPI
	* @param {String} content 
	*/
	"setContent": function(content) {}, 
	/**
	* Recupera o valor do field topicId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTopicId": function() {}, 
	/**
	* Setado o valor do field topicId
	* @memberOf fluigAPI
	* @param {int} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* Recupera o valor do field draft
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isDraft": function() {}, 
	/**
	* Setado o valor do field draft
	* @memberOf fluigAPI
	* @param {boolean} draft 
	*/
	"setDraft": function(draft) {}, 
	/**
	* Recupera o valor do field keyWord
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getKeyWord": function() {}, 
	/**
	* Setado o valor do field keyWord
	* @memberOf fluigAPI
	* @param {String} keyWord 
	*/
	"setKeyWord": function(keyWord) {}, 
	/**
	* Recupera o valor do field expires
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isExpires": function() {}, 
	/**
	* Setado o valor do field expires
	* @memberOf fluigAPI
	* @param {boolean} expires 
	*/
	"setExpires": function(expires) {}, 
	/**
	* Recupera o valor do field description
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* Setado o valor do field description
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* Recupera o valor do field version
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* Setado o valor do field version
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* Recupera o valor do field publicationDate
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getPublicationDate": function() {}, 
	/**
	* Setado o valor do field publicationDate
	* @memberOf fluigAPI
	* @param {Date} publicationDate 
	*/
	"setPublicationDate": function(publicationDate) {}, 
	/**
	* Recupera o valor do field expirationDate
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getExpirationDate": function() {}, 
	/**
	* Setado o valor do field expirationDate
	* @memberOf fluigAPI
	* @param {Date} expirationDate 
	*/
	"setExpirationDate": function(expirationDate) {}, 
	/**
	* Recupera o valor do field publisherId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPublisherId": function() {}, 
	/**
	* Setado o valor do field publisherId
	* @memberOf fluigAPI
	* @param {String} publisherId 
	*/
	"setPublisherId": function(publisherId) {}, 
	/**
	* Recupera o valor do field attachments
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getAttachments": function() {}, 
	/**
	* Setado o valor do field attachments
	* @memberOf fluigAPI
	* @param {List} attachments 
	*/
	"setAttachments": function(attachments) {}, 
	/**
	* Recupera o valor do field covers
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getCovers": function() {}, 
	/**
	* Setado o valor do field covers
	* @memberOf fluigAPI
	* @param {Map} covers 
	*/
	"setCovers": function(covers) {}, 
	/**
	* Recupera o valor do field user
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.social.SocialVO} 
	*/
	"getUser": function() {}, 
	/**
	* Setado o valor do field user
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.SocialVO} user 
	*/
	"setUser": function(user) {}, 
	/**
	* Recupera o valor do field articleCoverVO
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.social.ArticleCoverVO} 
	*/
	"getArticleCoverVO": function() {}, 
	/**
	* Setado o valor do field articleCoverVO
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.ArticleCoverVO} articleCoverVO 
	*/
	"setArticleCoverVO": function(articleCoverVO) {}, 
	/**
	* Recupera o valor do field userNotify
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isUserNotify": function() {}, 
	/**
	* Setado o valor do field userNotify
	* @memberOf fluigAPI
	* @param {boolean} userNotify 
	*/
	"setUserNotify": function(userNotify) {}, 
	/**
	* Recupera o valor do field socialObjectId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getSocialObjectId": function() {}, 
	/**
	* Setado o valor do field socialObjectId
	* @memberOf fluigAPI
	* @param {long} socialObjectId 
	*/
	"setSocialObjectId": function(socialObjectId) {}, 
	/**
	* Recupera o valor do field sociableVO
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.social.SociableVO} 
	*/
	"getSociable": function() {}, 
	/**
	* Setado o valor do field sociableVO
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.SociableVO} sociable 
	*/
	"setSociable": function(sociable) {}, 
	/**
	* Recupera valor do campo viewedDocument
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isViewedDocument": function() {}, 
	/**
	* Atribui valor do campo viewedDocument
	* @memberOf fluigAPI
	* @param {boolean} viewedDocument 
	*/
	"setViewedDocument": function(viewedDocument) {}, 
	/**
	* Recupera valor do campo securityLevel
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSecurityLevel": function() {}, 
	/**
	* Atribui valor do campo securityLevel
	* @memberOf fluigAPI
	* @param {String} securityLevel 
	*/
	"setSecurityLevel": function(securityLevel) {}, 
	/**
	* Recupera valor do campo accessCount
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getAccessCount": function() {}, 
	/**
	* Atribui valor do campo accessCount
	* @memberOf fluigAPI
	* @param {int} accessCount 
	*/
	"setAccessCount": function(accessCount) {}, 
	/**
	* Recupera valor do campo numberWatchs
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getNumberWatchs": function() {}, 
	/**
	* Atribui valor do campo numberWatchs
	* @memberOf fluigAPI
	* @param {long} numberWatchs 
	*/
	"setNumberWatchs": function(numberWatchs) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  obj 
	* @returns {boolean} 
	*/
	"equals": function(obj) {}
};
ArticleVO.prototype = {
	/**
	* Recupera o valor do field id
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* Setado o valor do field id
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* Recupera o valor do field categoryId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCategoryId": function() {}, 
	/**
	* Setado o valor do field categoryId
	* @memberOf fluigAPI
	* @param {long} categoryId 
	*/
	"setCategoryId": function(categoryId) {}, 
	/**
	* Recupera o valor do field alias
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAlias": function() {}, 
	/**
	* Setado o valor do field alias
	* @memberOf fluigAPI
	* @param {String} alias 
	*/
	"setAlias": function(alias) {}, 
	/**
	* Recupera o valor do field content
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getContent": function() {}, 
	/**
	* Setado o valor do field content
	* @memberOf fluigAPI
	* @param {String} content 
	*/
	"setContent": function(content) {}, 
	/**
	* Recupera o valor do field topicId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTopicId": function() {}, 
	/**
	* Setado o valor do field topicId
	* @memberOf fluigAPI
	* @param {int} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* Recupera o valor do field draft
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isDraft": function() {}, 
	/**
	* Setado o valor do field draft
	* @memberOf fluigAPI
	* @param {boolean} draft 
	*/
	"setDraft": function(draft) {}, 
	/**
	* Recupera o valor do field keyWord
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getKeyWord": function() {}, 
	/**
	* Setado o valor do field keyWord
	* @memberOf fluigAPI
	* @param {String} keyWord 
	*/
	"setKeyWord": function(keyWord) {}, 
	/**
	* Recupera o valor do field expires
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isExpires": function() {}, 
	/**
	* Setado o valor do field expires
	* @memberOf fluigAPI
	* @param {boolean} expires 
	*/
	"setExpires": function(expires) {}, 
	/**
	* Recupera o valor do field description
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* Setado o valor do field description
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* Recupera o valor do field version
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* Setado o valor do field version
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* Recupera o valor do field publicationDate
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getPublicationDate": function() {}, 
	/**
	* Setado o valor do field publicationDate
	* @memberOf fluigAPI
	* @param {Date} publicationDate 
	*/
	"setPublicationDate": function(publicationDate) {}, 
	/**
	* Recupera o valor do field expirationDate
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getExpirationDate": function() {}, 
	/**
	* Setado o valor do field expirationDate
	* @memberOf fluigAPI
	* @param {Date} expirationDate 
	*/
	"setExpirationDate": function(expirationDate) {}, 
	/**
	* Recupera o valor do field publisherId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPublisherId": function() {}, 
	/**
	* Setado o valor do field publisherId
	* @memberOf fluigAPI
	* @param {String} publisherId 
	*/
	"setPublisherId": function(publisherId) {}, 
	/**
	* Recupera o valor do field attachments
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getAttachments": function() {}, 
	/**
	* Setado o valor do field attachments
	* @memberOf fluigAPI
	* @param {List} attachments 
	*/
	"setAttachments": function(attachments) {}, 
	/**
	* Recupera o valor do field covers
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getCovers": function() {}, 
	/**
	* Setado o valor do field covers
	* @memberOf fluigAPI
	* @param {Map} covers 
	*/
	"setCovers": function(covers) {}, 
	/**
	* Recupera o valor do field user
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.social.SocialVO} 
	*/
	"getUser": function() {}, 
	/**
	* Setado o valor do field user
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.SocialVO} user 
	*/
	"setUser": function(user) {}, 
	/**
	* Recupera o valor do field articleCoverVO
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.social.ArticleCoverVO} 
	*/
	"getArticleCoverVO": function() {}, 
	/**
	* Setado o valor do field articleCoverVO
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.ArticleCoverVO} articleCoverVO 
	*/
	"setArticleCoverVO": function(articleCoverVO) {}, 
	/**
	* Recupera o valor do field userNotify
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isUserNotify": function() {}, 
	/**
	* Setado o valor do field userNotify
	* @memberOf fluigAPI
	* @param {boolean} userNotify 
	*/
	"setUserNotify": function(userNotify) {}, 
	/**
	* Recupera o valor do field socialObjectId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getSocialObjectId": function() {}, 
	/**
	* Setado o valor do field socialObjectId
	* @memberOf fluigAPI
	* @param {long} socialObjectId 
	*/
	"setSocialObjectId": function(socialObjectId) {}, 
	/**
	* Recupera o valor do field sociableVO
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.social.SociableVO} 
	*/
	"getSociable": function() {}, 
	/**
	* Setado o valor do field sociableVO
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.SociableVO} sociable 
	*/
	"setSociable": function(sociable) {}, 
	/**
	* Recupera valor do campo viewedDocument
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isViewedDocument": function() {}, 
	/**
	* Atribui valor do campo viewedDocument
	* @memberOf fluigAPI
	* @param {boolean} viewedDocument 
	*/
	"setViewedDocument": function(viewedDocument) {}, 
	/**
	* Recupera valor do campo securityLevel
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSecurityLevel": function() {}, 
	/**
	* Atribui valor do campo securityLevel
	* @memberOf fluigAPI
	* @param {String} securityLevel 
	*/
	"setSecurityLevel": function(securityLevel) {}, 
	/**
	* Recupera valor do campo accessCount
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getAccessCount": function() {}, 
	/**
	* Atribui valor do campo accessCount
	* @memberOf fluigAPI
	* @param {int} accessCount 
	*/
	"setAccessCount": function(accessCount) {}, 
	/**
	* Recupera valor do campo numberWatchs
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getNumberWatchs": function() {}, 
	/**
	* Atribui valor do campo numberWatchs
	* @memberOf fluigAPI
	* @param {long} numberWatchs 
	*/
	"setNumberWatchs": function(numberWatchs) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  obj 
	* @returns {boolean} 
	*/
	"equals": function(obj) {}
};
com.fluig.sdk.api.social.SocialBreadcrumbVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.social.SocialBreadcrumbItemVO&gt;} 
	*/
	"getItems": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} items 
	*/
	"setItems": function(items) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} map 
	*/
	"setMap": function(map) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getMap": function() {}
};
SocialBreadcrumbVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.social.SocialBreadcrumbItemVO&gt;} 
	*/
	"getItems": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} items 
	*/
	"setItems": function(items) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} map 
	*/
	"setMap": function(map) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getMap": function() {}
};
com.fluig.sdk.api.social.CommunityVO.prototype = {
	/**
	* Recupera valor do id
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* Atribui valor para id
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* Recupera valor do alias
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAlias": function() {}, 
	/**
	* Atribui valor para alias
	* @memberOf fluigAPI
	* @param {String} alias 
	*/
	"setAlias": function(alias) {}, 
	/**
	* Recupera valor do name
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* Atribui valor para name
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* Recupera valor do description
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* Atribui valor para description
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* Recupera valor do adminAlias
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAdminAlias": function() {}, 
	/**
	* Atribui valor para adminAlias
	* @memberOf fluigAPI
	* @param {String} adminAlias 
	*/
	"setAdminAlias": function(adminAlias) {}, 
	/**
	* Recupera valor do hidden
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getHidden": function() {}, 
	/**
	* Atribui valor para hidden
	* @memberOf fluigAPI
	* @param {boolean} hidden 
	*/
	"setHidden": function(hidden) {}, 
	/**
	* Recupera valor do privateContent
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getPrivateContent": function() {}, 
	/**
	* Atribui valor para privateContent
	* @memberOf fluigAPI
	* @param {boolean} privateContent 
	*/
	"setPrivateContent": function(privateContent) {}, 
	/**
	* Recupera valor do approvalRequired
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getApprovalRequired": function() {}, 
	/**
	* Atribui valor para approvalRequired
	* @memberOf fluigAPI
	* @param {boolean} approvalRequired 
	*/
	"setApprovalRequired": function(approvalRequired) {}, 
	/**
	* Recupera valor do ecmInfo
	* @memberOf fluigAPI
	* @returns {Map&lt;String,&gt;} 
	*/
	"getEcmInfo": function() {}, 
	/**
	* Atribui valor para ecmInfo
	* @memberOf fluigAPI
	* @param {Map} ecmInfo 
	*/
	"setEcmInfo": function(ecmInfo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getCreateForum": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} createForum 
	*/
	"setCreateForum": function(createForum) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
CommunityVO.prototype = {
	/**
	* Recupera valor do id
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* Atribui valor para id
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* Recupera valor do alias
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAlias": function() {}, 
	/**
	* Atribui valor para alias
	* @memberOf fluigAPI
	* @param {String} alias 
	*/
	"setAlias": function(alias) {}, 
	/**
	* Recupera valor do name
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* Atribui valor para name
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* Recupera valor do description
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* Atribui valor para description
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* Recupera valor do adminAlias
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAdminAlias": function() {}, 
	/**
	* Atribui valor para adminAlias
	* @memberOf fluigAPI
	* @param {String} adminAlias 
	*/
	"setAdminAlias": function(adminAlias) {}, 
	/**
	* Recupera valor do hidden
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getHidden": function() {}, 
	/**
	* Atribui valor para hidden
	* @memberOf fluigAPI
	* @param {boolean} hidden 
	*/
	"setHidden": function(hidden) {}, 
	/**
	* Recupera valor do privateContent
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getPrivateContent": function() {}, 
	/**
	* Atribui valor para privateContent
	* @memberOf fluigAPI
	* @param {boolean} privateContent 
	*/
	"setPrivateContent": function(privateContent) {}, 
	/**
	* Recupera valor do approvalRequired
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getApprovalRequired": function() {}, 
	/**
	* Atribui valor para approvalRequired
	* @memberOf fluigAPI
	* @param {boolean} approvalRequired 
	*/
	"setApprovalRequired": function(approvalRequired) {}, 
	/**
	* Recupera valor do ecmInfo
	* @memberOf fluigAPI
	* @returns {Map&lt;String,&gt;} 
	*/
	"getEcmInfo": function() {}, 
	/**
	* Atribui valor para ecmInfo
	* @memberOf fluigAPI
	* @param {Map} ecmInfo 
	*/
	"setEcmInfo": function(ecmInfo) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getCreateForum": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} createForum 
	*/
	"setCreateForum": function(createForum) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.workflow.ProcessDefinitionVersionVO.prototype = {
	/**
	* Recupera valor do tenantId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* Atribui valor para tenantId
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* Recupera valor do processId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* Atribui valor para processId
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* Recupera valor do version
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* Atribui valor para version
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* Recupera valor do versionDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVersionDescription": function() {}, 
	/**
	* Atribui valor para versionDescription
	* @memberOf fluigAPI
	* @param {String} versionDescription 
	*/
	"setVersionDescription": function(versionDescription) {}, 
	/**
	* Recupera valor do categoryStructure
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCategoryStructure": function() {}, 
	/**
	* Atribui valor para categoryStructure
	* @memberOf fluigAPI
	* @param {String} categoryStructure 
	*/
	"setCategoryStructure": function(categoryStructure) {}, 
	/**
	* Atribui valor para fullCategoryStructure
	* @memberOf fluigAPI
	* @param {String} fullCategoryStructure 
	*/
	"setFullCategoryStructure": function(fullCategoryStructure) {}, 
	/**
	* Recupera valor do fullCategoryStructure
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFullCategoryStructure": function() {}, 
	/**
	* Recupera valor do processDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessDescription": function() {}, 
	/**
	* Atribui valor para processDescription
	* @memberOf fluigAPI
	* @param {String} processDescription 
	*/
	"setProcessDescription": function(processDescription) {}, 
	/**
	* Recupera valor do rowId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getRowId": function() {}, 
	/**
	* Atribui valor para rowId
	* @memberOf fluigAPI
	* @param {int} rowId 
	*/
	"setRowId": function(rowId) {}, 
	/**
	* Favorito?
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isFavorite": function() {}, 
	/**
	* Atribui valor para favorite
	* @memberOf fluigAPI
	* @param {boolean} favorite 
	*/
	"setFavorite": function(favorite) {}, 
	/**
	* Mobile?
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isMobileReady": function() {}, 
	/**
	* Atribui valor para mobileReady
	* @memberOf fluigAPI
	* @param {boolean} mobileReady 
	*/
	"setMobileReady": function(mobileReady) {}, 
	/**
	* Recupera valor do formId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getFormId": function() {}, 
	/**
	* Atribui valor para formId
	* @memberOf fluigAPI
	* @param {int} formId 
	*/
	"setFormId": function(formId) {}, 
	/**
	* Recupera valor do initialProcessState
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.workflow.ProcessStateVO} 
	*/
	"getInitialProcessState": function() {}, 
	/**
	* Atribui valor para initialProcessState
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.ProcessStateVO} initialProcessState 
	*/
	"setInitialProcessState": function(initialProcessState) {}, 
	/**
	* Recupera valor do formVersion
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getFormVersion": function() {}, 
	/**
	* Atribui valor para formVersion
	* @memberOf fluigAPI
	* @param {int} formVersion 
	*/
	"setFormVersion": function(formVersion) {}
};
ProcessDefinitionVersionVO.prototype = {
	/**
	* Recupera valor do tenantId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* Atribui valor para tenantId
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* Recupera valor do processId
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* Atribui valor para processId
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* Recupera valor do version
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* Atribui valor para version
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* Recupera valor do versionDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVersionDescription": function() {}, 
	/**
	* Atribui valor para versionDescription
	* @memberOf fluigAPI
	* @param {String} versionDescription 
	*/
	"setVersionDescription": function(versionDescription) {}, 
	/**
	* Recupera valor do categoryStructure
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCategoryStructure": function() {}, 
	/**
	* Atribui valor para categoryStructure
	* @memberOf fluigAPI
	* @param {String} categoryStructure 
	*/
	"setCategoryStructure": function(categoryStructure) {}, 
	/**
	* Atribui valor para fullCategoryStructure
	* @memberOf fluigAPI
	* @param {String} fullCategoryStructure 
	*/
	"setFullCategoryStructure": function(fullCategoryStructure) {}, 
	/**
	* Recupera valor do fullCategoryStructure
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFullCategoryStructure": function() {}, 
	/**
	* Recupera valor do processDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessDescription": function() {}, 
	/**
	* Atribui valor para processDescription
	* @memberOf fluigAPI
	* @param {String} processDescription 
	*/
	"setProcessDescription": function(processDescription) {}, 
	/**
	* Recupera valor do rowId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getRowId": function() {}, 
	/**
	* Atribui valor para rowId
	* @memberOf fluigAPI
	* @param {int} rowId 
	*/
	"setRowId": function(rowId) {}, 
	/**
	* Favorito?
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isFavorite": function() {}, 
	/**
	* Atribui valor para favorite
	* @memberOf fluigAPI
	* @param {boolean} favorite 
	*/
	"setFavorite": function(favorite) {}, 
	/**
	* Mobile?
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isMobileReady": function() {}, 
	/**
	* Atribui valor para mobileReady
	* @memberOf fluigAPI
	* @param {boolean} mobileReady 
	*/
	"setMobileReady": function(mobileReady) {}, 
	/**
	* Recupera valor do formId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getFormId": function() {}, 
	/**
	* Atribui valor para formId
	* @memberOf fluigAPI
	* @param {int} formId 
	*/
	"setFormId": function(formId) {}, 
	/**
	* Recupera valor do initialProcessState
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.workflow.ProcessStateVO} 
	*/
	"getInitialProcessState": function() {}, 
	/**
	* Atribui valor para initialProcessState
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.ProcessStateVO} initialProcessState 
	*/
	"setInitialProcessState": function(initialProcessState) {}, 
	/**
	* Recupera valor do formVersion
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getFormVersion": function() {}, 
	/**
	* Atribui valor para formVersion
	* @memberOf fluigAPI
	* @param {int} formVersion 
	*/
	"setFormVersion": function(formVersion) {}
};
com.fluig.sdk.api.workflow.WorkflowVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processDescription 
	*/
	"setProcessDescription": function(processDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequesterId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requesterId 
	*/
	"setRequesterId": function(requesterId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequesterName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requesterName 
	*/
	"setRequesterName": function(requesterName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getActive": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} active 
	*/
	"setActive": function(active) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getAttachmentSeqId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} attachmentSeqId 
	*/
	"setAttachmentSeqId": function(attachmentSeqId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSourceProcess": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} sourceProcess 
	*/
	"setSourceProcess": function(sourceProcess) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSourceThreadSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} sourceThreadSequence 
	*/
	"setSourceThreadSequence": function(sourceThreadSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getStateId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} stateId 
	*/
	"setStateId": function(stateId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStateDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} stateDescription 
	*/
	"setStateDescription": function(stateDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDeadlineDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} deadlineDate 
	*/
	"setDeadlineDate": function(deadlineDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDeadlineText": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} deadlineText 
	*/
	"setDeadlineText": function(deadlineText) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} documentDescription 
	*/
	"setDocumentDescription": function(documentDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueName 
	*/
	"setColleagueName": function(colleagueName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} movementSequence 
	*/
	"setMovementSequence": function(movementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMainAttachmentDocumentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} mainAttachmentDocumentId 
	*/
	"setMainAttachmentDocumentId": function(mainAttachmentDocumentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMainAttachmentDocumentVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} mainAttachmentDocumentVersion 
	*/
	"setMainAttachmentDocumentVersion": function(mainAttachmentDocumentVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getRowId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} rowId 
	*/
	"setRowId": function(rowId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMovementHour": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} movementHour 
	*/
	"setMovementHour": function(movementHour) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getMobileReady": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} mobileReady 
	*/
	"setMobileReady": function(mobileReady) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getCanCancel": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} canCancel 
	*/
	"setCanCancel": function(canCancel) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getCanTake": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} canTake 
	*/
	"setCanTake": function(canTake) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUrl": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} url 
	*/
	"setUrl": function(url) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}
};
WorkflowVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processDescription 
	*/
	"setProcessDescription": function(processDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getProcessInstanceId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} processInstanceId 
	*/
	"setProcessInstanceId": function(processInstanceId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequesterId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requesterId 
	*/
	"setRequesterId": function(requesterId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequesterName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requesterName 
	*/
	"setRequesterName": function(requesterName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getActive": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} active 
	*/
	"setActive": function(active) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getAttachmentSeqId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} attachmentSeqId 
	*/
	"setAttachmentSeqId": function(attachmentSeqId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSourceProcess": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} sourceProcess 
	*/
	"setSourceProcess": function(sourceProcess) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSourceThreadSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} sourceThreadSequence 
	*/
	"setSourceThreadSequence": function(sourceThreadSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getStateId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} stateId 
	*/
	"setStateId": function(stateId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStateDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} stateDescription 
	*/
	"setStateDescription": function(stateDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDeadlineDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} deadlineDate 
	*/
	"setDeadlineDate": function(deadlineDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDeadlineText": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} deadlineText 
	*/
	"setDeadlineText": function(deadlineText) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} documentDescription 
	*/
	"setDocumentDescription": function(documentDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueName 
	*/
	"setColleagueName": function(colleagueName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} movementSequence 
	*/
	"setMovementSequence": function(movementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMainAttachmentDocumentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} mainAttachmentDocumentId 
	*/
	"setMainAttachmentDocumentId": function(mainAttachmentDocumentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMainAttachmentDocumentVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} mainAttachmentDocumentVersion 
	*/
	"setMainAttachmentDocumentVersion": function(mainAttachmentDocumentVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getRowId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} rowId 
	*/
	"setRowId": function(rowId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMovementHour": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} movementHour 
	*/
	"setMovementHour": function(movementHour) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getMobileReady": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} mobileReady 
	*/
	"setMobileReady": function(mobileReady) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getCanCancel": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} canCancel 
	*/
	"setCanCancel": function(canCancel) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getCanTake": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} canTake 
	*/
	"setCanTake": function(canTake) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUrl": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} url 
	*/
	"setUrl": function(url) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}
};
com.fluig.sdk.api.document.DocumentTaskVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} documentDescription 
	*/
	"setDocumentDescription": function(documentDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueName 
	*/
	"setColleagueName": function(colleagueName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPublisherName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} publisherName 
	*/
	"setPublisherName": function(publisherName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getLastModifiedDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} lastModifiedDate 
	*/
	"setLastModifiedDate": function(lastModifiedDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} documentType 
	*/
	"setDocumentType": function(documentType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getApproved": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} approved 
	*/
	"setApproved": function(approved) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getApprovedString": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} approvedString 
	*/
	"setApprovedString": function(approvedString) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isKnow": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} isKnow 
	*/
	"setIsKnow": function(isKnow) {}
};
DocumentTaskVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} documentDescription 
	*/
	"setDocumentDescription": function(documentDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueName 
	*/
	"setColleagueName": function(colleagueName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPublisherName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} publisherName 
	*/
	"setPublisherName": function(publisherName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getLastModifiedDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} lastModifiedDate 
	*/
	"setLastModifiedDate": function(lastModifiedDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDocumentType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} documentType 
	*/
	"setDocumentType": function(documentType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getApproved": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} approved 
	*/
	"setApproved": function(approved) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getApprovedString": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} approvedString 
	*/
	"setApprovedString": function(approvedString) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isKnow": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} isKnow 
	*/
	"setIsKnow": function(isKnow) {}
};
com.fluig.sdk.api.task.TaskKindEnum.prototype = {
	/**
	* Returns an array containing the constants of this enum type, inthe order they are declared.  This method may be used to iterateover the constants as follows:<pre>for (TaskKindEnum c : TaskKindEnum.values())&nbsp;   System.out.println(c);</pre>
	* @memberOf fluigAPI
	*/
	"values": function() {}, 
	/**
	* Returns the enum constant of this type with the specified name.The string must match <i>exactly</i> an identifier used to declare anenum constant in this type.  (Extraneous whitespace characters are not permitted.)
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"valueOf": function(name) {}
};
TaskKindEnum.prototype = {
	/**
	* Returns an array containing the constants of this enum type, inthe order they are declared.  This method may be used to iterateover the constants as follows:<pre>for (TaskKindEnum c : TaskKindEnum.values())&nbsp;   System.out.println(c);</pre>
	* @memberOf fluigAPI
	*/
	"values": function() {}, 
	/**
	* Returns the enum constant of this type with the specified name.The string must match <i>exactly</i> an identifier used to declare anenum constant in this type.  (Extraneous whitespace characters are not permitted.)
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"valueOf": function(name) {}
};
com.fluig.sdk.api.task.TaskStatusEnum.prototype = {
	/**
	* Returns an array containing the constants of this enum type, inthe order they are declared.  This method may be used to iterateover the constants as follows:<pre>for (TaskStatusEnum c : TaskStatusEnum.values())&nbsp;   System.out.println(c);</pre>
	* @memberOf fluigAPI
	*/
	"values": function() {}, 
	/**
	* Returns the enum constant of this type with the specified name.The string must match <i>exactly</i> an identifier used to declare anenum constant in this type.  (Extraneous whitespace characters are not permitted.)
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"valueOf": function(name) {}
};
TaskStatusEnum.prototype = {
	/**
	* Returns an array containing the constants of this enum type, inthe order they are declared.  This method may be used to iterateover the constants as follows:<pre>for (TaskStatusEnum c : TaskStatusEnum.values())&nbsp;   System.out.println(c);</pre>
	* @memberOf fluigAPI
	*/
	"values": function() {}, 
	/**
	* Returns the enum constant of this type with the specified name.The string must match <i>exactly</i> an identifier used to declare anenum constant in this type.  (Extraneous whitespace characters are not permitted.)
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"valueOf": function(name) {}
};
com.fluig.sdk.api.task.ResumedTasksVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} type 
	*/
	"setType": function(type) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTaskId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} taskId 
	*/
	"setTaskId": function(taskId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getState": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} state 
	*/
	"setState": function(state) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCustomURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} customURL 
	*/
	"setCustomURL": function(customURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTotalTask": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} totalTask 
	*/
	"setTotalTask": function(totalTask) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.task.ResumedTasksVO&gt;} 
	*/
	"getChildren": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} children 
	*/
	"setChildren": function(children) {}
};
ResumedTasksVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} type 
	*/
	"setType": function(type) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTaskId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} taskId 
	*/
	"setTaskId": function(taskId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getState": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} state 
	*/
	"setState": function(state) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCustomURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} customURL 
	*/
	"setCustomURL": function(customURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTotalTask": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} totalTask 
	*/
	"setTotalTask": function(totalTask) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.task.ResumedTasksVO&gt;} 
	*/
	"getChildren": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} children 
	*/
	"setChildren": function(children) {}
};
com.fluig.sdk.api.ecm.CollaborationAppVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getJndiName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} jndiName 
	*/
	"setJndiName": function(jndiName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getClientId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} clientId 
	*/
	"setClientId": function(clientId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getClientSecret": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} clientSecret 
	*/
	"setClientSecret": function(clientSecret) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEnabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} enabled 
	*/
	"setEnabled": function(enabled) {}
};
CollaborationAppVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getJndiName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} jndiName 
	*/
	"setJndiName": function(jndiName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getClientId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} clientId 
	*/
	"setClientId": function(clientId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getClientSecret": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} clientSecret 
	*/
	"setClientSecret": function(clientSecret) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEnabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} enabled 
	*/
	"setEnabled": function(enabled) {}
};
com.fluig.sdk.api.ecm.CollaborationVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getGuests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} guests 
	*/
	"setGuests": function(guests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCollaborationId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} collaborationId 
	*/
	"setCollaborationId": function(collaborationId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getOauthCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} oauthCode 
	*/
	"setOauthCode": function(oauthCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getEndDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} endDate 
	*/
	"setEndDate": function(endDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getStartDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} startDate 
	*/
	"setStartDate": function(startDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUploaderLogin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} uploaderLogin 
	*/
	"setUploaderLogin": function(uploaderLogin) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} documentVersion 
	*/
	"setDocumentVersion": function(documentVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSourceDocumentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} sourceDocumentId 
	*/
	"setSourceDocumentId": function(sourceDocumentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSourceDocumentVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} sourceDocumentVersion 
	*/
	"setSourceDocumentVersion": function(sourceDocumentVersion) {}
};
CollaborationVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getGuests": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} guests 
	*/
	"setGuests": function(guests) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCollaborationId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} collaborationId 
	*/
	"setCollaborationId": function(collaborationId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getOauthCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} oauthCode 
	*/
	"setOauthCode": function(oauthCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getEndDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} endDate 
	*/
	"setEndDate": function(endDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getStartDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} startDate 
	*/
	"setStartDate": function(startDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUploaderLogin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} uploaderLogin 
	*/
	"setUploaderLogin": function(uploaderLogin) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} documentVersion 
	*/
	"setDocumentVersion": function(documentVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSourceDocumentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} sourceDocumentId 
	*/
	"setSourceDocumentId": function(sourceDocumentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSourceDocumentVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} sourceDocumentVersion 
	*/
	"setSourceDocumentVersion": function(sourceDocumentVersion) {}
};
com.fluig.sdk.identity.UserAuthTokenSessionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserIdIdp": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} userIdIdp 
	*/
	"setUserIdIdp": function(userIdIdp) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAccessToken": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} accessToken 
	*/
	"setAccessToken": function(accessToken) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRefreshToken": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} refreshToken 
	*/
	"setRefreshToken": function(refreshToken) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getIssuedTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} issuedTime 
	*/
	"setIssuedTime": function(issuedTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getExpiresIn": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} expiresIn 
	*/
	"setExpiresIn": function(expiresIn) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getSerialversionuid": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getSession": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  session 
	*/
	"setSession": function(session) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDomain": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} domain 
	*/
	"setDomain": function(domain) {}
};
UserAuthTokenSessionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserIdIdp": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} userIdIdp 
	*/
	"setUserIdIdp": function(userIdIdp) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAccessToken": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} accessToken 
	*/
	"setAccessToken": function(accessToken) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRefreshToken": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} refreshToken 
	*/
	"setRefreshToken": function(refreshToken) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getIssuedTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} issuedTime 
	*/
	"setIssuedTime": function(issuedTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getExpiresIn": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} expiresIn 
	*/
	"setExpiresIn": function(expiresIn) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getSerialversionuid": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getSession": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  session 
	*/
	"setSession": function(session) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDomain": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} domain 
	*/
	"setDomain": function(domain) {}
};
com.fluig.sdk.api.alert.AlertVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.alert.AlertSenderVO&gt;} 
	*/
	"getSenders": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} senders 
	*/
	"setSenders": function(senders) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.alert.AlertUserVO} 
	*/
	"getReceiver": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.alert.AlertUserVO} receiver 
	*/
	"setReceiver": function(receiver) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.alert.AlertEventVO} 
	*/
	"getEvent": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.alert.AlertEventVO} event 
	*/
	"setEvent": function(event) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.alert.AlertObjectVO} 
	*/
	"getObject": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.alert.AlertObjectVO} object 
	*/
	"setObject": function(object) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.alert.AlertObjectVO} 
	*/
	"getPlace": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.alert.AlertObjectVO} place 
	*/
	"setPlace": function(place) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getRead": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} read 
	*/
	"setRead": function(read) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCreationDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} creationDate 
	*/
	"setCreationDate": function(creationDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.alert.AlertActionVO&gt;} 
	*/
	"getActions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} actions 
	*/
	"setActions": function(actions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCurrentDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} currentDate 
	*/
	"setCurrentDate": function(currentDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getCanRemove": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} canRemove 
	*/
	"setCanRemove": function(canRemove) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPriority": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} priority 
	*/
	"setPriority": function(priority) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCreationDateTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} creationDateTime 
	*/
	"setCreationDateTime": function(creationDateTime) {}
};
AlertVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.alert.AlertSenderVO&gt;} 
	*/
	"getSenders": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} senders 
	*/
	"setSenders": function(senders) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.alert.AlertUserVO} 
	*/
	"getReceiver": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.alert.AlertUserVO} receiver 
	*/
	"setReceiver": function(receiver) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.alert.AlertEventVO} 
	*/
	"getEvent": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.alert.AlertEventVO} event 
	*/
	"setEvent": function(event) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.alert.AlertObjectVO} 
	*/
	"getObject": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.alert.AlertObjectVO} object 
	*/
	"setObject": function(object) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.alert.AlertObjectVO} 
	*/
	"getPlace": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.alert.AlertObjectVO} place 
	*/
	"setPlace": function(place) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getRead": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} read 
	*/
	"setRead": function(read) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCreationDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} creationDate 
	*/
	"setCreationDate": function(creationDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.alert.AlertActionVO&gt;} 
	*/
	"getActions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} actions 
	*/
	"setActions": function(actions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCurrentDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} currentDate 
	*/
	"setCurrentDate": function(currentDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getCanRemove": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} canRemove 
	*/
	"setCanRemove": function(canRemove) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPriority": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} priority 
	*/
	"setPriority": function(priority) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCreationDateTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} creationDateTime 
	*/
	"setCreationDateTime": function(creationDateTime) {}
};
com.fluig.sdk.api.alert.AlertConfigVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLogin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} login 
	*/
	"setLogin": function(login) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEventKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} eventKey 
	*/
	"setEventKey": function(eventKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getApplicationKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} applicationKey 
	*/
	"setApplicationKey": function(applicationKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getWantReceive": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} wantReceive 
	*/
	"setWantReceive": function(wantReceive) {}
};
AlertConfigVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLogin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} login 
	*/
	"setLogin": function(login) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEventKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} eventKey 
	*/
	"setEventKey": function(eventKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getApplicationKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} applicationKey 
	*/
	"setApplicationKey": function(applicationKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getWantReceive": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} wantReceive 
	*/
	"setWantReceive": function(wantReceive) {}
};
com.fluig.sdk.api.authorizeclient.AuthorizeClientSdkServiceVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getResult": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} result 
	*/
	"setResult": function(result) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getServiceCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} serviceCode 
	*/
	"setServiceCode": function(serviceCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMethod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} method 
	*/
	"setMethod": function(method) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,&gt;} 
	*/
	"getParams": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} params 
	*/
	"setParams": function(params) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStrParams": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} strParams 
	*/
	"setStrParams": function(strParams) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEndpoint": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} endpoint 
	*/
	"setEndpoint": function(endpoint) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,&gt;} 
	*/
	"getOptions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} options 
	*/
	"setOptions": function(options) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  obj 
	* @returns {boolean} 
	*/
	"equals": function(obj) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTimeoutService": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} timeoutService 
	*/
	"setTimeoutService": function(timeoutService) {}
};
AuthorizeClientSdkServiceVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getResult": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} result 
	*/
	"setResult": function(result) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getServiceCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} serviceCode 
	*/
	"setServiceCode": function(serviceCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMethod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} method 
	*/
	"setMethod": function(method) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,&gt;} 
	*/
	"getParams": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} params 
	*/
	"setParams": function(params) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStrParams": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} strParams 
	*/
	"setStrParams": function(strParams) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEndpoint": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} endpoint 
	*/
	"setEndpoint": function(endpoint) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,&gt;} 
	*/
	"getOptions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} options 
	*/
	"setOptions": function(options) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  obj 
	* @returns {boolean} 
	*/
	"equals": function(obj) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTimeoutService": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} timeoutService 
	*/
	"setTimeoutService": function(timeoutService) {}
};
com.fluig.sdk.api.oauth.OAuthSdkVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAccessTokenURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} accessTokenURL 
	*/
	"setAccessTokenURL": function(accessTokenURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequestMethod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requestMethod 
	*/
	"setRequestMethod": function(requestMethod) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSignatureMethod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} signatureMethod 
	*/
	"setSignatureMethod": function(signatureMethod) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getConsumerKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} consumerKey 
	*/
	"setConsumerKey": function(consumerKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getConsumerSecret": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} consumerSecret 
	*/
	"setConsumerSecret": function(consumerSecret) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequestTokenURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requestTokenURL 
	*/
	"setRequestTokenURL": function(requestTokenURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserAuthorizationURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} userAuthorizationURL 
	*/
	"setUserAuthorizationURL": function(userAuthorizationURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getToken": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} token 
	*/
	"setToken": function(token) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTokenAccess": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tokenAccess 
	*/
	"setTokenAccess": function(tokenAccess) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTokenSecret": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tokenSecret 
	*/
	"setTokenSecret": function(tokenSecret) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthorizationURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} authorizationURL 
	*/
	"setAuthorizationURL": function(authorizationURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCreationDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} creationDate 
	*/
	"setCreationDate": function(creationDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getExpirationDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} expirationDate 
	*/
	"setExpirationDate": function(expirationDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getClientData": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} clientData 
	*/
	"setClientData": function(clientData) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProviderName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} providerName 
	*/
	"setProviderName": function(providerName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCallbackUrl": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} callbackUrl 
	*/
	"setCallbackUrl": function(callbackUrl) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getGrantType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} grantType 
	*/
	"setGrantType": function(grantType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getClientId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} clientId 
	*/
	"setClientId": function(clientId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRedirectUri": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} redirectUri 
	*/
	"setRedirectUri": function(redirectUri) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUsername": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} username 
	*/
	"setUsername": function(username) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPassword": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} password 
	*/
	"setPassword": function(password) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthenticationType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} authenticationType 
	*/
	"setAuthenticationType": function(authenticationType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getServiceTestUrl": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} serviceTestUrl 
	*/
	"setServiceTestUrl": function(serviceTestUrl) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getServiceUrl": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} serviceUrl 
	*/
	"setServiceUrl": function(serviceUrl) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDomain": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} domain 
	*/
	"setDomain": function(domain) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getClientSecret": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} clientSecret 
	*/
	"setClientSecret": function(clientSecret) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRefreshToken": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} refreshToken 
	*/
	"setRefreshToken": function(refreshToken) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMethod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} method 
	*/
	"setMethod": function(method) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,&gt;} 
	*/
	"getParams": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} param 
	*/
	"setParams": function(param) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStrParams": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} strParams 
	*/
	"setStrParams": function(strParams) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getScope": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} scope 
	*/
	"setScope": function(scope) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPasswordConfirmation": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} passwordConfirmation 
	*/
	"setPasswordConfirmation": function(passwordConfirmation) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRefreshTokenURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} refreshTokenURL 
	*/
	"setRefreshTokenURL": function(refreshTokenURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
OAuthSdkVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAccessTokenURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} accessTokenURL 
	*/
	"setAccessTokenURL": function(accessTokenURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequestMethod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requestMethod 
	*/
	"setRequestMethod": function(requestMethod) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSignatureMethod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} signatureMethod 
	*/
	"setSignatureMethod": function(signatureMethod) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getConsumerKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} consumerKey 
	*/
	"setConsumerKey": function(consumerKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getConsumerSecret": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} consumerSecret 
	*/
	"setConsumerSecret": function(consumerSecret) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRequestTokenURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} requestTokenURL 
	*/
	"setRequestTokenURL": function(requestTokenURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserAuthorizationURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} userAuthorizationURL 
	*/
	"setUserAuthorizationURL": function(userAuthorizationURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getToken": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} token 
	*/
	"setToken": function(token) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTokenAccess": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tokenAccess 
	*/
	"setTokenAccess": function(tokenAccess) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTokenSecret": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tokenSecret 
	*/
	"setTokenSecret": function(tokenSecret) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthorizationURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} authorizationURL 
	*/
	"setAuthorizationURL": function(authorizationURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCreationDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} creationDate 
	*/
	"setCreationDate": function(creationDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getExpirationDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} expirationDate 
	*/
	"setExpirationDate": function(expirationDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getClientData": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} clientData 
	*/
	"setClientData": function(clientData) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProviderName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} providerName 
	*/
	"setProviderName": function(providerName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCallbackUrl": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} callbackUrl 
	*/
	"setCallbackUrl": function(callbackUrl) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getGrantType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} grantType 
	*/
	"setGrantType": function(grantType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getClientId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} clientId 
	*/
	"setClientId": function(clientId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRedirectUri": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} redirectUri 
	*/
	"setRedirectUri": function(redirectUri) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUsername": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} username 
	*/
	"setUsername": function(username) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPassword": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} password 
	*/
	"setPassword": function(password) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthenticationType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} authenticationType 
	*/
	"setAuthenticationType": function(authenticationType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getServiceTestUrl": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} serviceTestUrl 
	*/
	"setServiceTestUrl": function(serviceTestUrl) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getServiceUrl": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} serviceUrl 
	*/
	"setServiceUrl": function(serviceUrl) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDomain": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} domain 
	*/
	"setDomain": function(domain) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getClientSecret": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} clientSecret 
	*/
	"setClientSecret": function(clientSecret) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRefreshToken": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} refreshToken 
	*/
	"setRefreshToken": function(refreshToken) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMethod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} method 
	*/
	"setMethod": function(method) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,&gt;} 
	*/
	"getParams": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} param 
	*/
	"setParams": function(param) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStrParams": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} strParams 
	*/
	"setStrParams": function(strParams) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getScope": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} scope 
	*/
	"setScope": function(scope) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPasswordConfirmation": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} passwordConfirmation 
	*/
	"setPasswordConfirmation": function(passwordConfirmation) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRefreshTokenURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} refreshTokenURL 
	*/
	"setRefreshTokenURL": function(refreshTokenURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.social.CommentVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getSociableId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} sociableId 
	*/
	"setSociableId": function(sociableId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getComment": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} comment 
	*/
	"setComment": function(comment) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCreationDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} creationDate 
	*/
	"setCreationDate": function(creationDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getUpdateDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} updateDate 
	*/
	"setUpdateDate": function(updateDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCommentWithoutMention": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} commentWithoutMention 
	*/
	"setCommentWithoutMention": function(commentWithoutMention) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isMention": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} mention 
	*/
	"setMention": function(mention) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getMentions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} mentions 
	*/
	"setMentions": function(mentions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getCustomData": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} customData 
	*/
	"setCustomData": function(customData) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} userName 
	*/
	"setUserName": function(userName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserAlias": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} userAlias 
	*/
	"setUserAlias": function(userAlias) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getSociableParentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} sociableParentId 
	*/
	"setSociableParentId": function(sociableParentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  obj 
	* @returns {boolean} 
	*/
	"equals": function(obj) {}
};
CommentVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getSociableId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} sociableId 
	*/
	"setSociableId": function(sociableId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getComment": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} comment 
	*/
	"setComment": function(comment) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCreationDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} creationDate 
	*/
	"setCreationDate": function(creationDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getUpdateDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} updateDate 
	*/
	"setUpdateDate": function(updateDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCommentWithoutMention": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} commentWithoutMention 
	*/
	"setCommentWithoutMention": function(commentWithoutMention) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isMention": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} mention 
	*/
	"setMention": function(mention) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getMentions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} mentions 
	*/
	"setMentions": function(mentions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getCustomData": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} customData 
	*/
	"setCustomData": function(customData) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} userName 
	*/
	"setUserName": function(userName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserAlias": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} userAlias 
	*/
	"setUserAlias": function(userAlias) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getSociableParentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} sociableParentId 
	*/
	"setSociableParentId": function(sociableParentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  obj 
	* @returns {boolean} 
	*/
	"equals": function(obj) {}
};
com.fluig.sdk.api.search.DefaultSearchResponse.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTimeElapsed": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} timeElapsed 
	*/
	"setTimeElapsed": function(timeElapsed) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTotalHits": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} totalHits 
	*/
	"setTotalHits": function(totalHits) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOffset": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} offset 
	*/
	"setOffset": function(offset) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isSolrAvailable": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} solrAvailable 
	*/
	"setSolrAvailable": function(solrAvailable) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;Map,String,&gt;} 
	*/
	"getItems": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} items 
	*/
	"setItems": function(items) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
DefaultSearchResponse.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTimeElapsed": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} timeElapsed 
	*/
	"setTimeElapsed": function(timeElapsed) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTotalHits": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} totalHits 
	*/
	"setTotalHits": function(totalHits) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOffset": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} offset 
	*/
	"setOffset": function(offset) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isSolrAvailable": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} solrAvailable 
	*/
	"setSolrAvailable": function(solrAvailable) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;Map,String,&gt;} 
	*/
	"getItems": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} items 
	*/
	"setItems": function(items) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.search.DefaultSearchRequest.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSearchType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} searchType 
	*/
	"setSearchType": function(searchType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPattern": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pattern 
	*/
	"setPattern": function(pattern) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getStartPeriod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} startPeriod 
	*/
	"setStartPeriod": function(startPeriod) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getEndPeriod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} endPeriod 
	*/
	"setEndPeriod": function(endPeriod) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getPeriod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  period 
	*/
	"setPeriod": function(period) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getOrdering": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} ordering 
	*/
	"setOrdering": function(ordering) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getLimit": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} limit 
	*/
	"setLimit": function(limit) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOffset": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} offset 
	*/
	"setOffset": function(offset) {}
};
DefaultSearchRequest.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSearchType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} searchType 
	*/
	"setSearchType": function(searchType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPattern": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pattern 
	*/
	"setPattern": function(pattern) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getStartPeriod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} startPeriod 
	*/
	"setStartPeriod": function(startPeriod) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getEndPeriod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} endPeriod 
	*/
	"setEndPeriod": function(endPeriod) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getPeriod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  period 
	*/
	"setPeriod": function(period) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getOrdering": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} ordering 
	*/
	"setOrdering": function(ordering) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getLimit": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} limit 
	*/
	"setLimit": function(limit) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOffset": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} offset 
	*/
	"setOffset": function(offset) {}
};
com.fluig.sdk.api.social.SocialVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAlias": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} alias 
	*/
	"setAlias": function(alias) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberFriends": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberFriends 
	*/
	"setNumberFriends": function(numberFriends) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberParticipations": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberParticipations 
	*/
	"setNumberParticipations": function(numberParticipations) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberFollowing": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberFollowing 
	*/
	"setNumberFollowing": function(numberFollowing) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberFollowers": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberFollowers 
	*/
	"setNumberFollowers": function(numberFollowers) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberModerations": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberModerations 
	*/
	"setNumberModerations": function(numberModerations) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isHidden": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} hidden 
	*/
	"setHidden": function(hidden) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isPrivateContent": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} privateContent 
	*/
	"setPrivateContent": function(privateContent) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isApprovalRequired": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} approvalRequired 
	*/
	"setApprovalRequired": function(approvalRequired) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIsModerator": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} isModerator 
	*/
	"setIsModerator": function(isModerator) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIsAdmin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} isAdmin 
	*/
	"setIsAdmin": function(isAdmin) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIsCommunityAdmin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} isCommunityAdmin 
	*/
	"setIsCommunityAdmin": function(isCommunityAdmin) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getLastUpdate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} lastUpdate 
	*/
	"setLastUpdate": function(lastUpdate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCreateDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} createDate 
	*/
	"setCreateDate": function(createDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getCustomPage": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} customPage 
	*/
	"setCustomPage": function(customPage) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getFavorite": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} favorite 
	*/
	"setFavorite": function(favorite) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isTenantAdmin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} tenantAdmin 
	*/
	"setTenantAdmin": function(tenantAdmin) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getUserData": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} userData 
	*/
	"setUserData": function(userData) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEmail": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} email 
	*/
	"setEmail": function(email) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLastName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFullName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} lastName 
	*/
	"setLastName": function(lastName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} fullName 
	*/
	"setFullName": function(fullName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  obj 
	* @returns {boolean} 
	*/
	"equals": function(obj) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
SocialVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAlias": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} alias 
	*/
	"setAlias": function(alias) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberFriends": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberFriends 
	*/
	"setNumberFriends": function(numberFriends) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberParticipations": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberParticipations 
	*/
	"setNumberParticipations": function(numberParticipations) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberFollowing": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberFollowing 
	*/
	"setNumberFollowing": function(numberFollowing) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberFollowers": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberFollowers 
	*/
	"setNumberFollowers": function(numberFollowers) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberModerations": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberModerations 
	*/
	"setNumberModerations": function(numberModerations) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isHidden": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} hidden 
	*/
	"setHidden": function(hidden) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isPrivateContent": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} privateContent 
	*/
	"setPrivateContent": function(privateContent) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isApprovalRequired": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} approvalRequired 
	*/
	"setApprovalRequired": function(approvalRequired) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIsModerator": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} isModerator 
	*/
	"setIsModerator": function(isModerator) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIsAdmin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} isAdmin 
	*/
	"setIsAdmin": function(isAdmin) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIsCommunityAdmin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} isCommunityAdmin 
	*/
	"setIsCommunityAdmin": function(isCommunityAdmin) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getLastUpdate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} lastUpdate 
	*/
	"setLastUpdate": function(lastUpdate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCreateDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} createDate 
	*/
	"setCreateDate": function(createDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getCustomPage": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} customPage 
	*/
	"setCustomPage": function(customPage) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getFavorite": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} favorite 
	*/
	"setFavorite": function(favorite) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isTenantAdmin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} tenantAdmin 
	*/
	"setTenantAdmin": function(tenantAdmin) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getUserData": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} userData 
	*/
	"setUserData": function(userData) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEmail": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} email 
	*/
	"setEmail": function(email) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLastName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFullName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} lastName 
	*/
	"setLastName": function(lastName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} fullName 
	*/
	"setFullName": function(fullName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  obj 
	* @returns {boolean} 
	*/
	"equals": function(obj) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.lms.ContentVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isPrivateContent": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} privateContent 
	*/
	"setPrivateContent": function(privateContent) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFileName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} fileName 
	*/
	"setFileName": function(fileName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getScormType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} scormType 
	*/
	"setScormType": function(scormType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getKeyword": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} keyword 
	*/
	"setKeyword": function(keyword) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getElucidatReleasePackageId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} elucidatReleasePackageId 
	*/
	"setElucidatReleasePackageId": function(elucidatReleasePackageId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} changeFile 
	*/
	"setChangeFile": function(changeFile) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isChangeFile": function() {}
};
ContentVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isPrivateContent": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} privateContent 
	*/
	"setPrivateContent": function(privateContent) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFileName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} fileName 
	*/
	"setFileName": function(fileName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getScormType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} scormType 
	*/
	"setScormType": function(scormType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getKeyword": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} keyword 
	*/
	"setKeyword": function(keyword) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getElucidatReleasePackageId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} elucidatReleasePackageId 
	*/
	"setElucidatReleasePackageId": function(elucidatReleasePackageId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} changeFile 
	*/
	"setChangeFile": function(changeFile) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isChangeFile": function() {}
};
com.fluig.sdk.api.lms.AssessmentApplicationFinishedVO.prototype = {
	/**
	* Finished assessment application ID
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentApplicationFinishedVO.html#getId--"><code>getId()</code></a>
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* URL do review the finished assessment application
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getReviewUrl": function() {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentApplicationFinishedVO.html#setReviewUrl-java.lang.String-"><code>setReviewUrl(String)</code></a>
	* @memberOf fluigAPI
	* @param {String} reviewUrl 
	*/
	"setReviewUrl": function(reviewUrl) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
AssessmentApplicationFinishedVO.prototype = {
	/**
	* Finished assessment application ID
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentApplicationFinishedVO.html#getId--"><code>getId()</code></a>
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* URL do review the finished assessment application
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getReviewUrl": function() {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentApplicationFinishedVO.html#setReviewUrl-java.lang.String-"><code>setReviewUrl(String)</code></a>
	* @memberOf fluigAPI
	* @param {String} reviewUrl 
	*/
	"setReviewUrl": function(reviewUrl) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.lms.AssessmentScheduleVO.prototype = {
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleVO.html#setUserId-java.lang.Long-"><code>setUserId(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getUserId": function() {}, 
	/**
	* Contém o valor de fluigUserId Na API pública não é recomendado expor a palavra "fluig"
	* @memberOf fluigAPI
	* @param {long} userId 
	*/
	"setUserId": function(userId) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleVO.html#setAssessmentVersionId-java.lang.Long-"><code>setAssessmentVersionId(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getAssessmentVersionId": function() {}, 
	/**
	* ID da versão da avaliação
	* @memberOf fluigAPI
	* @param {long} assessmentVersionId 
	*/
	"setAssessmentVersionId": function(assessmentVersionId) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleVO.html#setDateToExecuteBegin-java.util.Date-"><code>setDateToExecuteBegin(Date)</code></a>
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDateToExecuteBegin": function() {}, 
	/**
	* Data inicial para execução da Avaliação
	* @memberOf fluigAPI
	* @param {Date} dateToExecuteBegin 
	*/
	"setDateToExecuteBegin": function(dateToExecuteBegin) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleVO.html#setDateToExecuteEnd-java.util.Date-"><code>setDateToExecuteEnd(Date)</code></a>
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDateToExecuteEnd": function() {}, 
	/**
	* Data final para execução da Avaliação
	* @memberOf fluigAPI
	* @param {Date} dateToExecuteEnd 
	*/
	"setDateToExecuteEnd": function(dateToExecuteEnd) {}, 
	/**
	* $<a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleVO.html#setDescription-java.lang.String-"><code>setDescription(String)</code></a>
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* Descrição
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
AssessmentScheduleVO.prototype = {
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleVO.html#setUserId-java.lang.Long-"><code>setUserId(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getUserId": function() {}, 
	/**
	* Contém o valor de fluigUserId Na API pública não é recomendado expor a palavra "fluig"
	* @memberOf fluigAPI
	* @param {long} userId 
	*/
	"setUserId": function(userId) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleVO.html#setAssessmentVersionId-java.lang.Long-"><code>setAssessmentVersionId(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getAssessmentVersionId": function() {}, 
	/**
	* ID da versão da avaliação
	* @memberOf fluigAPI
	* @param {long} assessmentVersionId 
	*/
	"setAssessmentVersionId": function(assessmentVersionId) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleVO.html#setDateToExecuteBegin-java.util.Date-"><code>setDateToExecuteBegin(Date)</code></a>
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDateToExecuteBegin": function() {}, 
	/**
	* Data inicial para execução da Avaliação
	* @memberOf fluigAPI
	* @param {Date} dateToExecuteBegin 
	*/
	"setDateToExecuteBegin": function(dateToExecuteBegin) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleVO.html#setDateToExecuteEnd-java.util.Date-"><code>setDateToExecuteEnd(Date)</code></a>
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDateToExecuteEnd": function() {}, 
	/**
	* Data final para execução da Avaliação
	* @memberOf fluigAPI
	* @param {Date} dateToExecuteEnd 
	*/
	"setDateToExecuteEnd": function(dateToExecuteEnd) {}, 
	/**
	* $<a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleVO.html#setDescription-java.lang.String-"><code>setDescription(String)</code></a>
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* Descrição
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.lms.AssessmentScheduleEmailVO.prototype = {
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleEmailVO.html#setEmails-java.util.List-"><code>setEmails(List)</code></a>
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getEmails": function() {}, 
	/**
	* Emails a receberem o agendamento da avaliação
	* @memberOf fluigAPI
	* @param {List} emails 
	*/
	"setEmails": function(emails) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleEmailVO.html#setAssessmentVersionId-java.lang.Long-"><code>setAssessmentVersionId(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getAssessmentVersionId": function() {}, 
	/**
	* ID da versão da avaliação
	* @memberOf fluigAPI
	* @param {long} assessmentVersionId 
	*/
	"setAssessmentVersionId": function(assessmentVersionId) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleEmailVO.html#setDateToExecuteBegin-java.util.Date-"><code>setDateToExecuteBegin(Date)</code></a>
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDateToExecuteBegin": function() {}, 
	/**
	* Data inicial para execução da Avaliação
	* @memberOf fluigAPI
	* @param {Date} dateToExecuteBegin 
	*/
	"setDateToExecuteBegin": function(dateToExecuteBegin) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleEmailVO.html#setDateToExecuteEnd-java.util.Date-"><code>setDateToExecuteEnd(Date)</code></a>
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDateToExecuteEnd": function() {}, 
	/**
	* Data final para execução da Avaliação
	* @memberOf fluigAPI
	* @param {Date} dateToExecuteEnd 
	*/
	"setDateToExecuteEnd": function(dateToExecuteEnd) {}, 
	/**
	* $<a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleEmailVO.html#setDescription-java.lang.String-"><code>setDescription(String)</code></a>
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* Descrição
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
AssessmentScheduleEmailVO.prototype = {
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleEmailVO.html#setEmails-java.util.List-"><code>setEmails(List)</code></a>
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getEmails": function() {}, 
	/**
	* Emails a receberem o agendamento da avaliação
	* @memberOf fluigAPI
	* @param {List} emails 
	*/
	"setEmails": function(emails) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleEmailVO.html#setAssessmentVersionId-java.lang.Long-"><code>setAssessmentVersionId(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getAssessmentVersionId": function() {}, 
	/**
	* ID da versão da avaliação
	* @memberOf fluigAPI
	* @param {long} assessmentVersionId 
	*/
	"setAssessmentVersionId": function(assessmentVersionId) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleEmailVO.html#setDateToExecuteBegin-java.util.Date-"><code>setDateToExecuteBegin(Date)</code></a>
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDateToExecuteBegin": function() {}, 
	/**
	* Data inicial para execução da Avaliação
	* @memberOf fluigAPI
	* @param {Date} dateToExecuteBegin 
	*/
	"setDateToExecuteBegin": function(dateToExecuteBegin) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleEmailVO.html#setDateToExecuteEnd-java.util.Date-"><code>setDateToExecuteEnd(Date)</code></a>
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDateToExecuteEnd": function() {}, 
	/**
	* Data final para execução da Avaliação
	* @memberOf fluigAPI
	* @param {Date} dateToExecuteEnd 
	*/
	"setDateToExecuteEnd": function(dateToExecuteEnd) {}, 
	/**
	* $<a href="../../../../../com/fluig/sdk/api/lms/AssessmentScheduleEmailVO.html#setDescription-java.lang.String-"><code>setDescription(String)</code></a>
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* Descrição
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.lms.DisciplineVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getBibliography": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} bibliography 
	*/
	"setBibliography": function(bibliography) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEmenta": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} ementa 
	*/
	"setEmenta": function(ementa) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMethodology": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} methodology 
	*/
	"setMethodology": function(methodology) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObjective": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} objective 
	*/
	"setObjective": function(objective) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getScoreApprove": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  scoreApprove 
	*/
	"setScoreApprove": function(scoreApprove) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWorkload": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} workload 
	*/
	"setWorkload": function(workload) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCoordinatorId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} coordinatorId 
	*/
	"setCoordinatorId": function(coordinatorId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFolderId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} folderId 
	*/
	"setFolderId": function(folderId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getDisciplineId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} disciplineId 
	*/
	"setDisciplineId": function(disciplineId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getUseCommunity": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} useCommunity 
	*/
	"setUseCommunity": function(useCommunity) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getResponsiblesPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} responsiblesPermissions 
	*/
	"setResponsiblesPermissions": function(responsiblesPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getEnrollableItemRequirementsIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} enrollableItemRequirementsIds 
	*/
	"setEnrollableItemRequirementsIds": function(enrollableItemRequirementsIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getDisciplineRequirementsIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} disciplineRequirementsIds 
	*/
	"setDisciplineRequirementsIds": function(disciplineRequirementsIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getDisciplineSkills": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  disciplineSkills 
	*/
	"setDisciplineSkills": function(disciplineSkills) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCertificateId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} certificateId 
	*/
	"setCertificateId": function(certificateId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getPercentageClass": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  percentageClass 
	*/
	"setPercentageClass": function(percentageClass) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDaysToCertificate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} daysToCertificate 
	*/
	"setDaysToCertificate": function(daysToCertificate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.lms.ImagePropertiesVO} 
	*/
	"getImageProperties": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ImagePropertiesVO} imageProperties 
	*/
	"setImageProperties": function(imageProperties) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCertificateCondition": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} certificateCondition 
	*/
	"setCertificateCondition": function(certificateCondition) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}
};
DisciplineVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getBibliography": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} bibliography 
	*/
	"setBibliography": function(bibliography) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEmenta": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} ementa 
	*/
	"setEmenta": function(ementa) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMethodology": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} methodology 
	*/
	"setMethodology": function(methodology) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObjective": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} objective 
	*/
	"setObjective": function(objective) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getScoreApprove": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  scoreApprove 
	*/
	"setScoreApprove": function(scoreApprove) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWorkload": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} workload 
	*/
	"setWorkload": function(workload) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCoordinatorId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} coordinatorId 
	*/
	"setCoordinatorId": function(coordinatorId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFolderId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} folderId 
	*/
	"setFolderId": function(folderId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getDisciplineId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} disciplineId 
	*/
	"setDisciplineId": function(disciplineId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getUseCommunity": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} useCommunity 
	*/
	"setUseCommunity": function(useCommunity) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getResponsiblesPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} responsiblesPermissions 
	*/
	"setResponsiblesPermissions": function(responsiblesPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getEnrollableItemRequirementsIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} enrollableItemRequirementsIds 
	*/
	"setEnrollableItemRequirementsIds": function(enrollableItemRequirementsIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getDisciplineRequirementsIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} disciplineRequirementsIds 
	*/
	"setDisciplineRequirementsIds": function(disciplineRequirementsIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getDisciplineSkills": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  disciplineSkills 
	*/
	"setDisciplineSkills": function(disciplineSkills) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCertificateId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} certificateId 
	*/
	"setCertificateId": function(certificateId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getPercentageClass": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  percentageClass 
	*/
	"setPercentageClass": function(percentageClass) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDaysToCertificate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} daysToCertificate 
	*/
	"setDaysToCertificate": function(daysToCertificate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.lms.ImagePropertiesVO} 
	*/
	"getImageProperties": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ImagePropertiesVO} imageProperties 
	*/
	"setImageProperties": function(imageProperties) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCertificateCondition": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} certificateCondition 
	*/
	"setCertificateCondition": function(certificateCondition) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}
};
com.fluig.sdk.api.lms.EnrollmentRequestVO.prototype = {
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/EnrollmentRequestVO.html#setUserId-java.lang.Long-"><code>setUserId(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getUserId": function() {}, 
	/**
	* Contém o valor de fluigUserId Na API pública não é recomendado expor a palavra "fluig"
	* @memberOf fluigAPI
	* @param {long} userId 
	*/
	"setUserId": function(userId) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/EnrollmentRequestVO.html#setLearningId-java.lang.Long-"><code>setLearningId(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getLearningId": function() {}, 
	/**
	* ID do treinamento, trilha ou turma que o usuário deseja matricular
	* @memberOf fluigAPI
	* @param {long} learningId 
	*/
	"setLearningId": function(learningId) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/EnrollmentRequestVO.html#setIdEnrollmentRequest-java.lang.Long-"><code>setIdEnrollmentRequest(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getIdEnrollmentRequest": function() {}, 
	/**
	* ID da Requisição de matrícula
	* @memberOf fluigAPI
	* @param {long} idEnrollmentRequest 
	*/
	"setIdEnrollmentRequest": function(idEnrollmentRequest) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/EnrollmentRequestVO.html#setIdEnrollment-java.lang.Long-"><code>setIdEnrollment(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getIdEnrollment": function() {}, 
	/**
	* ID da matrícula
	* @memberOf fluigAPI
	* @param {long} idEnrollment 
	*/
	"setIdEnrollment": function(idEnrollment) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
EnrollmentRequestVO.prototype = {
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/EnrollmentRequestVO.html#setUserId-java.lang.Long-"><code>setUserId(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getUserId": function() {}, 
	/**
	* Contém o valor de fluigUserId Na API pública não é recomendado expor a palavra "fluig"
	* @memberOf fluigAPI
	* @param {long} userId 
	*/
	"setUserId": function(userId) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/EnrollmentRequestVO.html#setLearningId-java.lang.Long-"><code>setLearningId(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getLearningId": function() {}, 
	/**
	* ID do treinamento, trilha ou turma que o usuário deseja matricular
	* @memberOf fluigAPI
	* @param {long} learningId 
	*/
	"setLearningId": function(learningId) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/EnrollmentRequestVO.html#setIdEnrollmentRequest-java.lang.Long-"><code>setIdEnrollmentRequest(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getIdEnrollmentRequest": function() {}, 
	/**
	* ID da Requisição de matrícula
	* @memberOf fluigAPI
	* @param {long} idEnrollmentRequest 
	*/
	"setIdEnrollmentRequest": function(idEnrollmentRequest) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/EnrollmentRequestVO.html#setIdEnrollment-java.lang.Long-"><code>setIdEnrollment(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getIdEnrollment": function() {}, 
	/**
	* ID da matrícula
	* @memberOf fluigAPI
	* @param {long} idEnrollment 
	*/
	"setIdEnrollment": function(idEnrollment) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.lms.ReproveRequestVO.prototype = {
	/**
	* Retorna o id da requisição de matrícula
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getRequestId": function() {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/ReproveRequestVO.html#getRequestId--"><code>getRequestId()</code></a>
	* @memberOf fluigAPI
	* @param {long} requestId 
	*/
	"setRequestId": function(requestId) {}, 
	/**
	* Retorna o motivo da rejeição da requisição de matrícula
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRejectionReason": function() {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/ReproveRequestVO.html#getRejectionReason--"><code>getRejectionReason()</code></a>
	* @memberOf fluigAPI
	* @param {String} rejectionReason 
	*/
	"setRejectionReason": function(rejectionReason) {}
};
ReproveRequestVO.prototype = {
	/**
	* Retorna o id da requisição de matrícula
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getRequestId": function() {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/ReproveRequestVO.html#getRequestId--"><code>getRequestId()</code></a>
	* @memberOf fluigAPI
	* @param {long} requestId 
	*/
	"setRequestId": function(requestId) {}, 
	/**
	* Retorna o motivo da rejeição da requisição de matrícula
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getRejectionReason": function() {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/ReproveRequestVO.html#getRejectionReason--"><code>getRejectionReason()</code></a>
	* @memberOf fluigAPI
	* @param {String} rejectionReason 
	*/
	"setRejectionReason": function(rejectionReason) {}
};
com.fluig.sdk.api.lms.EnrolledUsersResponseVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.EnrollUsersLogVO&gt;} 
	*/
	"getSuccessList": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} successList 
	*/
	"setSuccessList": function(successList) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.EnrollUsersLogVO&gt;} 
	*/
	"getFailureList": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} failureList 
	*/
	"setFailureList": function(failureList) {}
};
EnrolledUsersResponseVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.EnrollUsersLogVO&gt;} 
	*/
	"getSuccessList": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} successList 
	*/
	"setSuccessList": function(successList) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.EnrollUsersLogVO&gt;} 
	*/
	"getFailureList": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} failureList 
	*/
	"setFailureList": function(failureList) {}
};
com.fluig.sdk.api.lms.MultipleEnrollmentRequestVO.prototype = {
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/MultipleEnrollmentRequestVO.html#setGroupId-java.lang.Long-"><code>setGroupId(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getGroupId": function() {}, 
	/**
	* Contém o valor de group fluig ID Na API pública não é recomendado expor a palavra "fluig"
	* @memberOf fluigAPI
	* @param {long} groupId 
	*/
	"setGroupId": function(groupId) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/MultipleEnrollmentRequestVO.html#setLearningId-java.lang.Long-"><code>setLearningId(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getLearningId": function() {}, 
	/**
	* ID do treinamento, trilha ou turma que o usuário deseja matricular
	* @memberOf fluigAPI
	* @param {long} learningId 
	*/
	"setLearningId": function(learningId) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/MultipleEnrollmentRequestVO.html#setIdEnrollmentRequest-java.lang.Long-"><code>setIdEnrollmentRequest(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getIdEnrollmentRequest": function() {}, 
	/**
	* ID da Requisição de matrícula
	* @memberOf fluigAPI
	* @param {long} idEnrollmentRequest 
	*/
	"setIdEnrollmentRequest": function(idEnrollmentRequest) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
MultipleEnrollmentRequestVO.prototype = {
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/MultipleEnrollmentRequestVO.html#setGroupId-java.lang.Long-"><code>setGroupId(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getGroupId": function() {}, 
	/**
	* Contém o valor de group fluig ID Na API pública não é recomendado expor a palavra "fluig"
	* @memberOf fluigAPI
	* @param {long} groupId 
	*/
	"setGroupId": function(groupId) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/MultipleEnrollmentRequestVO.html#setLearningId-java.lang.Long-"><code>setLearningId(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getLearningId": function() {}, 
	/**
	* ID do treinamento, trilha ou turma que o usuário deseja matricular
	* @memberOf fluigAPI
	* @param {long} learningId 
	*/
	"setLearningId": function(learningId) {}, 
	/**
	* <a href="../../../../../com/fluig/sdk/api/lms/MultipleEnrollmentRequestVO.html#setIdEnrollmentRequest-java.lang.Long-"><code>setIdEnrollmentRequest(Long)</code></a>
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getIdEnrollmentRequest": function() {}, 
	/**
	* ID da Requisição de matrícula
	* @memberOf fluigAPI
	* @param {long} idEnrollmentRequest 
	*/
	"setIdEnrollmentRequest": function(idEnrollmentRequest) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.lms.EnrollmentHistoryVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getEnrollId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} enrollId 
	*/
	"setEnrollId": function(enrollId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUsername": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} username 
	*/
	"setUsername": function(username) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getLearningId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} learningId 
	*/
	"setLearningId": function(learningId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getScore": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  score 
	*/
	"setScore": function(score) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFinalStatus": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} finalStatus 
	*/
	"setFinalStatus": function(finalStatus) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDateEnroll": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} dateEnroll 
	*/
	"setDateEnroll": function(dateEnroll) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDateConclusion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} dateConclusion 
	*/
	"setDateConclusion": function(dateConclusion) {}
};
EnrollmentHistoryVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getEnrollId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} enrollId 
	*/
	"setEnrollId": function(enrollId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUsername": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} username 
	*/
	"setUsername": function(username) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getLearningId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} learningId 
	*/
	"setLearningId": function(learningId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getScore": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  score 
	*/
	"setScore": function(score) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFinalStatus": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} finalStatus 
	*/
	"setFinalStatus": function(finalStatus) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDateEnroll": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} dateEnroll 
	*/
	"setDateEnroll": function(dateEnroll) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDateConclusion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} dateConclusion 
	*/
	"setDateConclusion": function(dateConclusion) {}
};
com.fluig.sdk.api.lms.FolderDisciplineVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getParentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} parentId 
	*/
	"setParentId": function(parentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}
};
FolderDisciplineVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getParentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} parentId 
	*/
	"setParentId": function(parentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}
};
com.fluig.sdk.api.lms.NormalClassVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getResponsiblesPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} responsiblesPermissions 
	*/
	"setResponsiblesPermissions": function(responsiblesPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getEnrollmentFinalDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} enrollmentFinalDate 
	*/
	"setEnrollmentFinalDate": function(enrollmentFinalDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getEnrollmentInitialDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} enrollmentInitialDate 
	*/
	"setEnrollmentInitialDate": function(enrollmentInitialDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getClassFinalDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} classFinalDate 
	*/
	"setClassFinalDate": function(classFinalDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getClassInitialDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} classInitialDate 
	*/
	"setClassInitialDate": function(classInitialDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getCost": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} cost 
	*/
	"setCost": function(cost) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVacancies": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} vacancies 
	*/
	"setVacancies": function(vacancies) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getValidityDays": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} validityDays 
	*/
	"setValidityDays": function(validityDays) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getWaitingListActive": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} waitingListActive 
	*/
	"setWaitingListActive": function(waitingListActive) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getRequiredReaction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} requiredReaction 
	*/
	"setRequiredReaction": function(requiredReaction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getNoFinishMinimumScore": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} noFinishMinimumScore 
	*/
	"setNoFinishMinimumScore": function(noFinishMinimumScore) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowInactiveItems": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} showInactiveItems 
	*/
	"setShowInactiveItems": function(showInactiveItems) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCoordinatorId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} coordinatorId 
	*/
	"setCoordinatorId": function(coordinatorId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTemplateClassId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} templateClassId 
	*/
	"setTemplateClassId": function(templateClassId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getReactionAssessmentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} reactionAssessmentId 
	*/
	"setReactionAssessmentId": function(reactionAssessmentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getDisciplineId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} disciplineId 
	*/
	"setDisciplineId": function(disciplineId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStartClassType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} startClassType 
	*/
	"setStartClassType": function(startClassType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isUseForum": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} useForum 
	*/
	"setUseForum": function(useForum) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
NormalClassVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getResponsiblesPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} responsiblesPermissions 
	*/
	"setResponsiblesPermissions": function(responsiblesPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getEnrollmentFinalDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} enrollmentFinalDate 
	*/
	"setEnrollmentFinalDate": function(enrollmentFinalDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getEnrollmentInitialDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} enrollmentInitialDate 
	*/
	"setEnrollmentInitialDate": function(enrollmentInitialDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getClassFinalDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} classFinalDate 
	*/
	"setClassFinalDate": function(classFinalDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getClassInitialDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} classInitialDate 
	*/
	"setClassInitialDate": function(classInitialDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getCost": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} cost 
	*/
	"setCost": function(cost) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVacancies": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} vacancies 
	*/
	"setVacancies": function(vacancies) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getValidityDays": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} validityDays 
	*/
	"setValidityDays": function(validityDays) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getWaitingListActive": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} waitingListActive 
	*/
	"setWaitingListActive": function(waitingListActive) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getRequiredReaction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} requiredReaction 
	*/
	"setRequiredReaction": function(requiredReaction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getNoFinishMinimumScore": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} noFinishMinimumScore 
	*/
	"setNoFinishMinimumScore": function(noFinishMinimumScore) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowInactiveItems": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} showInactiveItems 
	*/
	"setShowInactiveItems": function(showInactiveItems) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCoordinatorId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} coordinatorId 
	*/
	"setCoordinatorId": function(coordinatorId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTemplateClassId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} templateClassId 
	*/
	"setTemplateClassId": function(templateClassId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getReactionAssessmentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} reactionAssessmentId 
	*/
	"setReactionAssessmentId": function(reactionAssessmentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getDisciplineId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} disciplineId 
	*/
	"setDisciplineId": function(disciplineId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStartClassType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} startClassType 
	*/
	"setStartClassType": function(startClassType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isUseForum": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} useForum 
	*/
	"setUseForum": function(useForum) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  o 
	* @returns {boolean} 
	*/
	"equals": function(o) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.lms.TrackVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getTrackItemIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} trackItemIds 
	*/
	"setTrackItemIds": function(trackItemIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.TrackItemVO&gt;} 
	*/
	"getTrackItems": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} trackItems 
	*/
	"setTrackItems": function(trackItems) {}
};
TrackVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getTrackItemIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} trackItemIds 
	*/
	"setTrackItemIds": function(trackItemIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.TrackItemVO&gt;} 
	*/
	"getTrackItems": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} trackItems 
	*/
	"setTrackItems": function(trackItems) {}
};
com.fluig.sdk.api.lms.TrainingVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.ContentConfigVO&gt;} 
	*/
	"getContents": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} contents 
	*/
	"setContents": function(contents) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAllowContinue": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} allowContinue 
	*/
	"setAllowContinue": function(allowContinue) {}
};
TrainingVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.ContentConfigVO&gt;} 
	*/
	"getContents": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} contents 
	*/
	"setContents": function(contents) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAllowContinue": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} allowContinue 
	*/
	"setAllowContinue": function(allowContinue) {}
};
com.fluig.sdk.api.lms.SkillVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}
};
SkillVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}
};
com.fluig.sdk.api.lms.FolderVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getParentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} parentId 
	*/
	"setParentId": function(parentId) {}
};
FolderVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getParentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} parentId 
	*/
	"setParentId": function(parentId) {}
};
com.fluig.sdk.api.lms.ObjectiveQuestionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficulty": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficulty 
	*/
	"setDifficulty": function(difficulty) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSource": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} source 
	*/
	"setSource": function(source) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthor": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} author 
	*/
	"setAuthor": function(author) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getShuffle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} shuffle 
	*/
	"setShuffle": function(shuffle) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDropDown": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} dropDown 
	*/
	"setDropDown": function(dropDown) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.AlternativeVO&gt;} 
	*/
	"getAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} alternatives 
	*/
	"setAlternatives": function(alternatives) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} question 
	*/
	"setQuestion": function(question) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disabled 
	*/
	"setDisabled": function(disabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisableHTML": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disableHTML 
	*/
	"setDisableHTML": function(disableHTML) {}
};
ObjectiveQuestionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficulty": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficulty 
	*/
	"setDifficulty": function(difficulty) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSource": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} source 
	*/
	"setSource": function(source) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthor": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} author 
	*/
	"setAuthor": function(author) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getShuffle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} shuffle 
	*/
	"setShuffle": function(shuffle) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDropDown": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} dropDown 
	*/
	"setDropDown": function(dropDown) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.AlternativeVO&gt;} 
	*/
	"getAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} alternatives 
	*/
	"setAlternatives": function(alternatives) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} question 
	*/
	"setQuestion": function(question) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disabled 
	*/
	"setDisabled": function(disabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisableHTML": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disableHTML 
	*/
	"setDisableHTML": function(disableHTML) {}
};
com.fluig.sdk.api.lms.BlockVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.BlockQuestionsFilterVO&gt;} 
	*/
	"getTopicFilters": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} topicFilters 
	*/
	"setTopicFilters": function(topicFilters) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSelectQuestions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} selectQuestions 
	*/
	"setSelectQuestions": function(selectQuestions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getQuestionVersionIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} questionVersionIds 
	*/
	"setQuestionVersionIds": function(questionVersionIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getNumberRandomQuestions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} numberRandomQuestions 
	*/
	"setNumberRandomQuestions": function(numberRandomQuestions) {}
};
BlockVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.BlockQuestionsFilterVO&gt;} 
	*/
	"getTopicFilters": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} topicFilters 
	*/
	"setTopicFilters": function(topicFilters) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSelectQuestions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} selectQuestions 
	*/
	"setSelectQuestions": function(selectQuestions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getQuestionVersionIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} questionVersionIds 
	*/
	"setQuestionVersionIds": function(questionVersionIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getNumberRandomQuestions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} numberRandomQuestions 
	*/
	"setNumberRandomQuestions": function(numberRandomQuestions) {}
};
com.fluig.sdk.api.lms.AssessmentTopicVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getParentItemId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} parentItemId 
	*/
	"setParentItemId": function(parentItemId) {}
};
AssessmentTopicVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getParentItemId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} parentItemId 
	*/
	"setParentItemId": function(parentItemId) {}
};
com.fluig.sdk.api.lms.EssayQuestionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} question 
	*/
	"setQuestion": function(question) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficulty": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficulty 
	*/
	"setDifficulty": function(difficulty) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSource": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} source 
	*/
	"setSource": function(source) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthor": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} author 
	*/
	"setAuthor": function(author) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disabled 
	*/
	"setDisabled": function(disabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisableHTML": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disableHTML 
	*/
	"setDisableHTML": function(disableHTML) {}
};
EssayQuestionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} question 
	*/
	"setQuestion": function(question) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficulty": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficulty 
	*/
	"setDifficulty": function(difficulty) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSource": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} source 
	*/
	"setSource": function(source) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthor": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} author 
	*/
	"setAuthor": function(author) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disabled 
	*/
	"setDisabled": function(disabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisableHTML": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disableHTML 
	*/
	"setDisableHTML": function(disableHTML) {}
};
com.fluig.sdk.api.lms.OrdinationQuestionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} question 
	*/
	"setQuestion": function(question) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficulty": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficulty 
	*/
	"setDifficulty": function(difficulty) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSource": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} source 
	*/
	"setSource": function(source) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthor": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} author 
	*/
	"setAuthor": function(author) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isAssessWhole": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} assessWhole 
	*/
	"setAssessWhole": function(assessWhole) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.AlternativeVO&gt;} 
	*/
	"getAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} alternatives 
	*/
	"setAlternatives": function(alternatives) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disabled 
	*/
	"setDisabled": function(disabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisableHTML": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disableHTML 
	*/
	"setDisableHTML": function(disableHTML) {}
};
OrdinationQuestionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} question 
	*/
	"setQuestion": function(question) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficulty": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficulty 
	*/
	"setDifficulty": function(difficulty) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSource": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} source 
	*/
	"setSource": function(source) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthor": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} author 
	*/
	"setAuthor": function(author) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isAssessWhole": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} assessWhole 
	*/
	"setAssessWhole": function(assessWhole) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.AlternativeVO&gt;} 
	*/
	"getAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} alternatives 
	*/
	"setAlternatives": function(alternatives) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disabled 
	*/
	"setDisabled": function(disabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisableHTML": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disableHTML 
	*/
	"setDisableHTML": function(disableHTML) {}
};
com.fluig.sdk.api.lms.LacunaQuestionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} question 
	*/
	"setQuestion": function(question) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficulty": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficulty 
	*/
	"setDifficulty": function(difficulty) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSource": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} source 
	*/
	"setSource": function(source) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthor": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} author 
	*/
	"setAuthor": function(author) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.LacunaAlternativeVO&gt;} 
	*/
	"getLacunaAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} lacunaAlternatives 
	*/
	"setLacunaAlternatives": function(lacunaAlternatives) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAssessWhole": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} assessWhole 
	*/
	"setAssessWhole": function(assessWhole) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDropDown": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} dropDown 
	*/
	"setDropDown": function(dropDown) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disabled 
	*/
	"setDisabled": function(disabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisableHTML": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disableHTML 
	*/
	"setDisableHTML": function(disableHTML) {}
};
LacunaQuestionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} question 
	*/
	"setQuestion": function(question) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficulty": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficulty 
	*/
	"setDifficulty": function(difficulty) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSource": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} source 
	*/
	"setSource": function(source) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthor": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} author 
	*/
	"setAuthor": function(author) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.LacunaAlternativeVO&gt;} 
	*/
	"getLacunaAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} lacunaAlternatives 
	*/
	"setLacunaAlternatives": function(lacunaAlternatives) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAssessWhole": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} assessWhole 
	*/
	"setAssessWhole": function(assessWhole) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDropDown": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} dropDown 
	*/
	"setDropDown": function(dropDown) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disabled 
	*/
	"setDisabled": function(disabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisableHTML": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disableHTML 
	*/
	"setDisableHTML": function(disableHTML) {}
};
com.fluig.sdk.api.lms.MultipleQuestionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficulty": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficulty 
	*/
	"setDifficulty": function(difficulty) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSource": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} source 
	*/
	"setSource": function(source) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthor": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} author 
	*/
	"setAuthor": function(author) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getShuffle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} shuffle 
	*/
	"setShuffle": function(shuffle) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.AlternativeVO&gt;} 
	*/
	"getAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} alternatives 
	*/
	"setAlternatives": function(alternatives) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} question 
	*/
	"setQuestion": function(question) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isAssessWhole": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} assessWhole 
	*/
	"setAssessWhole": function(assessWhole) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMinAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} minAlternatives 
	*/
	"setMinAlternatives": function(minAlternatives) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMaxAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} maxAlternatives 
	*/
	"setMaxAlternatives": function(maxAlternatives) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disabled 
	*/
	"setDisabled": function(disabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisableHTML": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disableHTML 
	*/
	"setDisableHTML": function(disableHTML) {}
};
MultipleQuestionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficulty": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficulty 
	*/
	"setDifficulty": function(difficulty) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSource": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} source 
	*/
	"setSource": function(source) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthor": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} author 
	*/
	"setAuthor": function(author) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getShuffle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} shuffle 
	*/
	"setShuffle": function(shuffle) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.AlternativeVO&gt;} 
	*/
	"getAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} alternatives 
	*/
	"setAlternatives": function(alternatives) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} question 
	*/
	"setQuestion": function(question) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isAssessWhole": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} assessWhole 
	*/
	"setAssessWhole": function(assessWhole) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMinAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} minAlternatives 
	*/
	"setMinAlternatives": function(minAlternatives) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMaxAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} maxAlternatives 
	*/
	"setMaxAlternatives": function(maxAlternatives) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disabled 
	*/
	"setDisabled": function(disabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisableHTML": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disableHTML 
	*/
	"setDisableHTML": function(disableHTML) {}
};
com.fluig.sdk.api.lms.CorrelationQuestionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficulty": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficulty 
	*/
	"setDifficulty": function(difficulty) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSource": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} source 
	*/
	"setSource": function(source) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthor": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} author 
	*/
	"setAuthor": function(author) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getShuffle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} shuffle 
	*/
	"setShuffle": function(shuffle) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} question 
	*/
	"setQuestion": function(question) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isAssessWhole": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} assessWhole 
	*/
	"setAssessWhole": function(assessWhole) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isCorrelation": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} correlation 
	*/
	"setCorrelation": function(correlation) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.CorrelationAlternativeVO&gt;} 
	*/
	"getAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} alternatives 
	*/
	"setAlternatives": function(alternatives) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disabled 
	*/
	"setDisabled": function(disabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisableHTML": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disableHTML 
	*/
	"setDisableHTML": function(disableHTML) {}
};
CorrelationQuestionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficulty": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficulty 
	*/
	"setDifficulty": function(difficulty) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSource": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} source 
	*/
	"setSource": function(source) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthor": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} author 
	*/
	"setAuthor": function(author) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getShuffle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} shuffle 
	*/
	"setShuffle": function(shuffle) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} question 
	*/
	"setQuestion": function(question) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isAssessWhole": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} assessWhole 
	*/
	"setAssessWhole": function(assessWhole) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isCorrelation": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} correlation 
	*/
	"setCorrelation": function(correlation) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.CorrelationAlternativeVO&gt;} 
	*/
	"getAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} alternatives 
	*/
	"setAlternatives": function(alternatives) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disabled 
	*/
	"setDisabled": function(disabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisableHTML": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disableHTML 
	*/
	"setDisableHTML": function(disableHTML) {}
};
com.fluig.sdk.api.lms.ScaleQuestionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficulty": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficulty 
	*/
	"setDifficulty": function(difficulty) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSource": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} source 
	*/
	"setSource": function(source) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthor": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} author 
	*/
	"setAuthor": function(author) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} question 
	*/
	"setQuestion": function(question) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getInitialValue": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  initialValue 
	*/
	"setInitialValue": function(initialValue) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getFinalValue": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  finalValue 
	*/
	"setFinalValue": function(finalValue) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getScale": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  scale 
	*/
	"setScale": function(scale) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getCorrect": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  correct 
	*/
	"setCorrect": function(correct) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isValueDisplay": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} valueDisplay 
	*/
	"setValueDisplay": function(valueDisplay) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disabled 
	*/
	"setDisabled": function(disabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisableHTML": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disableHTML 
	*/
	"setDisableHTML": function(disableHTML) {}
};
ScaleQuestionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficulty": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficulty 
	*/
	"setDifficulty": function(difficulty) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSource": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} source 
	*/
	"setSource": function(source) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAuthor": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} author 
	*/
	"setAuthor": function(author) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} question 
	*/
	"setQuestion": function(question) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getInitialValue": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  initialValue 
	*/
	"setInitialValue": function(initialValue) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getFinalValue": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  finalValue 
	*/
	"setFinalValue": function(finalValue) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getScale": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  scale 
	*/
	"setScale": function(scale) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getCorrect": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  correct 
	*/
	"setCorrect": function(correct) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isValueDisplay": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} valueDisplay 
	*/
	"setValueDisplay": function(valueDisplay) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disabled 
	*/
	"setDisabled": function(disabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDisableHTML": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} disableHTML 
	*/
	"setDisableHTML": function(disableHTML) {}
};
com.fluig.sdk.api.lms.AssessmentVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getEvaluationMonitored": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} evaluationMonitored 
	*/
	"setEvaluationMonitored": function(evaluationMonitored) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getMonitorsIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} monitorsIds 
	*/
	"setMonitorsIds": function(monitorsIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowScores": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} showScores 
	*/
	"setShowScores": function(showScores) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowApprovalStatus": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} showApprovalStatus 
	*/
	"setShowApprovalStatus": function(showApprovalStatus) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowPerformanceOnQuestions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} showPerformanceOnQuestions 
	*/
	"setShowPerformanceOnQuestions": function(showPerformanceOnQuestions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowCorrectAnswers": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} showCorrectAnswers 
	*/
	"setShowCorrectAnswers": function(showCorrectAnswers) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getSolicitFeedbackEvaluation": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} solicitFeedbackEvaluation 
	*/
	"setSolicitFeedbackEvaluation": function(solicitFeedbackEvaluation) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAllowCommentsOnQuestions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} allowCommentsOnQuestions 
	*/
	"setAllowCommentsOnQuestions": function(allowCommentsOnQuestions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAnonymous": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} anonymous 
	*/
	"setAnonymous": function(anonymous) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowConclusionMessage": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} showConclusionMessage 
	*/
	"setShowConclusionMessage": function(showConclusionMessage) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getConclusionMessage": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} conclusionMessage 
	*/
	"setConclusionMessage": function(conclusionMessage) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getCorrectorsIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} correctorsIds 
	*/
	"setCorrectorsIds": function(correctorsIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getRequiredAllQuestions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} requiredAllQuestions 
	*/
	"setRequiredAllQuestions": function(requiredAllQuestions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getRequiredScore": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  requiredScore 
	*/
	"setRequiredScore": function(requiredScore) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMaxExecutionTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} maxExecutionTime 
	*/
	"setMaxExecutionTime": function(maxExecutionTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMinExecutionTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} minExecutionTime 
	*/
	"setMinExecutionTime": function(minExecutionTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAllowEssayQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} allowEssayQuestion 
	*/
	"setAllowEssayQuestion": function(allowEssayQuestion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getEnabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} enabled 
	*/
	"setEnabled": function(enabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.AssessmentBlockVersionVO&gt;} 
	*/
	"getAssessmentBlockVersions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} assessmentBlockVersions 
	*/
	"setAssessmentBlockVersions": function(assessmentBlockVersions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isKeepExistingAssessmentBlockVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} keepExistingAssessmentBlockVersion 
	*/
	"setKeepExistingAssessmentBlockVersion": function(keepExistingAssessmentBlockVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isAllowRestartAppFromCheckpoint": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} allowRestartAppFromCheckpoint 
	*/
	"setAllowRestartAppFromCheckpoint": function(allowRestartAppFromCheckpoint) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.lms.ImagePropertiesVO} 
	*/
	"getImageProperties": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ImagePropertiesVO} imageProperties 
	*/
	"setImageProperties": function(imageProperties) {}
};
AssessmentVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getEvaluationMonitored": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} evaluationMonitored 
	*/
	"setEvaluationMonitored": function(evaluationMonitored) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getMonitorsIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} monitorsIds 
	*/
	"setMonitorsIds": function(monitorsIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowScores": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} showScores 
	*/
	"setShowScores": function(showScores) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowApprovalStatus": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} showApprovalStatus 
	*/
	"setShowApprovalStatus": function(showApprovalStatus) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowPerformanceOnQuestions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} showPerformanceOnQuestions 
	*/
	"setShowPerformanceOnQuestions": function(showPerformanceOnQuestions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowCorrectAnswers": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} showCorrectAnswers 
	*/
	"setShowCorrectAnswers": function(showCorrectAnswers) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getSolicitFeedbackEvaluation": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} solicitFeedbackEvaluation 
	*/
	"setSolicitFeedbackEvaluation": function(solicitFeedbackEvaluation) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAllowCommentsOnQuestions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} allowCommentsOnQuestions 
	*/
	"setAllowCommentsOnQuestions": function(allowCommentsOnQuestions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAnonymous": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} anonymous 
	*/
	"setAnonymous": function(anonymous) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowConclusionMessage": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} showConclusionMessage 
	*/
	"setShowConclusionMessage": function(showConclusionMessage) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getConclusionMessage": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} conclusionMessage 
	*/
	"setConclusionMessage": function(conclusionMessage) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getCorrectorsIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} correctorsIds 
	*/
	"setCorrectorsIds": function(correctorsIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getRequiredAllQuestions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} requiredAllQuestions 
	*/
	"setRequiredAllQuestions": function(requiredAllQuestions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getRequiredScore": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  requiredScore 
	*/
	"setRequiredScore": function(requiredScore) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMaxExecutionTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} maxExecutionTime 
	*/
	"setMaxExecutionTime": function(maxExecutionTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMinExecutionTime": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} minExecutionTime 
	*/
	"setMinExecutionTime": function(minExecutionTime) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAllowEssayQuestion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} allowEssayQuestion 
	*/
	"setAllowEssayQuestion": function(allowEssayQuestion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getEnabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} enabled 
	*/
	"setEnabled": function(enabled) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.AssessmentBlockVersionVO&gt;} 
	*/
	"getAssessmentBlockVersions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} assessmentBlockVersions 
	*/
	"setAssessmentBlockVersions": function(assessmentBlockVersions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isKeepExistingAssessmentBlockVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} keepExistingAssessmentBlockVersion 
	*/
	"setKeepExistingAssessmentBlockVersion": function(keepExistingAssessmentBlockVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isAllowRestartAppFromCheckpoint": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} allowRestartAppFromCheckpoint 
	*/
	"setAllowRestartAppFromCheckpoint": function(allowRestartAppFromCheckpoint) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.lms.ImagePropertiesVO} 
	*/
	"getImageProperties": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.lms.ImagePropertiesVO} imageProperties 
	*/
	"setImageProperties": function(imageProperties) {}
};
com.fluig.sdk.filter.FilterResultVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFilterId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} filterId 
	*/
	"setFilterId": function(filterId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getUserId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} userId 
	*/
	"setUserId": function(userId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} userName 
	*/
	"setUserName": function(userName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFilterName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} filterName 
	*/
	"setFilterName": function(filterName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getProcessId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getProcessName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} processName 
	*/
	"setProcessName": function(processName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getPosition": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} position 
	*/
	"setPosition": function(position) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isPublicFilter": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} isPublicFilter 
	*/
	"setPublicFilter": function(isPublicFilter) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.filter.FilterFieldVO&gt;} 
	*/
	"getFields": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} fields 
	*/
	"setFields": function(fields) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.filter.FilterOrderVO} 
	*/
	"getFilterOrder": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.filter.FilterOrderVO} filterOrder 
	*/
	"setFilterOrder": function(filterOrder) {}
};
FilterResultVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFilterId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} filterId 
	*/
	"setFilterId": function(filterId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getUserId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} userId 
	*/
	"setUserId": function(userId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} userName 
	*/
	"setUserName": function(userName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFilterName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} filterName 
	*/
	"setFilterName": function(filterName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getProcessId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getProcessName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} processName 
	*/
	"setProcessName": function(processName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getPosition": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} position 
	*/
	"setPosition": function(position) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isPublicFilter": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} isPublicFilter 
	*/
	"setPublicFilter": function(isPublicFilter) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.filter.FilterFieldVO&gt;} 
	*/
	"getFields": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} fields 
	*/
	"setFields": function(fields) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.filter.FilterOrderVO} 
	*/
	"getFilterOrder": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.filter.FilterOrderVO} filterOrder 
	*/
	"setFilterOrder": function(filterOrder) {}
};
com.fluig.sdk.filter.FilterVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} type 
	*/
	"setType": function(type) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIsPublic": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} isPublic 
	*/
	"setIsPublic": function(isPublic) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.filter.FilterFieldVO&gt;} 
	*/
	"getFields": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} fields 
	*/
	"setFields": function(fields) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.filter.FilterOrderVO} 
	*/
	"getFilterOrder": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.filter.FilterOrderVO} filterOrder 
	*/
	"setFilterOrder": function(filterOrder) {}
};
FilterVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} type 
	*/
	"setType": function(type) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getProcessId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} processId 
	*/
	"setProcessId": function(processId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getIsPublic": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} isPublic 
	*/
	"setIsPublic": function(isPublic) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.filter.FilterFieldVO&gt;} 
	*/
	"getFields": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} fields 
	*/
	"setFields": function(fields) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.filter.FilterOrderVO} 
	*/
	"getFilterOrder": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.filter.FilterOrderVO} filterOrder 
	*/
	"setFilterOrder": function(filterOrder) {}
};
com.fluig.sdk.filter.FilterGroupResultVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFilterId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} filterId 
	*/
	"setFilterId": function(filterId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFilterName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} filterName 
	*/
	"setFilterName": function(filterName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getGroupId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} groupId 
	*/
	"setGroupId": function(groupId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getGroupCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} groupCode 
	*/
	"setGroupCode": function(groupCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getGroupDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} groupDescription 
	*/
	"setGroupDescription": function(groupDescription) {}
};
FilterGroupResultVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFilterId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} filterId 
	*/
	"setFilterId": function(filterId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFilterName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} filterName 
	*/
	"setFilterName": function(filterName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getGroupId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} groupId 
	*/
	"setGroupId": function(groupId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getGroupCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} groupCode 
	*/
	"setGroupCode": function(groupCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getGroupDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} groupDescription 
	*/
	"setGroupDescription": function(groupDescription) {}
};
com.fluig.sdk.filter.FilterGroupVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFilterId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} filterId 
	*/
	"setFilterId": function(filterId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getGroupsCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} groupsCode 
	*/
	"setGroupsCode": function(groupsCode) {}
};
FilterGroupVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getFilterId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} filterId 
	*/
	"setFilterId": function(filterId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getGroupsCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} groupsCode 
	*/
	"setGroupsCode": function(groupsCode) {}
};
com.fluig.sdk.api.lms.LinkVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getLinkedItemId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} linkedItemId 
	*/
	"setLinkedItemId": function(linkedItemId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getParentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} parentId 
	*/
	"setParentId": function(parentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}
};
LinkVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getLinkedItemId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} linkedItemId 
	*/
	"setLinkedItemId": function(linkedItemId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getParentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} parentId 
	*/
	"setParentId": function(parentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityPermission 
	*/
	"setSecurityPermission": function(securityPermission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.PermissionVO&gt;} 
	*/
	"getSecurityRestriction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} securityRestriction 
	*/
	"setSecurityRestriction": function(securityRestriction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getInheritPermissions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} inheritPermissions 
	*/
	"setInheritPermissions": function(inheritPermissions) {}
};
com.fluig.sdk.api.lms.LMSTaskVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getActions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} actions 
	*/
	"setActions": function(actions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPreferredAction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} preferredAction 
	*/
	"setPreferredAction": function(preferredAction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getIcon": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} icon 
	*/
	"setIcon": function(icon) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDueDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} dueDate 
	*/
	"setDueDate": function(dueDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} type 
	*/
	"setType": function(type) {}
};
LMSTaskVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTitle": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} title 
	*/
	"setTitle": function(title) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getActions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} actions 
	*/
	"setActions": function(actions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPreferredAction": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} preferredAction 
	*/
	"setPreferredAction": function(preferredAction) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getIcon": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} icon 
	*/
	"setIcon": function(icon) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getDueDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} dueDate 
	*/
	"setDueDate": function(dueDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} type 
	*/
	"setType": function(type) {}
};
com.fluig.sdk.api.document.DocumentSecurityConfigVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} sequence 
	*/
	"setSequence": function(sequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} permission 
	*/
	"setPermission": function(permission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowContent": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} showContent 
	*/
	"setShowContent": function(showContent) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getSecurityVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} securityVersion 
	*/
	"setSecurityVersion": function(securityVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getAttributionType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} attributionType 
	*/
	"setAttributionType": function(attributionType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAttributionValue": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} attributionValue 
	*/
	"setAttributionValue": function(attributionValue) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSecurityLevel": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} securityLevel 
	*/
	"setSecurityLevel": function(securityLevel) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDownloadEnabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} downloadEnabled 
	*/
	"setDownloadEnabled": function(downloadEnabled) {}
};
DocumentSecurityConfigVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} sequence 
	*/
	"setSequence": function(sequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getCompanyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} companyId 
	*/
	"setCompanyId": function(companyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getPermission": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} permission 
	*/
	"setPermission": function(permission) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowContent": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} showContent 
	*/
	"setShowContent": function(showContent) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getSecurityVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} securityVersion 
	*/
	"setSecurityVersion": function(securityVersion) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getAttributionType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} attributionType 
	*/
	"setAttributionType": function(attributionType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAttributionValue": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} attributionValue 
	*/
	"setAttributionValue": function(attributionValue) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSecurityLevel": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} securityLevel 
	*/
	"setSecurityLevel": function(securityLevel) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDownloadEnabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} downloadEnabled 
	*/
	"setDownloadEnabled": function(downloadEnabled) {}
};
com.fluig.sdk.api.document.DocumentRestrictionVO.prototype = {
	/**
	* Recupera valor do securityLevel
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSecurityLevel": function() {}, 
	/**
	* Atribui valor para securityLevel
	* @memberOf fluigAPI
	* @param {int} securityLevel 
	*/
	"setSecurityLevel": function(securityLevel) {}, 
	/**
	* Recupera valor do securityVersion
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getSecurityVersion": function() {}, 
	/**
	* Atribui valor para securityVersion
	* @memberOf fluigAPI
	* @param {boolean} securityVersion 
	*/
	"setSecurityVersion": function(securityVersion) {}, 
	/**
	* Recupera valor do inheritSecurity
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInheritSecurity": function() {}, 
	/**
	* Atribui valor para inheritSecurity
	* @memberOf fluigAPI
	* @param {boolean} inheritSecurity 
	*/
	"setInheritSecurity": function(inheritSecurity) {}, 
	/**
	* Recupera valor do downloadEnabled
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDownloadEnabled": function() {}, 
	/**
	* Atribui valor para downloadEnabled
	* @memberOf fluigAPI
	* @param {boolean} downloadEnabled 
	*/
	"setDownloadEnabled": function(downloadEnabled) {}, 
	/**
	* Recupera valor do showContent
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowContent": function() {}, 
	/**
	* Atribui valor para showContent
	* @memberOf fluigAPI
	* @param {boolean} showContent 
	*/
	"setShowContent": function(showContent) {}, 
	/**
	* Recupera valor do attributionDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAttributionDescription": function() {}, 
	/**
	* Atribui valor para attributionDescription
	* @memberOf fluigAPI
	* @param {String} attributionDescription 
	*/
	"setAttributionDescription": function(attributionDescription) {}, 
	/**
	* Recupera valor do attributionType
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getAttributionType": function() {}, 
	/**
	* Atribui valor para attributionType
	* @memberOf fluigAPI
	* @param {int} attributionType 
	*/
	"setAttributionType": function(attributionType) {}, 
	/**
	* Recupera valor do attributionValue
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAttributionValue": function() {}, 
	/**
	* Atribui valor para attributionValue
	* @memberOf fluigAPI
	* @param {String} attributionValue 
	*/
	"setAttributionValue": function(attributionValue) {}
};
DocumentRestrictionVO.prototype = {
	/**
	* Recupera valor do securityLevel
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSecurityLevel": function() {}, 
	/**
	* Atribui valor para securityLevel
	* @memberOf fluigAPI
	* @param {int} securityLevel 
	*/
	"setSecurityLevel": function(securityLevel) {}, 
	/**
	* Recupera valor do securityVersion
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getSecurityVersion": function() {}, 
	/**
	* Atribui valor para securityVersion
	* @memberOf fluigAPI
	* @param {boolean} securityVersion 
	*/
	"setSecurityVersion": function(securityVersion) {}, 
	/**
	* Recupera valor do inheritSecurity
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getInheritSecurity": function() {}, 
	/**
	* Atribui valor para inheritSecurity
	* @memberOf fluigAPI
	* @param {boolean} inheritSecurity 
	*/
	"setInheritSecurity": function(inheritSecurity) {}, 
	/**
	* Recupera valor do downloadEnabled
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getDownloadEnabled": function() {}, 
	/**
	* Atribui valor para downloadEnabled
	* @memberOf fluigAPI
	* @param {boolean} downloadEnabled 
	*/
	"setDownloadEnabled": function(downloadEnabled) {}, 
	/**
	* Recupera valor do showContent
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getShowContent": function() {}, 
	/**
	* Atribui valor para showContent
	* @memberOf fluigAPI
	* @param {boolean} showContent 
	*/
	"setShowContent": function(showContent) {}, 
	/**
	* Recupera valor do attributionDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAttributionDescription": function() {}, 
	/**
	* Atribui valor para attributionDescription
	* @memberOf fluigAPI
	* @param {String} attributionDescription 
	*/
	"setAttributionDescription": function(attributionDescription) {}, 
	/**
	* Recupera valor do attributionType
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getAttributionType": function() {}, 
	/**
	* Atribui valor para attributionType
	* @memberOf fluigAPI
	* @param {int} attributionType 
	*/
	"setAttributionType": function(attributionType) {}, 
	/**
	* Recupera valor do attributionValue
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAttributionValue": function() {}, 
	/**
	* Atribui valor para attributionValue
	* @memberOf fluigAPI
	* @param {String} attributionValue 
	*/
	"setAttributionValue": function(attributionValue) {}
};
com.fluig.sdk.api.workflow.ProcessAttachmentVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOriginalMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} originalMovementSequence 
	*/
	"setOriginalMovementSequence": function(originalMovementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getAttachedDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} attachedDate 
	*/
	"setAttachedDate": function(attachedDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}
};
ProcessAttachmentVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOriginalMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} originalMovementSequence 
	*/
	"setOriginalMovementSequence": function(originalMovementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueId 
	*/
	"setColleagueId": function(colleagueId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getAttachedDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} attachedDate 
	*/
	"setAttachedDate": function(attachedDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}
};
com.fluig.sdk.api.workflow.ProcessTaskInfoVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} movementSequence 
	*/
	"setMovementSequence": function(movementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTransferredSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} transferredSequence 
	*/
	"setTransferredSequence": function(transferredSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getStateSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} stateSequence 
	*/
	"setStateSequence": function(stateSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueName 
	*/
	"setColleagueName": function(colleagueName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.workflow.ProcessStateVO} 
	*/
	"getState": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.ProcessStateVO} state 
	*/
	"setState": function(state) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getTaskDeadline": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} taskDeadline 
	*/
	"setTaskDeadline": function(taskDeadline) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isExpired": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} expired 
	*/
	"setExpired": function(expired) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getStartDateTask": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} startDateTask 
	*/
	"setStartDateTask": function(startDateTask) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getStatus": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} status 
	*/
	"setStatus": function(status) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isActive": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} active 
	*/
	"setActive": function(active) {}
};
ProcessTaskInfoVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMovementSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} movementSequence 
	*/
	"setMovementSequence": function(movementSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTransferredSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} transferredSequence 
	*/
	"setTransferredSequence": function(transferredSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getStateSequence": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} stateSequence 
	*/
	"setStateSequence": function(stateSequence) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getColleagueName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} colleagueName 
	*/
	"setColleagueName": function(colleagueName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.workflow.ProcessStateVO} 
	*/
	"getState": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.workflow.ProcessStateVO} state 
	*/
	"setState": function(state) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getTaskDeadline": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} taskDeadline 
	*/
	"setTaskDeadline": function(taskDeadline) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isExpired": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} expired 
	*/
	"setExpired": function(expired) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getStartDateTask": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} startDateTask 
	*/
	"setStartDateTask": function(startDateTask) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getStatus": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} status 
	*/
	"setStatus": function(status) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isActive": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} active 
	*/
	"setActive": function(active) {}
};
com.fluig.sdk.api.enums.AssumeProcessTaskStatus.prototype = {
	/**
	* Returns an array containing the constants of this enum type, inthe order they are declared.  This method may be used to iterateover the constants as follows:<pre>for (AssumeProcessTaskStatus c : AssumeProcessTaskStatus.values())&nbsp;   System.out.println(c);</pre>
	* @memberOf fluigAPI
	*/
	"values": function() {}, 
	/**
	* Returns the enum constant of this type with the specified name.The string must match <i>exactly</i> an identifier used to declare anenum constant in this type.  (Extraneous whitespace characters are not permitted.)
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"valueOf": function(name) {}
};
AssumeProcessTaskStatus.prototype = {
	/**
	* Returns an array containing the constants of this enum type, inthe order they are declared.  This method may be used to iterateover the constants as follows:<pre>for (AssumeProcessTaskStatus c : AssumeProcessTaskStatus.values())&nbsp;   System.out.println(c);</pre>
	* @memberOf fluigAPI
	*/
	"values": function() {}, 
	/**
	* Returns the enum constant of this type with the specified name.The string must match <i>exactly</i> an identifier used to declare anenum constant in this type.  (Extraneous whitespace characters are not permitted.)
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"valueOf": function(name) {}
};
com.fluig.sdk.api.workflow.RequestTaskSLAVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getActivityDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} activityDescription 
	*/
	"setActivityDescription": function(activityDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAssigneeCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} assigneeCode 
	*/
	"setAssigneeCode": function(assigneeCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAssigneeName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} assigneeName 
	*/
	"setAssigneeName": function(assigneeName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getActivityCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} activityCode 
	*/
	"setActivityCode": function(activityCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"getAssigneeLocal": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.local.LocalVO} assigneeLocal 
	*/
	"setAssigneeLocal": function(assigneeLocal) {}
};
RequestTaskSLAVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getActivityDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} activityDescription 
	*/
	"setActivityDescription": function(activityDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAssigneeCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} assigneeCode 
	*/
	"setAssigneeCode": function(assigneeCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAssigneeName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} assigneeName 
	*/
	"setAssigneeName": function(assigneeName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getActivityCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} activityCode 
	*/
	"setActivityCode": function(activityCode) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.local.LocalVO} 
	*/
	"getAssigneeLocal": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.local.LocalVO} assigneeLocal 
	*/
	"setAssigneeLocal": function(assigneeLocal) {}
};
com.fluig.sdk.api.document.RelatedDocumentVO.prototype = {
	/**
	* Retorna tenantId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* Atribui valor para tenantId
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* Retorna documentId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* Atribui valor para documentoId
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* Retorna versão
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* Atribui valor para versão
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* Retorna relatedDocumentId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getRelatedDocumentId": function() {}, 
	/**
	* Atribui valor para relatedDocumentId
	* @memberOf fluigAPI
	* @param {int} relatedDocumentId 
	*/
	"setRelatedDocumentId": function(relatedDocumentId) {}
};
RelatedDocumentVO.prototype = {
	/**
	* Retorna tenantId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* Atribui valor para tenantId
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* Retorna documentId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDocumentId": function() {}, 
	/**
	* Atribui valor para documentoId
	* @memberOf fluigAPI
	* @param {int} documentId 
	*/
	"setDocumentId": function(documentId) {}, 
	/**
	* Retorna versão
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getVersion": function() {}, 
	/**
	* Atribui valor para versão
	* @memberOf fluigAPI
	* @param {int} version 
	*/
	"setVersion": function(version) {}, 
	/**
	* Retorna relatedDocumentId
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getRelatedDocumentId": function() {}, 
	/**
	* Atribui valor para relatedDocumentId
	* @memberOf fluigAPI
	* @param {int} relatedDocumentId 
	*/
	"setRelatedDocumentId": function(relatedDocumentId) {}
};
com.fluig.sdk.api.workflow.AttachmentVO.prototype = {
	/**
	* Recupera valor do absoluteFileName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAbsoluteFileName": function() {}, 
	/**
	* Atribui valor para absoluteFileName
	* @memberOf fluigAPI
	* @param {String} absoluteFileName 
	*/
	"setAbsoluteFileName": function(absoluteFileName) {}, 
	/**
	* Recupera valor do principal
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getPrincipal": function() {}, 
	/**
	* Atribui valor para principal
	* @memberOf fluigAPI
	* @param {boolean} principal 
	*/
	"setPrincipal": function(principal) {}, 
	/**
	* Recupera valor do attach
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAttach": function() {}, 
	/**
	* Atribui valor para attach
	* @memberOf fluigAPI
	* @param {boolean} attach 
	*/
	"setAttach": function(attach) {}, 
	/**
	* Recupera valor do fileName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFileName": function() {}, 
	/**
	* Atribui valor para fileName
	* @memberOf fluigAPI
	* @param {String} fileName 
	*/
	"setFileName": function(fileName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
AttachmentVO.prototype = {
	/**
	* Recupera valor do absoluteFileName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAbsoluteFileName": function() {}, 
	/**
	* Atribui valor para absoluteFileName
	* @memberOf fluigAPI
	* @param {String} absoluteFileName 
	*/
	"setAbsoluteFileName": function(absoluteFileName) {}, 
	/**
	* Recupera valor do principal
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getPrincipal": function() {}, 
	/**
	* Atribui valor para principal
	* @memberOf fluigAPI
	* @param {boolean} principal 
	*/
	"setPrincipal": function(principal) {}, 
	/**
	* Recupera valor do attach
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAttach": function() {}, 
	/**
	* Atribui valor para attach
	* @memberOf fluigAPI
	* @param {boolean} attach 
	*/
	"setAttach": function(attach) {}, 
	/**
	* Recupera valor do fileName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFileName": function() {}, 
	/**
	* Atribui valor para fileName
	* @memberOf fluigAPI
	* @param {String} fileName 
	*/
	"setFileName": function(fileName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.workflow.CardIndexAttachmentVO.prototype = {
	/**
	* Recupera valor do fileName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFileName": function() {}, 
	/**
	* Atribui valor para fileName
	* @memberOf fluigAPI
	* @param {String} fileName 
	*/
	"setFileName": function(fileName) {}, 
	/**
	* Recupera valor do principal
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getPrincipal": function() {}, 
	/**
	* Atribui valor para principal
	* @memberOf fluigAPI
	* @param {boolean} principal 
	*/
	"setPrincipal": function(principal) {}, 
	/**
	* Recupera valor do attach
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAttach": function() {}, 
	/**
	* Atribui valor para attach
	* @memberOf fluigAPI
	* @param {boolean} attach 
	*/
	"setAttach": function(attach) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
CardIndexAttachmentVO.prototype = {
	/**
	* Recupera valor do fileName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFileName": function() {}, 
	/**
	* Atribui valor para fileName
	* @memberOf fluigAPI
	* @param {String} fileName 
	*/
	"setFileName": function(fileName) {}, 
	/**
	* Recupera valor do principal
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getPrincipal": function() {}, 
	/**
	* Atribui valor para principal
	* @memberOf fluigAPI
	* @param {boolean} principal 
	*/
	"setPrincipal": function(principal) {}, 
	/**
	* Recupera valor do attach
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getAttach": function() {}, 
	/**
	* Atribui valor para attach
	* @memberOf fluigAPI
	* @param {boolean} attach 
	*/
	"setAttach": function(attach) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.page.PageWidgetMobileApiVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	* @returns {com.fluig.sdk.page.PageWidgetMobileApiVO} 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSlot": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} slot 
	* @returns {com.fluig.sdk.page.PageWidgetMobileApiVO} 
	*/
	"setSlot": function(slot) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getOrder": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} order 
	* @returns {com.fluig.sdk.page.PageWidgetMobileApiVO} 
	*/
	"setOrder": function(order) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	* @returns {com.fluig.sdk.page.PageWidgetMobileApiVO} 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isMobileEnabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} mobileEnabled 
	* @returns {com.fluig.sdk.page.PageWidgetMobileApiVO} 
	*/
	"setMobileEnabled": function(mobileEnabled) {}
};
PageWidgetMobileApiVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	* @returns {com.fluig.sdk.page.PageWidgetMobileApiVO} 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSlot": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} slot 
	* @returns {com.fluig.sdk.page.PageWidgetMobileApiVO} 
	*/
	"setSlot": function(slot) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getOrder": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} order 
	* @returns {com.fluig.sdk.page.PageWidgetMobileApiVO} 
	*/
	"setOrder": function(order) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} code 
	* @returns {com.fluig.sdk.page.PageWidgetMobileApiVO} 
	*/
	"setCode": function(code) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isMobileEnabled": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} mobileEnabled 
	* @returns {com.fluig.sdk.page.PageWidgetMobileApiVO} 
	*/
	"setMobileEnabled": function(mobileEnabled) {}
};
com.fluig.sdk.api.social.MediaVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMediaName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} mediaName 
	*/
	"setMediaName": function(mediaName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMediaType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} mediaType 
	*/
	"setMediaType": function(mediaType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMediaId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} mediaId 
	*/
	"setMediaId": function(mediaId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMediaVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} mediaVersion 
	*/
	"setMediaVersion": function(mediaVersion) {}
};
MediaVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMediaName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} mediaName 
	*/
	"setMediaName": function(mediaName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMediaType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} mediaType 
	*/
	"setMediaType": function(mediaType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMediaId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} mediaId 
	*/
	"setMediaId": function(mediaId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMediaVersion": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} mediaVersion 
	*/
	"setMediaVersion": function(mediaVersion) {}
};
com.fluig.sdk.api.social.ArticleCoverVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPath": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} path 
	*/
	"setPath": function(path) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPictureName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pictureName 
	*/
	"setPictureName": function(pictureName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {byte[]} 
	*/
	"getImage": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {byte[]} image 
	*/
	"setImage": function(image) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getCoordinateX": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} coordinateX 
	*/
	"setCoordinateX": function(coordinateX) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getCoordinateY": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} coordinateY 
	*/
	"setCoordinateY": function(coordinateY) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWidth": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} width 
	*/
	"setWidth": function(width) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getHeight": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} height 
	*/
	"setHeight": function(height) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getBase64media": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} base64media 
	*/
	"setBase64media": function(base64media) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"convertMediaData": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.social.CropVO} 
	*/
	"getCanvasData": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.CropVO} canvasData 
	*/
	"setCanvasData": function(canvasData) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.social.CropVO} 
	*/
	"getBoxData": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.CropVO} boxData 
	*/
	"setBoxData": function(boxData) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPictureId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pictureId 
	*/
	"setPictureId": function(pictureId) {}, 
	/**
	* Recupera o valor do field windowHeight
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWindowHeight": function() {}, 
	/**
	* Setado o valor do field windowHeight
	* @memberOf fluigAPI
	* @param {int} windowHeight 
	*/
	"setWindowHeight": function(windowHeight) {}, 
	/**
	* Recupera o valor do field windowWidth
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWindowWidth": function() {}, 
	/**
	* Setado o valor do field windowWidth
	* @memberOf fluigAPI
	* @param {int} windowWidth 
	*/
	"setWindowWidth": function(windowWidth) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
ArticleCoverVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPath": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} path 
	*/
	"setPath": function(path) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPictureName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pictureName 
	*/
	"setPictureName": function(pictureName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {byte[]} 
	*/
	"getImage": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {byte[]} image 
	*/
	"setImage": function(image) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getCoordinateX": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} coordinateX 
	*/
	"setCoordinateX": function(coordinateX) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getCoordinateY": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} coordinateY 
	*/
	"setCoordinateY": function(coordinateY) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWidth": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} width 
	*/
	"setWidth": function(width) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getHeight": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} height 
	*/
	"setHeight": function(height) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getBase64media": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} base64media 
	*/
	"setBase64media": function(base64media) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"convertMediaData": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.social.CropVO} 
	*/
	"getCanvasData": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.CropVO} canvasData 
	*/
	"setCanvasData": function(canvasData) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.social.CropVO} 
	*/
	"getBoxData": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.social.CropVO} boxData 
	*/
	"setBoxData": function(boxData) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getPictureId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} pictureId 
	*/
	"setPictureId": function(pictureId) {}, 
	/**
	* Recupera o valor do field windowHeight
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWindowHeight": function() {}, 
	/**
	* Setado o valor do field windowHeight
	* @memberOf fluigAPI
	* @param {int} windowHeight 
	*/
	"setWindowHeight": function(windowHeight) {}, 
	/**
	* Recupera o valor do field windowWidth
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWindowWidth": function() {}, 
	/**
	* Setado o valor do field windowWidth
	* @memberOf fluigAPI
	* @param {int} windowWidth 
	*/
	"setWindowWidth": function(windowWidth) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.social.SociableVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberLikes": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberLikes 
	*/
	"setNumberLikes": function(numberLikes) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberShares": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberShares 
	*/
	"setNumberShares": function(numberShares) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberComments": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberComments 
	*/
	"setNumberComments": function(numberComments) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberDenouncements": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberDenouncements 
	*/
	"setNumberDenouncements": function(numberDenouncements) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUrl": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} url 
	*/
	"setUrl": function(url) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} sociableType 
	*/
	"setSociableType": function(sociableType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSociableType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} objectClass 
	*/
	"setObjectClass": function(objectClass) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObjectClass": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} objectId 
	*/
	"setObjectId": function(objectId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObjectId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} thumbURL 
	*/
	"setThumbURL": function(thumbURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getThumbURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} userId 
	*/
	"setUserId": function(userId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getUserId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAlias": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} alias 
	*/
	"setAlias": function(alias) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  obj 
	* @returns {boolean} 
	*/
	"equals": function(obj) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
SociableVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberLikes": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberLikes 
	*/
	"setNumberLikes": function(numberLikes) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberShares": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberShares 
	*/
	"setNumberShares": function(numberShares) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberComments": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberComments 
	*/
	"setNumberComments": function(numberComments) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getNumberDenouncements": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} numberDenouncements 
	*/
	"setNumberDenouncements": function(numberDenouncements) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUrl": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} url 
	*/
	"setUrl": function(url) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} sociableType 
	*/
	"setSociableType": function(sociableType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSociableType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} objectClass 
	*/
	"setObjectClass": function(objectClass) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObjectClass": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} objectId 
	*/
	"setObjectId": function(objectId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObjectId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} thumbURL 
	*/
	"setThumbURL": function(thumbURL) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getThumbURL": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} name 
	*/
	"setName": function(name) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} userId 
	*/
	"setUserId": function(userId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getUserId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getAlias": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} alias 
	*/
	"setAlias": function(alias) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"hashCode": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  obj 
	* @returns {boolean} 
	*/
	"equals": function(obj) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.social.SocialBreadcrumbItemVO.prototype = {
	/**
	* Recupera o valor do field url
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUrl": function() {}, 
	/**
	* Setado o valor do field url
	* @memberOf fluigAPI
	* @param {String} url 
	*/
	"setUrl": function(url) {}, 
	/**
	* Recupera o valor do field description
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* Setado o valor do field description
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}
};
SocialBreadcrumbItemVO.prototype = {
	/**
	* Recupera o valor do field url
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUrl": function() {}, 
	/**
	* Setado o valor do field url
	* @memberOf fluigAPI
	* @param {String} url 
	*/
	"setUrl": function(url) {}, 
	/**
	* Recupera o valor do field description
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* Setado o valor do field description
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}
};
com.fluig.sdk.api.workflow.ProcessStateVO.prototype = {
	/**
	* Recupera valor do tenantId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* Atribui valor para tenantId
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* Recupera valor do sequence
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSequence": function() {}, 
	/**
	* Atribui valor para sequence
	* @memberOf fluigAPI
	* @param {int} sequence 
	*/
	"setSequence": function(sequence) {}, 
	/**
	* Recupera valor do stateName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStateName": function() {}, 
	/**
	* Atribui valor para stateName
	* @memberOf fluigAPI
	* @param {String} stateName 
	*/
	"setStateName": function(stateName) {}, 
	/**
	* Recupera valor do stateDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStateDescription": function() {}, 
	/**
	* Atribui valor para stateDescription
	* @memberOf fluigAPI
	* @param {String} stateDescription 
	*/
	"setStateDescription": function(stateDescription) {}
};
ProcessStateVO.prototype = {
	/**
	* Recupera valor do tenantId
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* Atribui valor para tenantId
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}, 
	/**
	* Recupera valor do sequence
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSequence": function() {}, 
	/**
	* Atribui valor para sequence
	* @memberOf fluigAPI
	* @param {int} sequence 
	*/
	"setSequence": function(sequence) {}, 
	/**
	* Recupera valor do stateName
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStateName": function() {}, 
	/**
	* Atribui valor para stateName
	* @memberOf fluigAPI
	* @param {String} stateName 
	*/
	"setStateName": function(stateName) {}, 
	/**
	* Recupera valor do stateDescription
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getStateDescription": function() {}, 
	/**
	* Atribui valor para stateDescription
	* @memberOf fluigAPI
	* @param {String} stateDescription 
	*/
	"setStateDescription": function(stateDescription) {}
};
com.fluig.sdk.api.alert.AlertSenderVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.alert.AlertUserVO} 
	*/
	"getUser": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.alert.AlertUserVO} user 
	*/
	"setUser": function(user) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCreationDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} creationDate 
	*/
	"setCreationDate": function(creationDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVia": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} via 
	*/
	"setVia": function(via) {}
};
AlertSenderVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.alert.AlertUserVO} 
	*/
	"getUser": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.alert.AlertUserVO} user 
	*/
	"setUser": function(user) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getCreationDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} creationDate 
	*/
	"setCreationDate": function(creationDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getVia": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} via 
	*/
	"setVia": function(via) {}
};
com.fluig.sdk.api.alert.AlertUserVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLogin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} login 
	*/
	"setLogin": function(login) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFullName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} fullName 
	*/
	"setFullName": function(fullName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFisrtName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLastName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getLastUpdateDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} lastUpdateDate 
	*/
	"setLastUpdateDate": function(lastUpdateDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}
};
AlertUserVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLogin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} login 
	*/
	"setLogin": function(login) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFullName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} fullName 
	*/
	"setFullName": function(fullName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getFisrtName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLastName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Date} 
	*/
	"getLastUpdateDate": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Date} lastUpdateDate 
	*/
	"setLastUpdateDate": function(lastUpdateDate) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}
};
com.fluig.sdk.api.alert.AlertEventVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEventKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} eventKey 
	*/
	"setEventKey": function(eventKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSingleDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} singleDescription 
	*/
	"setSingleDescription": function(singleDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getGroupDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} groupDescription 
	*/
	"setGroupDescription": function(groupDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getGrouped": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} grouped 
	*/
	"setGrouped": function(grouped) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getCanRemove": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} canRemove 
	*/
	"setCanRemove": function(canRemove) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.alert.AlertModuleVO} 
	*/
	"getModule": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.alert.AlertModuleVO} module 
	*/
	"setModule": function(module) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getIcon": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} icon 
	*/
	"setIcon": function(icon) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getOnlyAdmin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} onlyAdmin 
	*/
	"setOnlyAdmin": function(onlyAdmin) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getRequired": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} required 
	*/
	"setRequired": function(required) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getActive": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} active 
	*/
	"setActive": function(active) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescriptionKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} descriptionKey 
	*/
	"setDescriptionKey": function(descriptionKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSingleDescriptionKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} singleDescriptionKey 
	*/
	"setSingleDescriptionKey": function(singleDescriptionKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getGroupDescriptionKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} groupDescriptionKey 
	*/
	"setGroupDescriptionKey": function(groupDescriptionKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
AlertEventVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getEventKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} eventKey 
	*/
	"setEventKey": function(eventKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSingleDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} singleDescription 
	*/
	"setSingleDescription": function(singleDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getGroupDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} groupDescription 
	*/
	"setGroupDescription": function(groupDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getGrouped": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} grouped 
	*/
	"setGrouped": function(grouped) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getCanRemove": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} canRemove 
	*/
	"setCanRemove": function(canRemove) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.api.alert.AlertModuleVO} 
	*/
	"getModule": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.api.alert.AlertModuleVO} module 
	*/
	"setModule": function(module) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getIcon": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} icon 
	*/
	"setIcon": function(icon) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getOnlyAdmin": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} onlyAdmin 
	*/
	"setOnlyAdmin": function(onlyAdmin) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getRequired": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} required 
	*/
	"setRequired": function(required) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getActive": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} active 
	*/
	"setActive": function(active) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescriptionKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} descriptionKey 
	*/
	"setDescriptionKey": function(descriptionKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSingleDescriptionKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} singleDescriptionKey 
	*/
	"setSingleDescriptionKey": function(singleDescriptionKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getGroupDescriptionKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} groupDescriptionKey 
	*/
	"setGroupDescriptionKey": function(groupDescriptionKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.alert.AlertObjectVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getObjectId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} objectId 
	*/
	"setObjectId": function(objectId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObjectClass": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} objectClass 
	*/
	"setObjectClass": function(objectClass) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLink": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} link 
	*/
	"setLink": function(link) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getNote": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} note 
	*/
	"setNote": function(note) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTypeDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} typeDescription 
	*/
	"setTypeDescription": function(typeDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} objectDetail 
	*/
	"setObjectDetail": function(objectDetail) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObjectDetail": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTypeDescriptionKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} typeDescriptionKey 
	*/
	"setTypeDescriptionKey": function(typeDescriptionKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObjectDetailKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} objectDetailKey 
	*/
	"setObjectDetailKey": function(objectDetailKey) {}
};
AlertObjectVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getObjectId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} objectId 
	*/
	"setObjectId": function(objectId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObjectClass": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} objectClass 
	*/
	"setObjectClass": function(objectClass) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLink": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} link 
	*/
	"setLink": function(link) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getNote": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} note 
	*/
	"setNote": function(note) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTypeDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} typeDescription 
	*/
	"setTypeDescription": function(typeDescription) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} objectDetail 
	*/
	"setObjectDetail": function(objectDetail) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObjectDetail": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTypeDescriptionKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} typeDescriptionKey 
	*/
	"setTypeDescriptionKey": function(typeDescriptionKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getObjectDetailKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} objectDetailKey 
	*/
	"setObjectDetailKey": function(objectDetailKey) {}
};
com.fluig.sdk.api.alert.AlertActionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescriptionKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescriptionAfterExecKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getIntegrationType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUrl": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} url 
	*/
	"setUrl": function(url) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getHttpMethod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} httpMethod 
	*/
	"setHttpMethod": function(httpMethod) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getActionType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} actionType 
	*/
	"setActionType": function(actionType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getExecuted": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} executed 
	*/
	"setExecuted": function(executed) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescriptionAfterExec": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} descriptionAfterExec 
	*/
	"setDescriptionAfterExec": function(descriptionAfterExec) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getActionKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} actionKey 
	*/
	"setActionKey": function(actionKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} type 
	*/
	"setType": function(type) {}
};
AlertActionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescriptionKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescriptionAfterExecKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getIntegrationType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUrl": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} url 
	*/
	"setUrl": function(url) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getHttpMethod": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} httpMethod 
	*/
	"setHttpMethod": function(httpMethod) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getActionType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} actionType 
	*/
	"setActionType": function(actionType) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"getExecuted": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} executed 
	*/
	"setExecuted": function(executed) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescriptionAfterExec": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} descriptionAfterExec 
	*/
	"setDescriptionAfterExec": function(descriptionAfterExec) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getActionKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} actionKey 
	*/
	"setActionKey": function(actionKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} type 
	*/
	"setType": function(type) {}
};
com.fluig.sdk.api.lms.PermissionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getPartyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} partyId 
	*/
	"setPartyId": function(partyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getRoles": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} roles 
	*/
	"setRoles": function(roles) {}
};
PermissionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getPartyId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} partyId 
	*/
	"setPartyId": function(partyId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;String&gt;} 
	*/
	"getRoles": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} roles 
	*/
	"setRoles": function(roles) {}
};
com.fluig.sdk.api.lms.CatalogSkillVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMinPoint": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} minPoint 
	*/
	"setMinPoint": function(minPoint) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMaxPoint": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} maxPoint 
	*/
	"setMaxPoint": function(maxPoint) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSkillName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} skillName 
	*/
	"setSkillName": function(skillName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSkillDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} skillDescription 
	*/
	"setSkillDescription": function(skillDescription) {}
};
CatalogSkillVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMinPoint": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} minPoint 
	*/
	"setMinPoint": function(minPoint) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getMaxPoint": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} maxPoint 
	*/
	"setMaxPoint": function(maxPoint) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSkillName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} skillName 
	*/
	"setSkillName": function(skillName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSkillDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} skillDescription 
	*/
	"setSkillDescription": function(skillDescription) {}
};
com.fluig.sdk.api.lms.ImagePropertiesVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getCoordinateX": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} coordinateX 
	*/
	"setCoordinateX": function(coordinateX) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getCoordinateY": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} coordinateY 
	*/
	"setCoordinateY": function(coordinateY) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWidth": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} width 
	*/
	"setWidth": function(width) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getHeight": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} height 
	*/
	"setHeight": function(height) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getImageName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} imageName 
	*/
	"setImageName": function(imageName) {}
};
ImagePropertiesVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getCoordinateX": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} coordinateX 
	*/
	"setCoordinateX": function(coordinateX) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getCoordinateY": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} coordinateY 
	*/
	"setCoordinateY": function(coordinateY) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWidth": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} width 
	*/
	"setWidth": function(width) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getHeight": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} height 
	*/
	"setHeight": function(height) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getImageName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} imageName 
	*/
	"setImageName": function(imageName) {}
};
com.fluig.sdk.api.lms.EnrollUsersLogVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} newUserName 
	*/
	"setUserName": function(newUserName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getItemName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} newItemName 
	*/
	"setItemName": function(newItemName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMessage": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} newMessage 
	*/
	"setMessage": function(newMessage) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getUserId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} userId 
	*/
	"setUserId": function(userId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
EnrollUsersLogVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getUserName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} newUserName 
	*/
	"setUserName": function(newUserName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getItemName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} newItemName 
	*/
	"setItemName": function(newItemName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getMessage": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} newMessage 
	*/
	"setMessage": function(newMessage) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getUserId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} userId 
	*/
	"setUserId": function(userId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"toString": function() {}
};
com.fluig.sdk.api.lms.TrackItemVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getEnrollableItemId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} enrollableItemId 
	*/
	"setEnrollableItemId": function(enrollableItemId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isMandatory": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} mandatory 
	*/
	"setMandatory": function(mandatory) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getRequirementIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} requirementIds 
	*/
	"setRequirementIds": function(requirementIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOrder": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} order 
	*/
	"setOrder": function(order) {}
};
TrackItemVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getEnrollableItemId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} enrollableItemId 
	*/
	"setEnrollableItemId": function(enrollableItemId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isMandatory": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} mandatory 
	*/
	"setMandatory": function(mandatory) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getRequirementIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} requirementIds 
	*/
	"setRequirementIds": function(requirementIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOrder": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} order 
	*/
	"setOrder": function(order) {}
};
com.fluig.sdk.api.lms.ContentConfigVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getContentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} contentId 
	*/
	"setContentId": function(contentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isMandatory": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} mandatory 
	*/
	"setMandatory": function(mandatory) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOrder": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} order 
	*/
	"setOrder": function(order) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getScormProperties": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} scormProperties 
	*/
	"setScormProperties": function(scormProperties) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isUseScoreToApproveScorm": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} useScoreToApproveScorm 
	*/
	"setUseScoreToApproveScorm": function(useScoreToApproveScorm) {}
};
ContentConfigVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getContentId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} contentId 
	*/
	"setContentId": function(contentId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isMandatory": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} mandatory 
	*/
	"setMandatory": function(mandatory) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOrder": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} order 
	*/
	"setOrder": function(order) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {Map&lt;String,String&gt;} 
	*/
	"getScormProperties": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {Map} scormProperties 
	*/
	"setScormProperties": function(scormProperties) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isUseScoreToApproveScorm": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} useScoreToApproveScorm 
	*/
	"setUseScoreToApproveScorm": function(useScoreToApproveScorm) {}
};
com.fluig.sdk.api.lms.AlternativeVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getScore": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} score 
	*/
	"setScore": function(score) {}
};
AlternativeVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getScore": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} score 
	*/
	"setScore": function(score) {}
};
com.fluig.sdk.api.lms.BlockQuestionsFilterVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} type 
	*/
	"setType": function(type) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficultyStart": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficultyStart 
	*/
	"setDifficultyStart": function(difficultyStart) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficultyEnd": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficultyEnd 
	*/
	"setDifficultyEnd": function(difficultyEnd) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}
};
BlockQuestionsFilterVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTopicId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} topicId 
	*/
	"setTopicId": function(topicId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} type 
	*/
	"setType": function(type) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficultyStart": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficultyStart 
	*/
	"setDifficultyStart": function(difficultyStart) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getDifficultyEnd": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} difficultyEnd 
	*/
	"setDifficultyEnd": function(difficultyEnd) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getTags": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} tags 
	*/
	"setTags": function(tags) {}
};
com.fluig.sdk.api.lms.LacunaAlternativeVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.AlternativeVO&gt;} 
	*/
	"getAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} alternatives 
	*/
	"setAlternatives": function(alternatives) {}
};
LacunaAlternativeVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.AlternativeVO&gt;} 
	*/
	"getAlternatives": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} alternatives 
	*/
	"setAlternatives": function(alternatives) {}
};
com.fluig.sdk.api.lms.CorrelationAlternativeVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String[]} 
	*/
	"getCorrelations": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String[]} correlations 
	*/
	"setCorrelations": function(correlations) {}
};
CorrelationAlternativeVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String[]} 
	*/
	"getCorrelations": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String[]} correlations 
	*/
	"setCorrelations": function(correlations) {}
};
com.fluig.sdk.api.lms.AssessmentBlockVersionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getBlockId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} blockId 
	*/
	"setBlockId": function(blockId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWeight": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} weight 
	*/
	"setWeight": function(weight) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOrder": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} order 
	*/
	"setOrder": function(order) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isAllQuestionsRequired": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} allQuestionsRequired 
	*/
	"setAllQuestionsRequired": function(allQuestionsRequired) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getRequiredScore": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  requiredScore 
	*/
	"setRequiredScore": function(requiredScore) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isAllowsZero": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} allowsZero 
	*/
	"setAllowsZero": function(allowsZero) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getAssessmentBlockVersionId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getBlockName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} blockName 
	*/
	"setBlockName": function(blockName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} assessmentBlockVersionId 
	*/
	"setAssessmentBlockVersionId": function(assessmentBlockVersionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.BlockQuestionsFilterVO&gt;} 
	*/
	"getTopicFilters": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} topicFilters 
	*/
	"setTopicFilters": function(topicFilters) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSelectQuestions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} selectQuestions 
	*/
	"setSelectQuestions": function(selectQuestions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getQuestionVersionIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} questionVersionIds 
	*/
	"setQuestionVersionIds": function(questionVersionIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getNumberRandomQuestions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} numberRandomQuestions 
	*/
	"setNumberRandomQuestions": function(numberRandomQuestions) {}
};
AssessmentBlockVersionVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getBlockId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} blockId 
	*/
	"setBlockId": function(blockId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWeight": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} weight 
	*/
	"setWeight": function(weight) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getOrder": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} order 
	*/
	"setOrder": function(order) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isAllQuestionsRequired": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} allQuestionsRequired 
	*/
	"setAllQuestionsRequired": function(allQuestionsRequired) {}, 
	/**
	* 
	* @memberOf fluigAPI
	*/
	"getRequiredScore": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param  requiredScore 
	*/
	"setRequiredScore": function(requiredScore) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isAllowsZero": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} allowsZero 
	*/
	"setAllowsZero": function(allowsZero) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getAssessmentBlockVersionId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getBlockName": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} blockName 
	*/
	"setBlockName": function(blockName) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} assessmentBlockVersionId 
	*/
	"setAssessmentBlockVersionId": function(assessmentBlockVersionId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;com.fluig.sdk.api.lms.BlockQuestionsFilterVO&gt;} 
	*/
	"getTopicFilters": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} topicFilters 
	*/
	"setTopicFilters": function(topicFilters) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getSelectQuestions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} selectQuestions 
	*/
	"setSelectQuestions": function(selectQuestions) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {List&lt;long&gt;} 
	*/
	"getQuestionVersionIds": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {List} questionVersionIds 
	*/
	"setQuestionVersionIds": function(questionVersionIds) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getNumberRandomQuestions": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} numberRandomQuestions 
	*/
	"setNumberRandomQuestions": function(numberRandomQuestions) {}
};
com.fluig.sdk.filter.FilterFieldVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} key 
	*/
	"setKey": function(key) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getValue": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} value 
	*/
	"setValue": function(value) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLabel": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} label 
	*/
	"setLabel": function(label) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} type 
	*/
	"setType": function(type) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSlotId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} slotId 
	*/
	"setSlotId": function(slotId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isVisible": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} visible 
	*/
	"setVisible": function(visible) {}
};
FilterFieldVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} key 
	*/
	"setKey": function(key) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getValue": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} value 
	*/
	"setValue": function(value) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getType": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getLabel": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} label 
	*/
	"setLabel": function(label) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} type 
	*/
	"setType": function(type) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getSlotId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} slotId 
	*/
	"setSlotId": function(slotId) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {boolean} 
	*/
	"isVisible": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {boolean} visible 
	*/
	"setVisible": function(visible) {}
};
com.fluig.sdk.filter.FilterOrderVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.filter.FilterFieldVO} 
	*/
	"getField": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.filter.FilterFieldVO} field 
	*/
	"setField": function(field) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getOrder": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} order 
	*/
	"setOrder": function(order) {}
};
FilterOrderVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {com.fluig.sdk.filter.FilterFieldVO} 
	*/
	"getField": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {com.fluig.sdk.filter.FilterFieldVO} field 
	*/
	"setField": function(field) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getOrder": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} order 
	*/
	"setOrder": function(order) {}
};
com.fluig.sdk.api.social.CropVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getHeight": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} height 
	*/
	"setHeight": function(height) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWidth": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} width 
	*/
	"setWidth": function(width) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getLeft": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} left 
	*/
	"setLeft": function(left) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTop": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} top 
	*/
	"setTop": function(top) {}
};
CropVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getHeight": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} height 
	*/
	"setHeight": function(height) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getWidth": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} width 
	*/
	"setWidth": function(width) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getLeft": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} left 
	*/
	"setLeft": function(left) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {int} 
	*/
	"getTop": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {int} top 
	*/
	"setTop": function(top) {}
};
com.fluig.sdk.api.alert.AlertModuleVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getModuleKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} moduleKey 
	*/
	"setModuleKey": function(moduleKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}
};
AlertModuleVO.prototype = {
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} id 
	*/
	"setId": function(id) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getModuleKey": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} moduleKey 
	*/
	"setModuleKey": function(moduleKey) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {String} 
	*/
	"getDescription": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {String} description 
	*/
	"setDescription": function(description) {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @returns {long} 
	*/
	"getTenantId": function() {}, 
	/**
	* 
	* @memberOf fluigAPI
	* @param {long} tenantId 
	*/
	"setTenantId": function(tenantId) {}
};
