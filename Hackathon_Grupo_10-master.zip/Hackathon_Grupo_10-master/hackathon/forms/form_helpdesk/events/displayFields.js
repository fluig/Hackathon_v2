function displayFields(form, customHTML) {
    var atividade = getValue('WKNumState');
    var usuario = getValue('WKUser');
    var dataAtual = dateNow();

    //inicio
    if (atividade == 0 || atividade == 4) {
        form.setValue('dataSoli', dataAtual);

        form.setVisibleById('fildsResp', false);
    }

    //resolução
    if (atividade == 5) {
        form.setValue('responsavel', usuario);
        form.setValue('dataResp', dataAtual);

        form.setVisibleById('fildsResp', true);
    }
}
