function enableFields(form) {
    var atividade = getValue('WKNumState');
    var usuario = getValue('WKUser');

    //inicio
    if (atividade == 0 || atividade == 4) {
        form.setEnabled('descrResp', false);
    }

    //resolução
    if (atividade == 5) {
        form.setEnabled('descrResp', true);
    }
}
