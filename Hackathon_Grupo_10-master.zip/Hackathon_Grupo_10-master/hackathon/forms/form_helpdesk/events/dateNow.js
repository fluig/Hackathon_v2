function dateNow() {
    var formato = new java.text.SimpleDateFormat('dd/MM/yyyy');
    return formato.format(new java.util.Date());
}
