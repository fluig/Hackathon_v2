function afterProcessCreate(processId) {
    var consumer = oauthUtil.getNewAPIConsumer('enviaEmailAutomatico', 'enviaEmailAutomatico',
        '79c8aa71-a21f-4877-a7ff-e38547417fe5', '0087a043-d555-4fa7-9596-473c281bba6cd6012d10-168a-41eb-8c5d-30eb73033ecb')

        log.info("##batman");

    var email = hAPI.getCardValue("emailSoli")
    var corpoEmail = hAPI.getCardValue("descrSoli")

    var json = '{\
        "from" : "jessiley.oliveira@iv2.com.br",\
         "to" : "'+email+'",\
         "subject" : "Solicitacao: '+ processId +' encaminhada para resolucao ",\
         "templateId" : "solicitacao_helpdesk",\
         "dialectId"  : "pt_BR",\
         "param" : {\
          "CONTEUDO" : "Texto da mensagem: '+corpoEmail+'"\
          }\
   }'
    consumer.post("/public/alert/customEmailSender", json);
}
