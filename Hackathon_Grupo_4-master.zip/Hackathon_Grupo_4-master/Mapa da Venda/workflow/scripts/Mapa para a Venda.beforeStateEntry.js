function beforeStateEntry(sequenceId){
	
	
	if (sequenceId == 8) {

		hAPI.setCardValue('resultadoAcao', '1');
		
	}

	if (sequenceId == 6) {

		hAPI.setCardValue('resultadoAcao', '2');

	}

	if (sequenceId == 14) {

		hAPI.setCardValue('resultadoAcao', '3');
		
	}
	
	
	
	
	
}