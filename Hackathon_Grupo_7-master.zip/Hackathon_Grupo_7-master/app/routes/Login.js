module.exports = function(app){
	app.post('/login', (req, res) => {
		console.log(db)
		
			/*dbConn.collection('redeem').save(req.body, (err, result) => {
				if (err) console.log(err)

				console.log('save to databse')
				res.redirect('/')
			})*/
		//);
			
	})
}