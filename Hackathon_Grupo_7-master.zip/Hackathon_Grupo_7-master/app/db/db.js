/*const MongoClient = require('mongodb').MongoClient

const dbUrl = "mongodb://localhost:27017/redeem";*/



/*MongoClient.connect(dbUrl, (err, database) => {
	if (!err) {
		console.log('connected to mongodb successfully')
		db = database
	}
});*/



