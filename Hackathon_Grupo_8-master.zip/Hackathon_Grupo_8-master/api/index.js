var restify = require('restify');
var request = require('request');
var Promise = require('Promise');

function respond(req, res, next) {
  res.send('hello ' + req.params.name);
  next();
}

var server = restify.createServer();

server.get('/conversation/:codigo',function(req, res, next){
    request.post("http://fluig08.hackthon2017.fluig.io:8080/api/public/messaging/createConversation/v2",{
      "idOwnder": 5,
      "participantsIds": [3],
      "distinct": true,
      "metaData": {"conversationTitle": "Atendimento do Cliente Bruno no pedido"+req.params.codigo}
    })
    let idconversa = res.content.id.replace("layer:///conversations/", "");
});

server.listen(8080, function() {
  console.log('%s listening at %s', server.name, server.url);
});
