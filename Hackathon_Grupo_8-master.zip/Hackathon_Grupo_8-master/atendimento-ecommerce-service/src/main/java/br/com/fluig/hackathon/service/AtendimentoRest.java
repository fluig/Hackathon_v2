package br.com.fluig.hackathon.service;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import br.com.fluig.hackathon.domain.AtendimentoBs;
import br.com.fluig.hackathon.domain.model.EstadoAtendimento;
import br.com.fluig.hackathon.domain.model.Pedido;
import br.com.fluig.hackathon.domain.model.ResultadoAtendimento;

@Service
@RequestMapping("/atendimento")
public class AtendimentoRest {

	@Autowired
	private AtendimentoBs atendimentoBs;
	
	@RequestMapping(value = "/iniciar", method = RequestMethod.POST )
	public @ResponseBody ResultadoAtendimento iniciar(@RequestBody Pedido pedidoMap) {
		return atendimentoBs.iniciar(pedidoMap);
	}	
	
	@RequestMapping(value = "/status/{codigo}", method = RequestMethod.POST)
	public @ResponseBody EstadoAtendimento status(@PathVariable int codigo) {
		return atendimentoBs.status(codigo);
	}	
	
	
	@RequestMapping(value = "/criarConversa/{codigo}", method = RequestMethod.POST,  produces="application/json")
	public @ResponseBody int criarConversa(@PathVariable int codigo){
		 RestTemplate restTemplate = new RestTemplate();
		 HttpHeaders headers = new HttpHeaders();
		 headers.setContentType(MediaType.APPLICATION_JSON);
		 
		 Map<String, Object> map = new HashMap<String, Object>();
		 Map<String, Object> mapChild = new HashMap<String, Object>();
		 map.put("idOwner", 5);
		 map.put("participantsIds", Arrays.asList(3));
		 map.put("distinct", true);
		 mapChild.put("conversationTitle",  "Atendimento do cliente Bruno no pedido: " + codigo);
		 map.put("metaData", 5);
		 HttpEntity<String> entity = new HttpEntity<String>(map.toString() ,headers);
		 
		 Map<String, Object> result = (Map<String, Object>) restTemplate.exchange("http://fluig08.hackathon2017.fluig.io:8080/api/public/messaging/createConversation/v2", HttpMethod.POST, entity, Map.class);
		 return 0;
	}
	
	
}
