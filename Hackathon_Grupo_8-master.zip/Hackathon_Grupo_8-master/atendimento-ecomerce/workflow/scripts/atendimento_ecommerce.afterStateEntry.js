function afterStateEntry(sequenceId){
	hAPI.setCardValue("WKNumState", sequenceId);
}