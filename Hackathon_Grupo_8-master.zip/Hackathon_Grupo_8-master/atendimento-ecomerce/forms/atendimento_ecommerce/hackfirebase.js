var hackfirebase = (
	function () {
		'use strict';
		
		function init() {
			 var config = {
					    apiKey: "AIzaSyBI7pmGyIRGUPr_3Y_9FKppgGbIQk8p9Xk",
					    authDomain: "venda-top.firebaseapp.com",
					    databaseURL: "https://venda-top.firebaseio.com",
					    projectId: "venda-top",
					    storageBucket: "venda-top.appspot.com",
					    messagingSenderId: "962954542919"
					  };
					  firebase.initializeApp(config);
			
		};
		
		function escreverAtendimento(codigo, status, mensagem){
			firebase.database().ref('treatment/' + codigo).set({
				numeroAtividade: status,
				mensagem: mensagem,
				data: moment().format("DD/MM/YYYY HH:mm:ss")
			 });
			lerAtendimento(codigo);
		}
		
		function lerAtendimento(codigo){
			var treatment;
			var starCountRef = firebase.database().ref('treatment/' + 25);
			starCountRef.on('value', function(atendimento) {
					console.log(atendimento.val());
					treatment = atendimento.val();
			});
			return treatment;
		}
		return {
			init: init,
			escreverAtendimento: escreverAtendimento,
			lerAtendimento:lerAtendimento
		}

	})();

