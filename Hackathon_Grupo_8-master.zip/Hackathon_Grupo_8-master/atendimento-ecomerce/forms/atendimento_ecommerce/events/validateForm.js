function validateForm(form) {

	if (form.getValue("WKNumState") == "5" && form.getValue("itensChecados") != "true") {
		var msg = "Todos os itens devem estar checados"
		throw new Error(msg);
	}
}