var formWorkflow = (
	function () {
		'use strict';
		
		
		function init() {
			$("#lbEmailCliente").text($("#email").val());
			$("#lbNomeCliente").text($("#nome").val());
			$("#lbEntregar").text($("#entrega").val());
			$("#lbDataPedido").text($("#dataPedido").val());
			$("#lbDataPickup").text($("#dataPickup").val());
			$("#lbNomeLoja").text($("#nomeLoja").val());
			
			produtos.criarTabela();
			hackfirebase.init();
			atualizarStatusPedido();
			
			window.parent.$("button[data-send]").click(function () {
				var mensagem = "Iniciando separação do seu pedido";
				
				if($("#WKNumState").val() == 5){
					mensagem = document.workflowStates.SEPARAR
				}else if ($("#WKNumState").val() == 15){
					mensagem = document.workflowStates.PICKUP
				}else if ($("#WKNumState").val() == 25){
					mensagem = document.workflowStates.TRANSPORTADORA
				}else if ($("#WKNumState").val() == 13){
					mensagem = document.workflowStates.ENTREGA
				}
				
				hackfirebase.escreverAtendimento($("#WKNumProces").val(), $("#WKNumState").val(), mensagem);
			});
		};
		
		function atualizarStatusPedido(){
			
			var formMode = $("#FormMode").val() == "VIEW";
			var numState = $("#WKNumState").val();
			var mensagem = "Iniciando separação do seu pedido";
			if(numState == 5 && !formMode){
				mensagem = document.workflowStates.SEPARAR
			}else if (numState == 5 && formMode){
				mensagem = document.workflowStates.SEPARAR_VIEW
			}else if (numState == 15 && !formMode){
				mensagem = document.workflowStates.PICKUP
			}else if (numState == 15 && formMode){
				mensagem = document.workflowStates.PICKUP_VIEW
			}else if (numState == 25 && !formMode){
				mensagem = document.workflowStates.TRANSPORTADORA
			}else if (numState== 25 && formMode){
				mensagem = document.workflowStates.TRANSPORTADORA_VIEW
			}else if (numState == 13 && !formMode){
				mensagem = document.workflowStates.ENTREGA
			}else if (numState == 13 && formMode){
				mensagem = document.workflowStates.ENTREGA_VIEW
			}
			
			hackfirebase.escreverAtendimento($("#WKNumProces").val(), $("#WKNumState").val(), mensagem);
		}
		return {
			init: init
		}

	})();



