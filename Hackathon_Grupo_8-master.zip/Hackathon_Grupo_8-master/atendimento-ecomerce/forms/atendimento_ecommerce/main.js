$(document).ready(function() {
	
	(function(form, that) {
	    'use strict';
	    console.log("aplicação iniciada");
	    that.workflowStates = initConstantesWorkflowState();
	    form.init();
	    
	    
	})(formWorkflow, this);
	
	function initConstantesWorkflowState(){
		return Object.freeze({
			 'SEPARAR_VIEW' : "Aguardando inicialização da separação do pedido.",
		   	 'SEPARAR' : "Pedido está sendo separado para entrega.",
		   	 'PICKUP_VIEW' : "Aguardando inicialização da preparação do pedido para Pick up",
		   	 'PICKUP' : "Pedido está sendo preparado para retirada.",
		   	 'ENTREGA_VIEW' : "Aguardando inicialização da entrega do pedido",
		   	 'ENTREGA' : "Pedido está a caminho.",
		   	 'TRANSPORTADORA_VIEW' : "Aguardando inicialização do envio pela transportadora",
		   	 'TRANSPORTADORA' : "Pedido foi enviado pela trasnportadora."
		   });
	}
});




 