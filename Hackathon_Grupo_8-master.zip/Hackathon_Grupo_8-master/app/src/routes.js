import about from './components/pages/About.vue'
import checkout from './components/pages/Checkout.vue'
import products from './components/pages/Products.vue'
import orders from './components/pages/Pedidos'
import orderPickup from './components/pages/OrderPickUp.vue'
// import chat from './components/pages/Chat'

export default [
  {
    path: '/',
    component: products
  },
  {
    path: '/products/',
    component: products
  },
  {
    path: '/order-pickup',
    component: orderPickup
  },
  {
    path: '/about/',
    component: about
  },
  {
    path: '/checkout/',
    component: checkout
  },
  {
    path: '/orders/',
    component: orders
  }
]
