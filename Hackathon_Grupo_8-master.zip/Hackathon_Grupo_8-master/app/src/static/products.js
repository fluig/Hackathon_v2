export default [
    {
        ean: 123,
        name: "God Of War 3 Ps3",
        subtitle: "God Of War 3 Ps3 Favoritos Novo Lacrado + Pôster Brinde",
        price: 84.89
      },
      {
        ean: 234,
        name: "Fifa 18",
        subtitle: "Ps4 Fifa Soccer 2018 Português Midia Fisica Lacrado",
        price: 204.48
      },
      {
        ean: 245,
        name: "Jogo Gta 5",
        subtitle: "Grand Theft Auto V Ps4 Mídia Física Lacrado",
        price: 159.99
      },
      {
        ean: 345,
        name: "Batman Return To Arkham",
        subtitle: "Jogo Mídia Física Batman Return To Arkham+filme Xbox One",
        price: 129.99
      },
      {
        ean: 545,
        name: "The Legend Of Zelda",
        subtitle: "The Legend Of Zelda Breath Of The Wild Midia Fisica Wii U",
        price: 259.99
      },
      {
        ean: 575,
        name: "Nintendo Switch",
        subtitle: "Nintendo Switch 32gb Cinza Ou Colorido",
        price: 1669.99
      },
      {
        ean: 655,
        name: "Batman Return To Arkham",
        subtitle: "Jogo Mídia Física Batman Return To Arkham+filme Xbox One",
        price: 129.99
      },
]
