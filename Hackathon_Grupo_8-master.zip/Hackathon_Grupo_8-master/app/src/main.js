// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import Vuetify from 'vuetify'
import VueFire from 'vuefire'
import Firebase from 'firebase'


// Import F7
/* eslint-disable no-unused-vars */
import Framework7 from 'framework7'

// Import F7 Vue Plugin
import Framework7Vue from 'framework7-vue'

import Framework7Theme from 'framework7/dist/css/framework7.material.css'
import Framework7ThemeColors from 'framework7/dist/css/framework7.material.colors.min.css'

// Import Routes
import Routes from './routes.js'

import App from './App'


// Init F7 Vue Plugin
Vue.use(Framework7Vue)

// Init VueFire Vue Plugin
Vue.use(VueFire)

Vue.use(Vuetify)

/* eslint-disable no-new */
// Init App
window.app = new Vue({
  el: '#app',
  template: '<app/>',
  framework7: {
    root: '#app',
    material: true,
    routes: Routes
  },
  created: function() {
    console.log(this)
  },
  components: {
    app: App
  }
})
