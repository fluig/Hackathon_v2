<template>
  <!-- App -->
  <div id="app">

    <!-- Statusbar -->
    <f7-statusbar></f7-statusbar>

    <!-- Left Panel -->
    <f7-panel left reveal layout="dark">
      <f7-view id="left-panel-view" navbar-through :dynamic-navbar="true">
        <f7-navbar>
          <f7-block>
            <i class="material-icons icon">account_circle</i>
          </f7-block>

        </f7-navbar>
        <f7-pages>
          <f7-page>
            <f7-block-title>Bem vindo</f7-block-title>
            <f7-list>
              <f7-list-item link="/products" title="Produtos" link-view="#main-view" link-close-panel>
                
              </f7-list-item>
              <f7-list-item link="/orders" title="Pedidos" link-view="#main-view" link-close-panel>
                <i class="material-icons icon">credit_card</i>
              </f7-list-item>
            </f7-list>
          </f7-page>
        </f7-pages>
      </f7-view>
    </f7-panel>

    <!-- Main Views -->
    <f7-views>
      <f7-view id="main-view" navbar-through :dynamic-navbar="true" main>
        <!-- Navbar -->
        <f7-navbar>
          <f7-nav-left>
            <f7-link icon="icon-bars" open-panel="left"></f7-link>
          </f7-nav-left>
          <f7-nav-center sliding>Bungee Jump Store</f7-nav-center>
          <f7-nav-right>
            <f7-link icon="icon-box_fill" href="/checkout"><i class="material-icons icon">shopping_basket</i> &nbsp;&nbsp; {{countCart}}</f7-link>
          </f7-nav-right>
        </f7-navbar>
        <!-- Pages -->
        <f7-pages>
          <f7-page>
            <f7-list link="/about/" title="About"></f7-list>
          </f7-page>
        </f7-pages>
      </f7-view>
    </f7-views>

  </div>
</template>

<script>

import product from './components/Product'
import ProductsPage from './components/pages/Products.vue'

export default {

  data: () => {
    return {
      selectedProducts: [],
    }
  },

  methods: {
    getSelectedProducts: {

    },
    productQuantChanged: function(product, quant) {
      product.quant = quant
      let exists = this.selectedProducts.find((listed) => listed.ean == product.ean)
      if (!exists) {
        this.selectedProducts.push(product)
      }
      if (quant == 0) {
        this.selectedProducts = this.selectedProducts.filter((listed) => listed.ean != product.ean)
      }

    },
    onProductsSelected: function(productList) {
      window.app_selectedProducts = productList
    }
  },
  components: {
    product,
    ProductsPage
  },
  computed: {
    countCart: function() {
      let count = 0
      return this.selectedProducts.length
    }
  },
  watch: {
  }

}
</script>
