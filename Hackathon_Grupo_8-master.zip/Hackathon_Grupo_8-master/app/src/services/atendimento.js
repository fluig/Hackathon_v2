import ClientHttp from './ClientHttp';

export default class atendimento{

  /**
   * @param usuario {email, nome}
   * @param produtos [{id, codigoBarras, descricao, qtde}]
   * @param dataPickUp "dd/MM/YYYY HH:mm:ss"
   * @param ehEntrega "true"
   * @param nomeLoja "bungee jump"
   */
  static iniciar( usuario, produtos, dataPickUp, ehEntrega, nomeLoja ){
     return ClientHttp.post('atendimento/iniciar', {usuario, produtos, dataPickUp, ehEntrega, nomeLoja} );
  }

  /**
   *@param codigo 123
   */
  static status(codigo){
    return ClientHttp.post('atendimento/status/'+codigo);
  }
}




