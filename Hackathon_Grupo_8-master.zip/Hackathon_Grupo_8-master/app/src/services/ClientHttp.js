import axios from 'axios'

const http = axios.create({
  baseURL: 'http://67.205.149.247:8080/atendimento/services/',
  timeout: 2000,
  header:{"Access-Control-Allow-Origin":"*", "Content-Type":"application/json"}
});

export default http;
