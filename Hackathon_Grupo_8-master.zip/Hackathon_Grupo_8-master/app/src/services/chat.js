import ClientHttp from './ClientHttp';

export default class Chat{

  
  static createConversation(codigo){
    return ClientHttp.post('http://fluig08.hackathon2017.fluig.io:8080/api/public/messaging/createConversation/v2', { "idOwner" : 5, 
        "participantsIds" : [3],
        "distinct" : true, 
        "metaData": { "conversationTitle": "Atendimento do cliente Bruno no pedido: " + codigo}}).then(res =>{
          let idconversa = res.content.id.replace("layer:///conversations/", "");
          console.log("Id conversa:" + idconversa)
          return idconversa;
        });
    } 

   static sendMessage(codigoConversa, textoConversa){
     return ClientHttp.post('http://fluig08.hackathon2017.fluig.io:8080/api/public/messaging/sendMessage/' + codigoConversa, { "text" : textoConversa});
    } 

}




