export default {
  exclude: 'node_modules/**',
  runtimeHelpers: true
};
