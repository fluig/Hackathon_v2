<template>
    <span>
        <v-stepper v-model="modelStep" >
            <v-stepper-header>
            <v-stepper-step step="1" :complete="solicStep > 1"></v-stepper-step>

            <v-divider></v-divider>
            <v-stepper-step step="2" :complete="solicStep > 2"></v-stepper-step>

            <v-divider></v-divider>
            <v-stepper-step step="3" :complete="solicStep > 3"></v-stepper-step>

            <v-divider></v-divider>
            <v-stepper-step step="4" :complete="solicStep > 4"></v-stepper-step>

            </v-stepper-header>
        </v-stepper>
    </span>

</template>
<script>
require('vuetify/dist/vuetify.min.css')
require('material-design-icons/iconfont/material-icons.css')

export default {
  props: ['step'],
  data: function() {
      return {
          modelStep: ""
       }
  },
  computed: {
      solicStep: function() {
        return Number(this.step+1)
      }
  }
}
</script>

<style scoped>
    .stepper__step--complete .stepper__step__step {
        color: white
    }
    .stepper {
        box-shadow: unset
    }
    .divider.hr {
        border: 1px solid #cdcdcd;
    }
</style>



