<template>
  <div>
    <f7-card>
        <f7-card-content>
             <div class="list-block media-list">
                <ul>
                    <li class="item-content">
                    <div class="item-media">
                        <img :src="product.img" width="80">
                    </div>
                    <div class="item-inner">
                        <div class="item-title-row">
                        <div class="item-title">{{product.name}}</div>
                        </div>
                        <div class="item-subtitle">{{product.subtitle}}</div>
                    </div>
                    </li>
                </ul>
            </div>
        </f7-card-content>
        <f7-card-footer>
            <div class="row no-gutter" style="width: 100%">
                <!-- Each "cell" has col-[widht in percents] class -->
                <div class="col-50">
                    Quant:  <b>{{quant || 0}}</b>
                </div>
                <div class="col-50">
                    Preço: R$ <b>{{product.price || 0}}</b>
                </div>
            </div>
        </f7-card-footer>
        <f7-card-footer v-if="allowEdit">
          <f7-button @click="increment">+</f7-button>
          <f7-button @click="decrement">-</f7-button>
          <PayPal
            :amount="finalAmmount"
            currency="BRL"
            :client="credentials"
            :dev="true"
            @paypal-paymentAuthorized="iniciarAtendimento"
            @paypal-paymentCompleted="iniciarAtendimento"
            @paypal-paymentCancelled="iniciarAtendimento"
            invoiceNumber="201701011000">
          </PayPal>
        </f7-card-footer>
    </f7-card>
  </div>
</template>

<script>

  import PayPal from './vue-paypal-checkout/src/main'
  import atendimento from '../services/atendimento'
  import paypalCredentials from './../static/paypal-credentials'
  console.log("paypal credentials", paypalCredentials)
  import {db} from '../util/firebase'
  import  * as moment from 'moment'


  export default {
      data: () => {
          return {
              credentials: paypalCredentials,
              quant: 0,
              ammount: 0
          }
      },
      created: function() {
        if (this.product.quant) this.quant = this.product.quant

      },
      computed: {
          price: function() {
            return 12
          },
          finalAmmount: function() {
              return Number(this.product.price).toFixed(2)
          }
      },
      props: ["product", "allowEdit"],
      methods: {
          increment: function() {
              this.quant++
              this.$emit("quantchanged", this.product, this.quant)
          },
          decrement: function() {
              this.quant--
              if (this.quant < 0) this.quant = 0
              this.$emit("quantchanged", this.product, this.quant)
          },
          iniciarAtendimento: function() {
              let product = this.product;
              let vue = this
              window.app_completePurchase = function(loja, pickupTime) {
                console.log("completando compra", loja, pickupTime)
                let usuario = {nome: "Bruno Rodrigues", email: "brunocroh@gmail.com"};
                product.qtde = this.quant == 0 ? 1 : vue.quant;
                let dataPickUp = "07/10/2017 " +    pickupTime
                let ehEntrega = "true";
                let nomeLoja = loja;
                let produtos = [product];
                // let dataPickUp = "07/10/2017 08:00:00"

                atendimento.iniciar(usuario,
                    produtos,
                    dataPickUp,
                    ehEntrega,
                    loja)
                .then(res => {
                    console.log(res.data);
                });
              }
              app_router.load({url: '/order-pickup'})
          }
      },
    components: {
      PayPal
    }
  }
</script>

<style scoped>
    .inline-block {
        display: inline-block;
    }
    .float-right {
        float: right;
    }
</style>
