<template>
  <f7-page>
    <f7-navbar title="About" back-link="Back" sliding></f7-navbar>
    <f7-block>

      <product
        v-for="product in products"
        v-bind:key="product.ean"
        :product="product"
        @quantchanged="productQuantChanged"
        :allowEdit="true">
      </product>
    </f7-block>
  </f7-page>
</template>

<script>

import {db} from '../../util/firebase';
import Product from '../Product.vue'

let productsRef = db.ref('products/')

export default {
  data: () => {
    return {
      selectedProducts: [],
    }
  },
  created: function() {
    console.log("products router", this)
    window.app_router = this.$router
  },
  firebase: {
    products: productsRef
  },
  methods: {
    getSelectedProducts: {

    },
    productQuantChanged: function(product, quant) {
      product.quant = quant
      console.log(product, quant)
      let exists = this.selectedProducts.find((listed) => listed.ean == product.ean)
      if (!exists) {
        this.selectedProducts.push(product)
      }
      if (quant == 0) {
        this.selectedProducts = this.selectedProducts.filter((listed) => listed.ean != product.ean)
      }
      this.$emit("selected", this.selectedProducts)

    }
  },
  components: {
    Product
  },
  computed: {
    countCart: function() {
      console.log(this.selectedProducts)
      let count = 0
      return this.selectedProducts.length
    }
  },
  watch: {

  }
}
</script>
