<template>
  <f7-page>
    <f7-navbar title="About" back-link="Back" sliding></f7-navbar>
    <f7-block>
      <f7-card title="Checkout de pedido" :content="'Total: R$ '+ totalPedido.toFixed(2)"></f7-card>
    </f7-block>
    <f7-block>
      <PayPal
          :amount="totalPedido.toFixed(2)"
          currency="BRL"
          :client="credentials"
          :dev="true"
          @paypal-paymentAuthorized="iniciarAtendimento"
          invoiceNumber="201701011000">
        </PayPal>
    </f7-block>
    <f7-block>
      <f7-list>
        <f7-list-item link="/order-pickup" title="Configurar pickup" link-view="#main-view">
        </f7-list-item>
      </f7-list>
    </f7-block>
    <f7-block>
      <product
        v-for="product in produtosSelecionados"
        v-bind:key="product.ean"
        :product="product"
        :allowEdit="false">
      </product>
    </f7-block>
  </f7-page>
</template>

<script>
import product from './../Product'
import PayPal from './../vue-paypal-checkout/src/main'
import paypalCredentials from './../../static/paypal-credentials'

export default {
  props: ['cartItens'],
  data: function() {
    return {
      credentials: paypalCredentials
    }
  },
  computed: {
    produtosSelecionados: function() {
      return window.app_selectedProducts || []
    },
    totalPedido: function() {
      let num = (val) => Number(val)
      let total = 0
      this.produtosSelecionados.forEach( (prod) => total+= num(prod.price) * num(prod.quant))
      return total
    }
  },
  methods: {
    iniciarAtendimento: function() {
      let products = this.produtosSelecionados;
      window.app_completePurchase = function(loja, pickupTime) {
          console.log("completando compra", loja, pickupTime)

        let usuario = {nome: "Bruno Rodrigues", email: "brunocroh@gmail.com"};
        let produtos = products;
        // let dataPickUp = "07/10/2017 08:00:00"
        let ehEntrega = false;

        atendimento.iniciar(usuario,
        produtos,
        // dataPickUp,
        pickupTime,
        ehEntrega).then(res => {
            console.log(res.data);
        });
      }
    }
  },
  components: {
    product,
    PayPal
  }
}
</script>
