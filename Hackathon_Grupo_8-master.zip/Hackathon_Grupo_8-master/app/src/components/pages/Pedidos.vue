<template>

  <f7-page>
    <f7-navbar title="About" back-link="Back" sliding></f7-navbar>
    <f7-block>
        <f7-card>
            <f7-list>
                <f7-list-item :title="pedido.codigo"></f7-list-item>
                <f7-list-item :title="pedido.valor"></f7-list-item>
                <f7-list-item :title="pedido.data"></f7-list-item>
                <f7-list-item><small>{{pedido.mensagem}}</small></f7-list-item>
                <f7-list-item><small>{{pedido.ultimaInteracao}}</small></f7-list-item>
                <p>
                    <delivery-loader :step="3"></delivery-loader>
                </p>
                <f7-list-item>
                  <textarea v-model="sendChat"></textarea>
                </f7-list-item>
                <f7-list-item>
                  <a href="#" class="button active" @click="sendMsg">Enviar</a>
                </f7-list-item>
            </f7-list>
        </f7-card>
    </f7-block>
  </f7-page>
</template>

<script>

    import {db} from '../../util/firebase'
    import deliveryLoader from './../DeliveryLoader'

    var mock = {
      "codigo": "Pedido 86",
      "valor": "Valor: R$ 80.32",
      "data": "09/10/2017",
      "mensagem": "Atendimento trabalhando agora",
      "ultimaInteracao": "Ultima interação às 12h39"
    }

    export default {
        data: () => {
          return {
            pedido: {
              codigo: "Pedido 123",
              valor: "Valor: R$ 80.32",
              data: "09/10/2017",
              mensagem: "aguardando separação do produto",
              ultimaInteracao: "Ultima interação às 12h39"
            },
            sendChat:""
          }
        },
        created: function(){
            db.ref('ultimoInserido/1').on('value', function(snapshot){
                db.ref('treatment/73'/*+snapshot.val().codigo*/).on('value', function(snap){
                  console.log(snap.val());
                  if(snap.val()){
                    this.pedido = snap.val().valor;
                  }else{
                    this.pedido = mock;
                  }
                })
            })
        },
        methods: {
          sendMsg: function() {
            alert("enviando msg" + this.sendChat)
          }
        },
        components: {
            deliveryLoader
        },
    }
</script>

<style scoped>

</style>
