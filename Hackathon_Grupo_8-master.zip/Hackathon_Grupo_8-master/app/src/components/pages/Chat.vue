<template>
  <p>This is the chat</p>
</template>
<script>
export default {
  data: function() {
      return {}
  }
}
</script>