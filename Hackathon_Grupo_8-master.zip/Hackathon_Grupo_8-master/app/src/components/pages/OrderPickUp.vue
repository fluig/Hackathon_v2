<template>
  <f7-page>
    <f7-navbar title="About" back-link="Back" sliding></f7-navbar>
    <f7-block>
        <p>Selecione a loja desejada para pick-up</p>
    </f7-block>
    <f7-block>
        <f7-list form>


            <f7-list-item smart-select smart-select-searchbar title="Loja" smart-select-back-on-select>
                <select name="lojas" v-model="form.selectedStore">
                    <optgroup label="Goiânia">
                        <option value="Loja Avenida Independência" selected>Loja Avenida Independência</option>
                        <option value="Loja Campinas">Loja Campinas</option>
                    </optgroup>
                    <optgroup label="Brasília">
                        <option value="Loja Região Leste" >Loja Região Leste</option>
                        <option value="Loja dos Candangos">Loja dos Candangos</option>
                    </optgroup>
                    <optgroup label="Belo Horizonte">
                        <option value="Loja Shopping Flores" >Loja Shopping Flores</option>
                        <option value="Loja do Pão de Queijo">Games &amp; Pão de Queijo</option>
                    </optgroup>
                </select>
            </f7-list-item>

            <f7-list-item title="Pickup">
                <f7-input type="time" placeholder="Hora" v-model="form.pickUpTime"/>
            </f7-list-item>

            <f7-list-item>
                <f7-button @click="enviar">Agendar</f7-button>
            </f7-list-item>
        </f7-list>
    </f7-block>
  </f7-page>
</template>

<script>
export default {
    data: function() {
        return {
            form: {
                selectedStore: "",
                pickUpTime: ""
            }
        }
    },
    methods: {
        enviar: function() {
            if (window.app_completePurchase ) {
                window.app_completePurchase (this.form.selectedStore, this.form.pickUpTime)
            }
            app_router.load({url: '/orders'})
        }
    }
}
</script>
