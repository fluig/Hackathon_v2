package br.com.fluig.hackathon;

public class BasicPackage {

}
