function setSelectedZoomItem(selectedItem) {
	//$("#tblEnvolvidos tbody i ").not(":first").each(function() {
		//fnWdkRemoveChild(this);
	//});

	if(selectedItem.inputId == "codProposta"){
		$('input[name="tipoProjeto"]').val(selectedItem.tipo_projeto);
		$('input[name="nomeProposta"]').val(selectedItem.nome_projeto);
		$('textarea[name="justificativa"]').val(selectedItem.justificativa);
		$('textarea[name="objetivo"]').val(selectedItem.objetivo);
		$('textarea[name="descricao"]').val(selectedItem.descricao);
		$('textarea[name="escopo"]').val(selectedItem.escopo);
		$('textarea[name="premissas"]').val(selectedItem.premissa);
		$('textarea[name="restricoes"]').val(selectedItem.restricoes);
	}
}
window.onload = function() {
	"use strict";
	var $zoomPreview = $(".zoom-preview");
	if ($zoomPreview.length) {
		$zoomPreview.parent().removeClass("input-group");
		$zoomPreview.remove();
	}
	$('input#codProposta').on('fluig.filter.beforeItemRemove', function(event) {
		$('[name="tipoProjeto"]').val('');
		$('[name="nomeProposta"]').val('');
		$('[name="justificativa"]').val('');
		$('[name="objetivo"]').val('');
		$('[name="descricao"]').val('');
		$('[name="escopo"]').val('');
		$('[name="premissas"]').val('');
		$('[name="restricoes"]').val('');
	});
};