function displayFields(form,customHTML){
	var activity = parseInt(getValue('WKNumState'));

	form.setShowDisabledFields(true);
	var modo = form.getFormMode();

	function oculta(variavel){        
		customHTML.append('<script>                                       ');
	    customHTML.append('$(\'[name="'+variavel+'"]\').css(\'display\', \'none\');                      ');
	    customHTML.append('$([name="'+variavel+'"]).parent().css(\'display\', \'none\');                                     ');
	    customHTML.append('var closers = $([name="'+variavel+'"]).closest(\'.form-field\').find(\'input, textarea, select\');');
	    customHTML.append('var hideDiv = true;                                                                               ');
	    customHTML.append('$.each(closers, function(i, close) {                                                              ');
	    customHTML.append('  if (close.style.display != \'none\') {                                                          ');
	    customHTML.append('    hideDiv = false;                                                                              ');
	    customHTML.append('  }                                                                                               ');
	    customHTML.append('});                                                                                               ');
	    customHTML.append('                                                                                                  ');
	    customHTML.append('if (hideDiv == true) {                                                                            ');
	    customHTML.append('  $([name="'+variavel+'"]).closest(\'.form-field\').css(\'display\', \'none\');                   ');
	    customHTML.append('}                                                                                                 ');
	    customHTML.append('$(\'[name="'+variavel+'"]\').closest(".form-field").hide();                                       ');
	    customHTML.append('</script>                                       ');
	  }

	if (modo == 'VIEW') {
		form.setShowDisabledFields(false);
	}

	if (activity == 4 || activity == 0) {
		oculta('aprovacaoEscritorioProjeto');
		oculta('aprovacaogerencia');
		oculta('aprovacaoFinanceiro');
		oculta('solicitarAporte');
		oculta('valorAporte');
		oculta('aprovarPedidoAporte');
		oculta('aprovacaoPresidencia');
		oculta('aprovacaoGG');
	}

	if (activity == 5 || activity == 10) {
		oculta('aprovacaogerencia');
		oculta('aprovacaoFinanceiro');
		oculta('solicitarAporte');
		oculta('valorAporte');
		oculta('aprovarPedidoAporte');
		oculta('aprovacaoPresidencia');
		oculta('aprovacaoGG');
	}

	if (activity == 19) {
		oculta('aprovacaoFinanceiro');
		oculta('solicitarAporte');
		oculta('valorAporte');
		oculta('aprovarPedidoAporte');
		oculta('aprovacaoPresidencia');
		oculta('aprovacaoGG');
	}

	if (activity == 32) {
		oculta('valorAporte');
		oculta('aprovacaoPresidencia');
		oculta('aprovarPedidoAporte');
		oculta('aprovacaoGG');
	}

	if (activity == 40) {
		oculta('aprovacaoGG');
		oculta('aprovacaoPresidencia');
	}

	if (activity == 46) {
		oculta('aprovacaoPresidencia');
		if(getValue('aprovarPedidoAporte') == "") {
			oculta('aprovarPedidoAporte');
		}
		if(getValue('valorAporte') == ""){
			oculta('valorAporte');
		}
	}

	if (activity == 53) {
		if(getValue('aprovarPedidoAporte') == "") {
			oculta('aprovarPedidoAporte');
		}
		if(getValue('valorAporte') == ""){
			oculta('valorAporte');
		}
	}

	if (activity == 59) {
		if(getValue('aprovarPedidoAporte') == "") {
			oculta('aprovarPedidoAporte');
		}
		if(getValue('valorAporte') == ""){
			oculta('valorAporte');
		}
	}
}