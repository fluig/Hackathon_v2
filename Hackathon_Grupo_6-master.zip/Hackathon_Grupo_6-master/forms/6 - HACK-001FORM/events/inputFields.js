function inputFields(form){
	var codProposta = form.getValue('codProposta');
	var tipoProjeto = form.getValue('tipoProjeto');
	
	form.setValue('campoDescritor', codProposta + '-' + tipoProjeto);
}