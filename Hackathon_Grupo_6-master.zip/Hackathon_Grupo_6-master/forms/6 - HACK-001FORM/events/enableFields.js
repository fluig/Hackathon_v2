function enableFields(form){
	var activity = getValue('WKNumState');
	
	if (activity == 10 || activity == 19){
		form.setEnabled('aprovacaoEscritorioProjeto', false);
	}

	if (activity == 32){
		form.setEnabled('aprovacaoEscritorioProjeto', false);
		form.setEnabled('aprovacaogerencia', false);
	}

	if (activity == 40){
		form.setEnabled('aprovacaoFinanceiro', false);
		form.setEnabled('aprovacaogerencia', false);

		if(form.getValue('valorAporte') != ''){
			form.setEnabled('valorAporte', false);
		}
	}

	if (activity == 53){
		form.setEnabled('aprovacaoEscritorioProjeto', false);
		form.setEnabled('aprovacaoFinanceiro', false);
		form.setEnabled('aprovacaogerencia', false);

		if(form.getValue('valorAporte') != ''){
			form.setEnabled('valorAporte', false);
		}

		if(form.getValue('aprovarPedidoAporte') != ''){
			form.setEnabled('aprovarPedidoAporte', false);
		}
	}

	if (activity == 59){
		form.setEnabled('aprovacaoEscritorioProjeto', false);
		form.setEnabled('aprovacaoFinanceiro', false);
		form.setEnabled('aprovacaogerencia', false);
		form.setEnabled('aprovacaoPresidencia', false);
		form.setEnabled('aprovacaoGG', false);

		if(form.getValue('valorAporte') != ''){
			form.setEnabled('valorAporte', false);
		}

		if(form.getValue('aprovarPedidoAporte') != ''){
			form.setEnabled('aprovarPedidoAporte', false);
		}
	}
}