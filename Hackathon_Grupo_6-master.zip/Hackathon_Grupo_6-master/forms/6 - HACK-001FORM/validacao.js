function validaCampos(atividade, proximaAtividade){	
	if(atividade == 0 || atividade == 4){
		addHasFree('codProposta');
	}
	
	if(atividade == 5){
		addHasFree('aprovacaoEscritorioProjeto');
		if(getValue('aprovacaoEscritorioProjeto') == "Não"){
			addHasFree('observacoes');
		}
	}
	
	if(atividade == 19){
		addHasFree('aprovacaogerencia');
		if(getValue('aprovacaogerencia') == "Não"){
			addHasFree('observacoes');
		}
	}
	
	if(atividade == 32){
		addHasFree('aprovacaoFinanceiro');
		if(getValue('aprovacaoFinanceiro') == "Não"){
			addHasFree('observacoes');
		}
		addHasFree('solicitarAporte');
		if(getValue('solicitarAporte') == "Sim"){
			addHasFree('valorAporte');
		}
	}
	
	if(atividade == 40){
		addHasFree('aprovarPedidoAporte');
	}
	
	if(atividade == 46){
		addHasFree('aprovacaoGG');
	}

	if(atividade == 53){
		addHasFree('aprovacaoPresidencia');
	}
}