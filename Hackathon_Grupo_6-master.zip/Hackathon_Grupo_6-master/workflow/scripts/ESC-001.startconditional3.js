function startconditional3() {
	false;
}