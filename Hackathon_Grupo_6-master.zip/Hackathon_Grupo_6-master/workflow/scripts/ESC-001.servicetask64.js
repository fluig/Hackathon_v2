function servicetask64(attempt, message) {
	/*
	var tamanhoLaco = hAPI.getCardValue('');

	for(var i = 0; i < tamanhoLaco.length; i++){
		try {
			var nmrSolicProposta = getValue('WKNumProces'); 
			
			var servico = ServiceManager.getService("ECMWorkflowEngineService").getBean(); 
			log.warn("%%%%%% servico : " + servico);
			
			var locator = servico.instantiate("com.totvs.technology.ecm.workflow.ws.ECMWorkflowEngineServiceService"); 
			log.warn("%%%%%% locator : " + locator);
	  
			var WorkflowEngineService = locator.getWorkflowEngineServicePort(); 
			log.warn("%%%%%% WorkflowEngineService : " + WorkflowEngineService);
	  
			var username = hAPI.getAdvancedProperty("loginService"); 
	  		log.warn("%%%%%% username : " + username);
	  
	  		var password = hAPI.getAdvancedProperty("passwordService"); 
	  		log.warn("%%%%%% password : " + password);
	  
	  		var companyId = parseInt(getValue("WKCompany")); 
			log.warn("%%%%%% companyId : " + companyId);
	  
			var processId = "ESC-002";
			var choosedState = 0;

			var comments = "Solicitação aberta por: Nº " + nmrSolicProposta;  
			log.warn("%%%%%% comments : " + comments);
	  
			var userId = hAPI.getAdvancedProperty("matService");   
			log.warn("%%%%%% userId : " + userId);
	  
			var completeTask = true;   
			log.warn("%%%%%% completeTask : " + completeTask);
	  
			var attachments = servico.instantiate("com.totvs.technology.ecm.workflow.ws.ProcessAttachmentDtoArray");   
			log.warn("%%%%%% attachments : " + attachments);
	  
			var appointment = servico.instantiate("com.totvs.technology.ecm.workflow.ws.ProcessTaskAppointmentDtoArray");   
			log.warn("%%%%%% appointment : " + appointment);
			  
			var managerMode = false;  
			log.warn("%%%%%% managerMode : " + managerMode);
			  
			var novaSolic;

			var colleagueIds = servico.instantiate("net.java.dev.jaxb.array.StringArray");
			colleagueIds.getItem().add('System:Auto');
			log.warn("%%%%%% colleagueIds"); 

			var cardData =  preencheFicha(servico, i);
			//var cardData = servico.instantiate("net.java.dev.jaxb.array.StringArrayArray");

			novaSolic = WorkflowEngineService.startProcess(username,password,companyId,processId,choosedState,colleagueIds,comments,userId,completeTask,attachments,cardData,appointment,managerMode);
			var numSolicIniciada = retornoArrayArray(novaSolic,"iProcess");
			hAPI.setCardValue("numSolicIniciada", numSolicIniciada);

			if (numSolicIniciada == '') {
				var erroRetorno = "";
				for(var k = 0 ; k < novaSolic.getItem().size() ; k++){
					erroRetorno +=" ---- "+novaSolic.getItem().get(k).getItem().get(0) + " => "+novaSolic.getItem().get(k).getItem().get(1);
				}
				throw erroRetorno;
			}

			hAPI.setCardValue('numSolicIniciada',""+numSolicIniciada);
		} catch(error) { 
			log.error(error);
			throw error;
		}
	}
	
}

function preencheFicha(servico, index){
	log.warn("%%%%%% entrou na funcão");
	var cardData = servico.instantiate("net.java.dev.jaxb.array.StringArrayArray");
	log.warn("%%%%%% cardData");

	var solicOrigem = servico.instantiate("net.java.dev.jaxb.array.StringArray");
	solicOrigem.getItem().add("codProposta");
	solicOrigem.getItem().add(hAPI.getCardValue('codProposta')+"");
	cardData.getItem().add(solicOrigem);
	log.warn("@@"+(hAPI.getCardValue('codProposta')+""));
	 
	var solicOrigem = servico.instantiate("net.java.dev.jaxb.array.StringArray");
	solicOrigem.getItem().add("tipoProjeto");
	solicOrigem.getItem().add(hAPI.getCardValue('tipoProjeto')+"");
	cardData.getItem().add(solicOrigem);
	log.warn("@@"+(hAPI.getCardValue('tipoProjeto')+""));
	
	var solicOrigem = servico.instantiate("net.java.dev.jaxb.array.StringArray");
	solicOrigem.getItem().add("justificativa");
	solicOrigem.getItem().add(hAPI.getCardValue('justificativa')+"");
	cardData.getItem().add(solicOrigem);
	log.warn("@@"+(hAPI.getCardValue('justificativa')+""));

	var solicOrigem = servico.instantiate("net.java.dev.jaxb.array.StringArray");
	solicOrigem.getItem().add("objetivo");
	solicOrigem.getItem().add(hAPI.getCardValue('objetivo')+"");
	cardData.getItem().add(solicOrigem);
	log.warn("@@"+(hAPI.getCardValue('objetivo')+""));

	var solicOrigem = servico.instantiate("net.java.dev.jaxb.array.StringArray");
	solicOrigem.getItem().add("macro");
	solicOrigem.getItem().add(hAPI.getCardValue("macro___"+i)+"");
	cardData.getItem().add(solicOrigem);
	log.warn("@@"+(hAPI.getCardValue("macro___"+i)+""));

	var solicOrigem = servico.instantiate("net.java.dev.jaxb.array.StringArray");
	solicOrigem.getItem().add("solicOrigem");
	solicOrigem.getItem().add(getValue('WKNumProces')+"");
	cardData.getItem().add(solicOrigem);
	log.warn("@@"+(getValue('WKNumProces')+""));*/
}