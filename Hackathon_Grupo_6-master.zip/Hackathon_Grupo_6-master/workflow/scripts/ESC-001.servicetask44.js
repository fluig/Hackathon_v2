function servicetask44(attempt, message) {
}